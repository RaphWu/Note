﻿using System;
using System.Windows.Forms;
using Calin.WinForm;

namespace Calin.TaskPulse
{
    public partial class FormSplash : Form
    {
        public FormSplash()
        {
            InitializeComponent();
        }

        private void FormSplash_Load(object sender, EventArgs e)
        {
            MessageList.Items.Clear();
        }

        public void UpdateStatus(string message)
        {
            this.InvokeIfRequired(() =>
            {
                MessageList.Items.Insert(0, message);
            });
        }
    }
}
