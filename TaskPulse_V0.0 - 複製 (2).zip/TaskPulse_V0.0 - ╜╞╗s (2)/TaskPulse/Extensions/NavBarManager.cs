﻿using System.Collections.Generic;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Sunny.UI;

namespace Calin.TaskPulse.Extensions
{
    public class NavBarNodeState
    {
        public TreeNode Node { get; set; }
        public bool Visible { get; set; } = true;
        public int Order { get; set; }
    }

    public class NavBarManager
    {
        private readonly UINavBar _navBar;
        private readonly List<NavBarNodeState> _nodes = new List<NavBarNodeState>();

        public List<NavBarNodeState> Nodes => _nodes;

        public int Count => _nodes.Count;

        public NavBarManager(UINavBar navBar)
        {
            _navBar = navBar;
        }

        public void AddNode(string text, PageCode pageCode, int order)
        {
            int pageIndex = (int)pageCode;
            var node = _navBar.CreateNode(text, pageIndex);
            node.Tag = pageIndex;

            var state = new NavBarNodeState { Node = node, Order = order, Visible = true };
            _nodes.Add(state);
        }

        public void SetVisible(NavBarNodeState state, bool visible)
        {
            state.Visible = visible;
            //Refresh();
        }

        //public void Refresh()
        //{
        //    _navBar.Nodes.Clear();
        //    foreach (var state in _nodes.OrderBy(x => x.Order))
        //    {
        //        if (state.Visible)
        //            _navBar.Nodes.Add(state.Node);
        //    }
        //}
    }
}
