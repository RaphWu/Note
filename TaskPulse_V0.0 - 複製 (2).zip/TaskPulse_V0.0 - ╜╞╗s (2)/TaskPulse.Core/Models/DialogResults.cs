﻿using System.Windows.Forms;

namespace Calin.TaskPulse.Core.Models
{
    public class DialogResults
    {
        public DialogResult DialogResult { get; set; }
        public string StringValue { get; set; }
        public string StringValue2 { get; set; }
        public int IntValue { get; set; }
        public int IntValue2 { get; set; }
    }
}
