﻿using System.Data.Entity;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.Models
{
    public class CoreContext : DbContext
    {
        public CoreContext() : base("name=CoreContext") { }

        /********************
         * Core
         ********************/
        public DbSet<Permission> Permissions { get; set; }

        /***** User *****/
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<JobTitle> JobTitles { get; set; }
        public DbSet<UserGroup> UserGroups { get; set; }
        public DbSet<EmployeeStatus> EmployeeStatuses { get; set; }

        /***** WorkstationName *****/
        public DbSet<Workstation> Workstations { get; set; }
        public DbSet<Model> Models { get; set; }
        public DbSet<ModelStatus> ModelStatuses { get; set; }

        /***** MachineLocations *****/
        public DbSet<MachineCondition> MachineConditions { get; set; }
        public DbSet<MachineLocation> MachineLocations { get; set; }
        //public DbSet<MachineAssetCode> MachineAssetCodes { get; set; }
        public DbSet<MachineBrand> MachineBrands { get; set; }
        public DbSet<MachineCategory> MachineCategories { get; set; }
        public DbSet<MachineType> MachineTypes { get; set; }
        //public DbSet<MachineIssueCategory> MachineIssueCategories { get; set; }
        public DbSet<MachineName> MachineNames { get; set; }
        public DbSet<Machine> Machines { get; set; }

        /********************
         * MaintiFlowMain
         ********************/

        //***** 需求單位 *****/
        //public DbSet<RequestingUnit> RequestingUnits { get; set; }

        /***** 維護單位 *****/
        public DbSet<IssueCategory> IssueCategories { get; set; }
        public DbSet<MaintenanceUnit> MaintenanceUnits { get; set; }

        /***** TaskOrder *****/
        public DbSet<TaskOrder> TaskOrders { get; set; }
        public DbSet<TaskOrderEngineer> TaskOrderEngineers { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new CoreInitializer(modelBuilder));

            SplashMessenger.Post("建立資料庫關聯...");

            /********************
             * Core
            ********************/

            /***** 權限 *****/
            // 部門權限 多對多: Department.DepartmentId ↔ Permission.PermissionId
            modelBuilder.Entity<Department>()
                .HasMany(d => d.Permissions)
                .WithMany(p => p.Departments)
                .Map(m =>
                {
                    m.ToTable("DepartmentPermissions");
                    m.MapLeftKey("DepartmentId");
                    m.MapRightKey("PermissionId");
                });

            // 群組權限 多對多: UserGroup.UserGroupId ↔ Permission.PermissionId
            modelBuilder.Entity<UserGroup>()
                .HasMany(p => p.Permissions)
                .WithMany(ug => ug.UserGroups)
                .Map(m =>
                {
                    m.ToTable("UserGroupPermissions");
                    m.MapLeftKey("UserGroupId");
                    m.MapRightKey("PermissionId");
                });

            // 個人權限 多對多: Employee.EmployeeId ↔ Permission.PermissionId
            modelBuilder.Entity<Employee>()
               .HasMany(e => e.Permissions)
               .WithMany(p => p.Employees)
               .Map(m =>
               {
                   m.ToTable("EmployeePermissions");
                   m.MapLeftKey("EmployeeId");
                   m.MapRightKey("PermissionId");
               });

            //// Permission Owner 屬性配置
            //modelBuilder.Entity<Permission>()
            //    .Property(p => p.Owner)
            //    .IsRequired();

            /***** Employee *****/
            var employee = modelBuilder.Entity<Employee>();

            // 部門 一對多: Employee.Department → Department.Employees
            employee.HasOptional(e => e.Department)
                    .WithMany(d => d.Employees)
                    .HasForeignKey(e => e.DepartmentId)
                    .WillCascadeOnDelete(false);

            // 群組 多對多: Employee.EmployeeId ↔ UserGroup.UserGroupId
            employee.HasMany(e => e.UserGroups)
                    .WithMany(ug => ug.Members)
                    .Map(m =>
                    {
                        m.ToTable("EmployeeUserGroups");
                        m.MapLeftKey("EmployeeId");
                        m.MapRightKey("UserGroupId");
                    });

            // 職稱 一對多: Employee.JobTitle → JobTitle.Employees
            employee.HasOptional(e => e.JobTitle)
                    .WithMany(t => t.Employees)
                    .HasForeignKey(e => e.JobTitleId)
                    .WillCascadeOnDelete(false);

            // 副本人員 多對多: Employee.EmployeeId ↔ CarbonCopy.CarbonCopyId
            employee.HasMany(e => e.CarbonCopies)
                    .WithMany(e => e.CarbonCopiedBy)
                    .Map(m =>
                    {
                        m.ToTable("EmployeeCarbonCopies");   // 中介表名稱
                        m.MapLeftKey("EmployeeId");          // 主動 CC 的人
                        m.MapRightKey("CarbonCopyEmployeeId"); // 被 CC 的人
                    });

            // 狀態 一對多: Employee.Status → EmployeeStatus.Employees
            employee.HasRequired(e => e.Status)
                    .WithMany(t => t.Employees)
                    .HasForeignKey(e => e.StatusId)
                    .WillCascadeOnDelete(false);

            /***** Machine *****/

            var machine = modelBuilder.Entity<Machine>();

            // 機台狀態 一對多: Machine.Condition → MachineCondition.Machines
            machine.HasRequired(m => m.Condition)
                  .WithMany(ms => ms.Machines)
                  .HasForeignKey(m => m.ConditionId)
                  .WillCascadeOnDelete(false);

            // 位置 一對多: Machine.Location → MachineLocation.MachineLocations
            machine.HasRequired(m => m.Location)
                   .WithMany(ml => ml.MachineLocations)
                   .HasForeignKey(m => m.LocationId)
                   .WillCascadeOnDelete(false);

            //// 資產編號 多對一: MachineAssetCode.MachineId → MachineAssetCode.Machine
            //modelBuilder.Entity<MachineAssetCode>()
            //    .HasRequired(m => m.Machine)
            //    .WithMany(ma => ma.Assets)
            //    .HasForeignKey(m => m.MachineId)
            //    .WillCascadeOnDelete(false);

            // 廠牌 一對多: Machine.Brand → MachineBrand.MachineBrands
            machine.HasOptional(m => m.Brand)
                   .WithMany(mb => mb.MachineBrands)
                   .HasForeignKey(m => m.BrandId)
                   .WillCascadeOnDelete(false);

            // 機台分類 一對多: MachineType.Category → MachineCategory.MachineTypes
            modelBuilder.Entity<MachineType>()
                .HasRequired(m => m.Category)
                .WithMany(mc => mc.MachineTypes)
                .HasForeignKey(m => m.CategoryId)
                .WillCascadeOnDelete(false);

            // 機台設備別 一對多: MachineName.MachineType → MachineType.MachineNames
            modelBuilder.Entity<MachineName>()
                .HasOptional(m => m.MachineType)
                .WithMany(mt => mt.MachineNames)
                .HasForeignKey(m => m.TypeId)
                .WillCascadeOnDelete(false);

            // 機台名稱 一對多: Machine.MachineName → MachineName.Machines
            machine.HasRequired(m => m.MachineName)
                   .WithMany(mn => mn.Machines)
                   .HasForeignKey(m => m.MachineNameId)
                   .WillCascadeOnDelete(false);

            // 工站 多對多: Machine.Workstations ↔ Workstation.Machines
            machine.HasMany(m => m.Workstations)
                   .WithMany(w => w.Machines)
                   .Map(m =>
                   {
                       m.ToTable("MachineWorkstation");
                       m.MapLeftKey("MachineId");
                       m.MapRightKey("Key");
                   });

            //// 問題分類 一對多: Machine.IssueCategory → MachineIssueCategory.Machines
            //machine.HasOptional(m => m.IssueCategory)
            //       .WithMany(ic => ic.Machines)
            //       .HasForeignKey(m => m.IssueCategoryId)
            //       .WillCascadeOnDelete(false);

            /********************
             * MaintiFlowMain
             ********************/

            var taskorder = modelBuilder.Entity<TaskOrder>();

            /***** 需求單位 *****/
            // 需求單位 一對多: TaskOrder.RequestingUnit → Department.TaskOrders
            //taskorder.HasOptional(t => t.RequestingUnit)
            //         .WithMany(ru => ru.TaskOrders)
            //         .HasForeignKey(t => t.RequestingUnitId)
            //         .WillCascadeOnDelete(false);

            // 回覆人員 一對多: TaskOrder.FeedbackEmployee → Employee.FeedbackEmployeeTaskOrders
            taskorder.HasOptional(t => t.FeedbackEmployee)
                   .WithMany(ru => ru.FeedbackEmployeeTaskOrders)
                   .HasForeignKey(t => t.FeedbackEmployeeId)
                   .WillCascadeOnDelete(false);

            /***** 維護單位 *****/
            // 維護類型 一對多: TaskOrder.IssueCategory → TaskOrderIssueCategory.TaskOrders
            taskorder.HasOptional(t => t.IssueCategory)
                     .WithMany(ic => ic.TaskOrders)
                     .HasForeignKey(t => t.IssueCategoryId)
                     .WillCascadeOnDelete(false);

            // 維護單位 一對多: TaskOrder.MaintenanceUnit → MaintenanceUnit.TaskOrders
            taskorder.HasOptional(t => t.MaintenanceUnit)
                     .WithMany(mu => mu.TaskOrders)
                     .HasForeignKey(t => t.MaintenanceUnitId)
                     .WillCascadeOnDelete(false);

            /***** TaskOrder.Core *****/
            // 部門 一對多: Employee.Department → Department.Employees
            modelBuilder.Entity<Employee>()
                .HasOptional(t => t.Department)
                .WithMany(e => e.Employees)
                .HasForeignKey(t => t.DepartmentId)
                .WillCascadeOnDelete(false);

            // 職稱 一對多: Employee.JobTitle → JobTitle.Employees
            modelBuilder.Entity<Employee>()
                .HasOptional(t => t.JobTitle)
                .WithMany(e => e.Employees)
                .HasForeignKey(t => t.JobTitleId)
                .WillCascadeOnDelete(false);

            // 建檔人員 一對多: TaskOrder.Creator → Employee.CreaterTaskOrders
            taskorder.HasRequired(t => t.Creator)
                     .WithMany(e => e.CreaterTaskOrders)
                     .HasForeignKey(t => t.CreatorId)
                     .WillCascadeOnDelete(false);

            // 維護工程師 多對多（顯式 join entity）
            modelBuilder.Entity<TaskOrderEngineer>()
                .HasKey(te => new { te.TaskOrderId, te.EmployeeId });

            modelBuilder.Entity<TaskOrderEngineer>()
                .HasRequired(te => te.TaskOrder)
                .WithMany(t => t.TaskOrderEngineers)
                .HasForeignKey(te => te.TaskOrderId)
                .WillCascadeOnDelete(true); // 刪除 TaskOrder 時自動刪除關聯

            modelBuilder.Entity<TaskOrderEngineer>()
                .HasRequired(te => te.Engineer)
                .WithMany(e => e.TaskOrderEngineers)
                .HasForeignKey(te => te.EmployeeId)
                .WillCascadeOnDelete(false); // 不刪除 Employee

            /***** WorkstationName *****/
            // 工站 一對多: TaskOrder.Workstation → Workstation.TaskOrders
            taskorder
                .HasOptional(t => t.Workstation)
                .WithMany(w => w.TaskOrders)
                .HasForeignKey(t => t.WorkstationId)
                .WillCascadeOnDelete(false);

            // 機種 一對多: Workstation.Model → Model.Worktations
            modelBuilder.Entity<Workstation>()
                .HasOptional(w => w.Model)
                .WithMany(m => m.Worktations)
                .HasForeignKey(w => w.ModelId)
                .WillCascadeOnDelete(true);

            // 機種狀態 一對多: Model.ModelStatus → ModelStatus.Models
            modelBuilder.Entity<Model>()
                .HasRequired(w => w.ModelStatus)
                .WithMany(m => m.Models)
                .HasForeignKey(w => w.ModelStatusId)
                .WillCascadeOnDelete(false);
        }
    }
}
