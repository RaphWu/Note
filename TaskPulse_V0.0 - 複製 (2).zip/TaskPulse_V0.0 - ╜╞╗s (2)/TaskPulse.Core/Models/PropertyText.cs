﻿namespace Calin.TaskPulse.Core.Models
{
    public static class PropertyText
    {
        public struct Name
        {
            // TaskPulse.Core.CoreService.Initialize() 維護

            public static string EmployeeId;
            public static string EmployeeName;
            public static string DepartmentId;
            public static string Department;
            public static string JobTitleId;
            public static string JobTitle;
            public static string JobTitleName;
            public static string Email;
            public static string CarbonCopies;
            public static string CarbonCopyString;
            public static string CarbonCopyList;
            public static string IsEngineer;
            public static string IsEngineerString;
            public static string EmployeeStatus;
            public static string EmployeeStatusId;
            public static string EmployeeStatusName;
            public static string EmployeeStatusBoolean;
            public static string StatusChangeAt;
            public static string StatusChangeAtString;

            public static string MachineCode;
            public static string MachineCategory;
            public static string MachineType;
            public static string MachineName;
            public static string MachineModel;
            public static string Condition;
            public static string ConditionName;
            public static string Brand;
            public static string BrandName;
            public static string Location;
            public static string LocationName;
            public static string Assets;
            public static string AssetString;
            public static string AssetList;
            public static string SerialNumber;
            public static string Barcode;
            public static string Connected;
            public static string ConnectedString;
            public static string Disposal;
            public static string DisposalString;
            public static string Remark;
            public static string Workstations;
            public static string ModelStatus;

            // TaskPulse.MaintiFlowMain.MaintiFlowService.Initialize() 維護

            public static string TaskOrderId;
            public static string WorkOrderNo;
            public static string OrderStatus;
            public static string OrderStatusId;
            public static string OrderStatusString;
            public static string Machine;
            public static string FullMachineName;
            public static string ModelName;
            public static string Workstation;
            public static string WorkstationName;
            public static string ModelWsName;
            public static string Creator;
            public static string CreatorName;
            public static string CreatorNameWithDepartment;
            public static string FullCreatorName;
            public static string CreationDateTime;
            public static string CreationDateTimeString;
            public static string CreationDateString;

            public static string MaintenanceUnit;
            public static string MaintenanceUnitId;
            public static string MaintenanceUnitString;
            public static string UnitString;
            public static string Engineers;
            public static string EngineerString;
            public static string EngineerMultiString;
            public static string AcceptedTime;
            public static string AcceptedTimeString;
            public static string MaintiFlowIssueCategory;
            public static string MaintiFlowIssueCategoryId;
            public static string MaintiFlowIssueCategoryString;
            public static string MaintiFlowIssueDescription;
            public static string Details;
            public static string RepairStarted;
            public static string RepairStartedString;
            public static string RepairCompleted;
            public static string RepairCompletedString;
            public static string RepairDurationTick;
            public static string RepairDuration;
            public static string RepairDurationString;
            public static string FillingTime;
            public static string FillingTimeString;

            public static string RequestingUnit;
            public static string RequestingUnitId;
            public static string RequestingUnitString;
            public static string FeedbackEmployee;
            public static string FeedbackEmployeeString;
            public static string Feedback;
            public static string OutageStarted;
            public static string OutageStartedString;
            public static string OutageEnded;
            public static string OutageEndedString;
            public static string OutageDurationTick;
            public static string OutageDuration;
            public static string OutageDurationString;

            public static string Responsible;
        }

        public struct Title
        {
            public static string Performer;
            public static string List;
            public static string CheckList;
            // Module
            public static string Setup;
            public static string ToolQuest;
            public static string MechaTrack;
            public static string MaintiFlow;

            // TaskPulse.Core.CoreService.Initialize() 維護

            public static string Employee;
            public static string EmployeeId;
            public static string EmployeeName;
            public static string Department;
            public static string JobTitle;
            public static string Email;
            public static string CarbonCopies;
            public static string IsEngineer;
            public static string EmployeeStatus;
            public static string StatusChangeAt;

            public static string MachineCode;
            public static string MachineCategory;
            public static string MachineType;
            public static string MachineName;
            public static string MachineModel;
            public static string Condition;
            public static string Brand;
            public static string Location;
            public static string Assets;
            public static string SerialNumber;
            public static string Barcode;
            public static string Connected;
            public static string Disposal;
            public static string Remark;
            public static string Workstations;
            public static string ModelStatus;

            // TaskPulse.MaintiFlowMain.MaintiFlowService.Initialize() 維護

            public static string TaskOrderId;
            public static string WorkOrderNo;
            public static string Status;
            public static string Machine;
            public static string ModelName;
            public static string Workstation;
            public static string ModelWsName;
            public static string Creator;
            public static string CreationDateTime;

            public static string MaintenanceUnit;
            public static string Engineer;
            public static string AcceptedTime;
            public static string MaintiFlowIssueCategory;
            public static string MaintiFlowIssueDescription;
            public static string Details;
            public static string RepairStarted;
            public static string RepairCompleted;
            public static string RepairDuration;
            public static string FillingTime;

            public static string RequestingUnit;
            public static string FeedbackEmployee;
            public static string Feedback;
            public static string OutageStarted;
            public static string OutageEnded;
            public static string OutageDuration;

            public static string Responsible;
        }
    }
}
