﻿using System.Windows.Forms;
using Autofac;

namespace Calin.TaskPulse.Core.Services
{
    public class DialogService
    {
        private readonly IComponentContext _context;

        public DialogService(IComponentContext context)
        {
            _context = context;
        }

        public DialogResult ShowDialog<T>() where T : Form
        {
            using (var dialog = _context.Resolve<T>())
            {
                return dialog.ShowDialog();
            }
        }
    }
}
