﻿namespace Calin.TaskPulse.Core.NavServices
{
    /// <summary>
    /// 定義導航服務的介面。
    /// </summary>
    public interface INavigationService
    {
        /// <summary>
        /// 導航至指定的泛型視圖類型。
        /// </summary>
        /// <typeparam name="TView">視圖的類型，必須為類別型別。</typeparam>
        /// <param name="regionName">區域名稱，用於指定導航的目標區域。</param>
        /// <param name="alive">指示視圖是否應保持活躍的布林值，預設為 <c>true</c>。</param>
        void Navigate<TView>(string regionName, bool alive = true) where TView : class;
    }
}
