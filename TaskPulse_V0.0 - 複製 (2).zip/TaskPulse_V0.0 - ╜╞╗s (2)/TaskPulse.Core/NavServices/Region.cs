﻿using System;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.NavServices
{
    public class Region : IRegion
    {
        private object _currentView;

        /// <inheritdoc/>
        public string Name { get; }

        /// <inheritdoc/>
        public Control HostControl { get; }

        public Region(string name, Control host)
        {
            Name = name;
            HostControl = host;
        }

        /// <inheritdoc/>
        public void ShowView(object view)
        {
            if (view is Control ctrl)
            {
                HostControl.Controls.Clear();
                ctrl.Dock = DockStyle.Fill;
                HostControl.Controls.Add(ctrl);
            }
            else
            {
                throw new ArgumentException("View must be a Control");
            }

            _currentView = view;
        }

        /// <inheritdoc/>
        public object GetCurrentView()
        {
            return _currentView;
        }

        /// <inheritdoc/>
        public void Clear()
        {
            HostControl.Controls.Clear();
        }
    }
}
