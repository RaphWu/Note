﻿namespace Calin.TaskPulse.Core.NavServices
{
    /// <summary>
    /// 定義一個介面，用於處理導航頁面的檢知。
    /// </summary>
    public interface INavigationAware
    {
        /// <summary>
        /// 當導航到此介面時呼叫。
        /// </summary>
        void OnNavigatedTo();

        /// <summary>
        /// 當從此介面導航離開時呼叫。
        /// </summary>
        void OnNavigatedFrom();
    }
}
