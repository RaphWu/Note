﻿using System;

namespace Calin.TaskPulse.Core.NavServices
{
    /// <summary>
    /// 提供檢視管理功能的介面。
    /// </summary>
    public interface IViewManager
    {
        /// <summary>
        /// 解析指定型別的檢視。
        /// </summary>
        /// <param name="viewType">要解析的檢視型別。</param>
        /// <param name="alive">指示是否保持檢視存活的布林值。</param>
        /// <returns>解析後的檢視物件。</returns>
        object Resolve(Type viewType, bool alive = false);

        /// <summary>
        /// 解析指定型別的檢視。
        /// </summary>
        /// <typeparam name="TView">要解析的檢視型別。</typeparam>
        /// <param name="alive">指示是否保持檢視存活的布林值。</param>
        /// <returns>解析後的檢視物件。</returns>
        TView Resolve<TView>(bool alive = false) where TView : class;

        /// <summary>
        /// 釋放指定型別的檢視。
        /// </summary>
        /// <param name="viewType">要釋放的檢視型別。</param>
        void Release(Type viewType);

        /// <summary>
        /// 釋放指定型別的檢視。
        /// </summary>
        /// <typeparam name="TView">要釋放的檢視型別。</typeparam>
        void Release<TView>() where TView : class;
    }
}
