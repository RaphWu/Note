﻿using System.Windows.Forms;

namespace Calin.TaskPulse.Core.NavServices
{
    /// <summary>
    /// 提供區域管理功能的介面。
    /// </summary>
    public interface IRegionManager
    {
        /// <summary>
        /// 註冊一個區域，將其與指定的控制項關聯。
        /// </summary>
        /// <param name="name">區域的名稱。</param>
        /// <param name="control">與區域關聯的控制項。</param>
        void RegisterRegion(string name, Control control);

        /// <summary>
        /// 根據名稱取得指定的區域。
        /// </summary>
        /// <param name="name">區域的名稱。</param>
        /// <returns>指定名稱的區域。</returns>
        IRegion GetRegion(string name);
    }
}
