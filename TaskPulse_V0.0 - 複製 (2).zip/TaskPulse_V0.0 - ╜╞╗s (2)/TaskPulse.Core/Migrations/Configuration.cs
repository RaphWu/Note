﻿using System.Data.Entity.Migrations;
using System.Data.SQLite.EF6.Migrations;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Migrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<CoreContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;

            // 註冊 SQLite Migration SQL Generator
            SetSqlGenerator("System.Data.SQLite", new SQLiteMigrationSqlGenerator());
        }

        protected override void Seed(CoreContext context)
        {
            // Seed 資料
        }
    }
}
