﻿using System.Data.Entity;
using System.Linq;

namespace Calin.TaskPulse.Core.Extensions
{
    public static class DbContextExtensions
    {
        /// <summary>
        /// 放棄所有未儲存的變更，讓 DbContext 回到呼叫 SaveChanges() 前的狀態。
        /// </summary>
        public static void ResetChanges(this DbContext context)
        {
            if (context == null)
                return;

            foreach (var entry in context.ChangeTracker.Entries().ToList())
            {
                switch (entry.State)
                {
                    case EntityState.Modified:
                        // 把目前值改回原本追蹤的值
                        entry.CurrentValues.SetValues(entry.OriginalValues);
                        entry.State = EntityState.Unchanged;
                        break;

                    case EntityState.Added:
                        // 新增的實體還沒存，就移除追蹤
                        entry.State = EntityState.Detached;
                        break;

                    case EntityState.Deleted:
                        // 恢復刪除狀態
                        entry.State = EntityState.Unchanged;
                        break;

                    default:
                        // Unchanged 狀態不用處理
                        break;
                }
            }
        }
    }
}
