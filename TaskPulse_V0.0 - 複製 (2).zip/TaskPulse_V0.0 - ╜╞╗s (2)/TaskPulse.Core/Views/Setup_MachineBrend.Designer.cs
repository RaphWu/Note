﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_MachineBrend
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.Condition_Up = new Sunny.UI.UISymbolButton();
            this.Condition_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.Location_Up = new Sunny.UI.UISymbolButton();
            this.Location_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.Brand_Up = new Sunny.UI.UISymbolButton();
            this.Brand_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.Brand_Create = new Sunny.UI.UISymbolButton();
            this.Brand_Edit = new Sunny.UI.UISymbolButton();
            this.Brand_Delete = new Sunny.UI.UISymbolButton();
            this.List_Conditions = new Sunny.UI.UIListBox();
            this.HeadLabel_Condition = new System.Windows.Forms.Label();
            this.HeadLabel_Location = new System.Windows.Forms.Label();
            this.HeadLabel_Brand = new System.Windows.Forms.Label();
            this.List_Brands = new Sunny.UI.UIListBox();
            this.List_Locations = new Sunny.UI.UIListBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Location_Create = new Sunny.UI.UISymbolButton();
            this.Location_Edit = new Sunny.UI.UISymbolButton();
            this.Location_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.Condition_Create = new Sunny.UI.UISymbolButton();
            this.Condition_Edit = new Sunny.UI.UISymbolButton();
            this.Condition_Delete = new Sunny.UI.UISymbolButton();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 8;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel6, 5, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel5, 3, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel3, 1, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel4, 2, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.List_Conditions, 6, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.HeadLabel_Condition, 6, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.HeadLabel_Location, 4, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.HeadLabel_Brand, 2, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.List_Brands, 2, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.List_Locations, 4, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel1, 4, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel2, 6, 2);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 3;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(1080, 668);
            this.tableLayoutPanel_Page.TabIndex = 0;
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel6.AutoSize = true;
            this.flowLayoutPanel6.Controls.Add(this.Condition_Up);
            this.flowLayoutPanel6.Controls.Add(this.Condition_Down);
            this.flowLayoutPanel6.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel6.Location = new System.Drawing.Point(686, 150);
            this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel6.TabIndex = 28;
            // 
            // Condition_Up
            // 
            this.Condition_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Condition_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Condition_Up.Location = new System.Drawing.Point(0, 9);
            this.Condition_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Condition_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Condition_Up.Name = "Condition_Up";
            this.Condition_Up.Size = new System.Drawing.Size(30, 30);
            this.Condition_Up.Symbol = 361702;
            this.Condition_Up.SymbolSize = 32;
            this.Condition_Up.TabIndex = 2;
            this.Condition_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Condition_Up.Click += new System.EventHandler(this.Condition_Up_Click);
            // 
            // Condition_Down
            // 
            this.Condition_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Condition_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Condition_Down.Location = new System.Drawing.Point(0, 57);
            this.Condition_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Condition_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Condition_Down.Name = "Condition_Down";
            this.Condition_Down.Size = new System.Drawing.Size(30, 30);
            this.Condition_Down.Symbol = 361703;
            this.Condition_Down.SymbolSize = 32;
            this.Condition_Down.TabIndex = 4;
            this.Condition_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Condition_Down.Click += new System.EventHandler(this.Condition_Down_Click);
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel5.AutoSize = true;
            this.flowLayoutPanel5.Controls.Add(this.Location_Up);
            this.flowLayoutPanel5.Controls.Add(this.Location_Down);
            this.flowLayoutPanel5.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(366, 150);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel5.TabIndex = 27;
            // 
            // Location_Up
            // 
            this.Location_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Location_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Location_Up.Location = new System.Drawing.Point(0, 9);
            this.Location_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Location_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Location_Up.Name = "Location_Up";
            this.Location_Up.Size = new System.Drawing.Size(30, 30);
            this.Location_Up.Symbol = 361702;
            this.Location_Up.SymbolSize = 32;
            this.Location_Up.TabIndex = 2;
            this.Location_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Location_Up.Click += new System.EventHandler(this.Location_Up_Click);
            // 
            // Location_Down
            // 
            this.Location_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Location_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Location_Down.Location = new System.Drawing.Point(0, 57);
            this.Location_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Location_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Location_Down.Name = "Location_Down";
            this.Location_Down.Size = new System.Drawing.Size(30, 30);
            this.Location_Down.Symbol = 361703;
            this.Location_Down.SymbolSize = 32;
            this.Location_Down.TabIndex = 4;
            this.Location_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Location_Down.Click += new System.EventHandler(this.Location_Down_Click);
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel3.AutoSize = true;
            this.flowLayoutPanel3.Controls.Add(this.Brand_Up);
            this.flowLayoutPanel3.Controls.Add(this.Brand_Down);
            this.flowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(46, 150);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel3.TabIndex = 26;
            // 
            // Brand_Up
            // 
            this.Brand_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Brand_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Brand_Up.Location = new System.Drawing.Point(0, 9);
            this.Brand_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Brand_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Brand_Up.Name = "Brand_Up";
            this.Brand_Up.Size = new System.Drawing.Size(30, 30);
            this.Brand_Up.Symbol = 361702;
            this.Brand_Up.SymbolSize = 32;
            this.Brand_Up.TabIndex = 2;
            this.Brand_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Brand_Up.Click += new System.EventHandler(this.Brand_Up_Click);
            // 
            // Brand_Down
            // 
            this.Brand_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Brand_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Brand_Down.Location = new System.Drawing.Point(0, 57);
            this.Brand_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Brand_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Brand_Down.Name = "Brand_Down";
            this.Brand_Down.Size = new System.Drawing.Size(30, 30);
            this.Brand_Down.Symbol = 361703;
            this.Brand_Down.SymbolSize = 32;
            this.Brand_Down.TabIndex = 4;
            this.Brand_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Brand_Down.Click += new System.EventHandler(this.Brand_Down_Click);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.Controls.Add(this.Brand_Create);
            this.flowLayoutPanel4.Controls.Add(this.Brand_Edit);
            this.flowLayoutPanel4.Controls.Add(this.Brand_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(132, 618);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 23;
            // 
            // Brand_Create
            // 
            this.Brand_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Brand_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Brand_Create.Location = new System.Drawing.Point(9, 0);
            this.Brand_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Brand_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Brand_Create.Name = "Brand_Create";
            this.Brand_Create.Size = new System.Drawing.Size(30, 30);
            this.Brand_Create.Symbol = 557669;
            this.Brand_Create.SymbolSize = 32;
            this.Brand_Create.TabIndex = 2;
            this.Brand_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Brand_Create.Click += new System.EventHandler(this.Brand_Create_Click);
            // 
            // Brand_Edit
            // 
            this.Brand_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Brand_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Brand_Edit.Location = new System.Drawing.Point(57, 0);
            this.Brand_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Brand_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Brand_Edit.Name = "Brand_Edit";
            this.Brand_Edit.Size = new System.Drawing.Size(30, 30);
            this.Brand_Edit.Symbol = 559205;
            this.Brand_Edit.SymbolSize = 32;
            this.Brand_Edit.TabIndex = 3;
            this.Brand_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Brand_Edit.Click += new System.EventHandler(this.Brand_Edit_Click);
            // 
            // Brand_Delete
            // 
            this.Brand_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Brand_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Brand_Delete.Location = new System.Drawing.Point(105, 0);
            this.Brand_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Brand_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Brand_Delete.Name = "Brand_Delete";
            this.Brand_Delete.Size = new System.Drawing.Size(30, 30);
            this.Brand_Delete.Symbol = 559506;
            this.Brand_Delete.SymbolSize = 26;
            this.Brand_Delete.TabIndex = 4;
            this.Brand_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Brand_Delete.Click += new System.EventHandler(this.Brand_Delete_Click);
            // 
            // List_Conditions
            // 
            this.List_Conditions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Conditions.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Conditions.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Conditions.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Conditions.Location = new System.Drawing.Point(723, 30);
            this.List_Conditions.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Conditions.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Conditions.Name = "List_Conditions";
            this.List_Conditions.Padding = new System.Windows.Forms.Padding(2);
            this.List_Conditions.Radius = 1;
            this.List_Conditions.ShowText = false;
            this.List_Conditions.Size = new System.Drawing.Size(242, 583);
            this.List_Conditions.TabIndex = 22;
            this.List_Conditions.Text = "uiListBox1";
            this.List_Conditions.SelectedIndexChanged += new System.EventHandler(this.List_Conditions_SelectedIndexChanged);
            // 
            // HeadLabel_Condition
            // 
            this.HeadLabel_Condition.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.HeadLabel_Condition.AutoSize = true;
            this.HeadLabel_Condition.Font = new System.Drawing.Font("標楷體", 14F);
            this.HeadLabel_Condition.Location = new System.Drawing.Point(819, 6);
            this.HeadLabel_Condition.Name = "HeadLabel_Condition";
            this.HeadLabel_Condition.Size = new System.Drawing.Size(49, 19);
            this.HeadLabel_Condition.TabIndex = 19;
            this.HeadLabel_Condition.Text = "狀態";
            this.HeadLabel_Condition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HeadLabel_Location
            // 
            this.HeadLabel_Location.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.HeadLabel_Location.AutoSize = true;
            this.HeadLabel_Location.Font = new System.Drawing.Font("標楷體", 14F);
            this.HeadLabel_Location.Location = new System.Drawing.Point(499, 6);
            this.HeadLabel_Location.Name = "HeadLabel_Location";
            this.HeadLabel_Location.Size = new System.Drawing.Size(49, 19);
            this.HeadLabel_Location.TabIndex = 18;
            this.HeadLabel_Location.Text = "位罝";
            this.HeadLabel_Location.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HeadLabel_Brand
            // 
            this.HeadLabel_Brand.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.HeadLabel_Brand.AutoSize = true;
            this.HeadLabel_Brand.Font = new System.Drawing.Font("標楷體", 14F);
            this.HeadLabel_Brand.Location = new System.Drawing.Point(179, 6);
            this.HeadLabel_Brand.Name = "HeadLabel_Brand";
            this.HeadLabel_Brand.Size = new System.Drawing.Size(49, 19);
            this.HeadLabel_Brand.TabIndex = 17;
            this.HeadLabel_Brand.Text = "廠牌";
            this.HeadLabel_Brand.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // List_Brands
            // 
            this.List_Brands.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Brands.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Brands.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Brands.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Brands.Location = new System.Drawing.Point(83, 30);
            this.List_Brands.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Brands.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Brands.Name = "List_Brands";
            this.List_Brands.Padding = new System.Windows.Forms.Padding(2);
            this.List_Brands.ShowText = false;
            this.List_Brands.Size = new System.Drawing.Size(242, 583);
            this.List_Brands.TabIndex = 20;
            this.List_Brands.Text = "uiListBox1";
            this.List_Brands.SelectedIndexChanged += new System.EventHandler(this.List_Brands_SelectedIndexChanged);
            // 
            // List_Locations
            // 
            this.List_Locations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Locations.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Locations.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Locations.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Locations.Location = new System.Drawing.Point(403, 30);
            this.List_Locations.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Locations.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Locations.Name = "List_Locations";
            this.List_Locations.Padding = new System.Windows.Forms.Padding(2);
            this.List_Locations.Radius = 1;
            this.List_Locations.ShowText = false;
            this.List_Locations.Size = new System.Drawing.Size(242, 583);
            this.List_Locations.TabIndex = 21;
            this.List_Locations.Text = "uiListBox1";
            this.List_Locations.SelectedIndexChanged += new System.EventHandler(this.List_Locations_SelectedIndexChanged);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.Location_Create);
            this.flowLayoutPanel1.Controls.Add(this.Location_Edit);
            this.flowLayoutPanel1.Controls.Add(this.Location_Delete);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(452, 618);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel1.TabIndex = 24;
            // 
            // Location_Create
            // 
            this.Location_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Location_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Location_Create.Location = new System.Drawing.Point(9, 0);
            this.Location_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Location_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Location_Create.Name = "Location_Create";
            this.Location_Create.Size = new System.Drawing.Size(30, 30);
            this.Location_Create.Symbol = 557669;
            this.Location_Create.SymbolSize = 32;
            this.Location_Create.TabIndex = 2;
            this.Location_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Location_Create.Click += new System.EventHandler(this.Location_Create_Click);
            // 
            // Location_Edit
            // 
            this.Location_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Location_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Location_Edit.Location = new System.Drawing.Point(57, 0);
            this.Location_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Location_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Location_Edit.Name = "Location_Edit";
            this.Location_Edit.Size = new System.Drawing.Size(30, 30);
            this.Location_Edit.Symbol = 559205;
            this.Location_Edit.SymbolSize = 32;
            this.Location_Edit.TabIndex = 3;
            this.Location_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Location_Edit.Click += new System.EventHandler(this.Location_Edit_Click);
            // 
            // Location_Delete
            // 
            this.Location_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Location_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Location_Delete.Location = new System.Drawing.Point(105, 0);
            this.Location_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Location_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Location_Delete.Name = "Location_Delete";
            this.Location_Delete.Size = new System.Drawing.Size(30, 30);
            this.Location_Delete.Symbol = 559506;
            this.Location_Delete.SymbolSize = 26;
            this.Location_Delete.TabIndex = 4;
            this.Location_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Location_Delete.Click += new System.EventHandler(this.Location_Delete_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel2.AutoSize = true;
            this.flowLayoutPanel2.Controls.Add(this.Condition_Create);
            this.flowLayoutPanel2.Controls.Add(this.Condition_Edit);
            this.flowLayoutPanel2.Controls.Add(this.Condition_Delete);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(772, 618);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel2.TabIndex = 25;
            // 
            // Condition_Create
            // 
            this.Condition_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Condition_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Condition_Create.Location = new System.Drawing.Point(9, 0);
            this.Condition_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Condition_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Condition_Create.Name = "Condition_Create";
            this.Condition_Create.Size = new System.Drawing.Size(30, 30);
            this.Condition_Create.Symbol = 557669;
            this.Condition_Create.SymbolSize = 32;
            this.Condition_Create.TabIndex = 2;
            this.Condition_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Condition_Create.Click += new System.EventHandler(this.Condition_Create_Click);
            // 
            // Condition_Edit
            // 
            this.Condition_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Condition_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Condition_Edit.Location = new System.Drawing.Point(57, 0);
            this.Condition_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Condition_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Condition_Edit.Name = "Condition_Edit";
            this.Condition_Edit.Size = new System.Drawing.Size(30, 30);
            this.Condition_Edit.Symbol = 559205;
            this.Condition_Edit.SymbolSize = 32;
            this.Condition_Edit.TabIndex = 3;
            this.Condition_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Condition_Edit.Click += new System.EventHandler(this.Condition_Edit_Click);
            // 
            // Condition_Delete
            // 
            this.Condition_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Condition_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Condition_Delete.Location = new System.Drawing.Point(105, 0);
            this.Condition_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Condition_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Condition_Delete.Name = "Condition_Delete";
            this.Condition_Delete.Size = new System.Drawing.Size(30, 30);
            this.Condition_Delete.Symbol = 559506;
            this.Condition_Delete.SymbolSize = 26;
            this.Condition_Delete.TabIndex = 4;
            this.Condition_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Condition_Delete.Click += new System.EventHandler(this.Condition_Delete_Click);
            // 
            // Setup_MachineBrend
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_MachineBrend";
            this.Size = new System.Drawing.Size(1080, 668);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.tableLayoutPanel_Page.PerformLayout();
            this.flowLayoutPanel6.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private System.Windows.Forms.Label HeadLabel_Condition;
        private System.Windows.Forms.Label HeadLabel_Location;
        private System.Windows.Forms.Label HeadLabel_Brand;
        private Sunny.UI.UIListBox List_Locations;
        private Sunny.UI.UIListBox List_Brands;
        private Sunny.UI.UIListBox List_Conditions;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton Brand_Create;
        private Sunny.UI.UISymbolButton Brand_Edit;
        private Sunny.UI.UISymbolButton Brand_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Sunny.UI.UISymbolButton Location_Create;
        private Sunny.UI.UISymbolButton Location_Edit;
        private Sunny.UI.UISymbolButton Location_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private Sunny.UI.UISymbolButton Condition_Create;
        private Sunny.UI.UISymbolButton Condition_Edit;
        private Sunny.UI.UISymbolButton Condition_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private Sunny.UI.UISymbolButton Condition_Up;
        private Sunny.UI.UISymbolButton Condition_Down;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private Sunny.UI.UISymbolButton Location_Up;
        private Sunny.UI.UISymbolButton Location_Down;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private Sunny.UI.UISymbolButton Brand_Up;
        private Sunny.UI.UISymbolButton Brand_Down;
    }
}
