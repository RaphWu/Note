﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Helper;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachineCategory : UserControl, INavigationAware
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly ILifetimeScope _scope;
        private readonly IEntityCacheManager _cacheManager;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        private readonly DbSet<MachineCategory> _categories;
        private readonly DbSet<MachineType> _types;
        private readonly DbSet<MachineName> _names;

        private List<ListViewModel> _vmCategories = new List<ListViewModel>();
        private ListViewModel _vmCategory = new ListViewModel();
        private List<ListViewModel> _vmTypes = new List<ListViewModel>();
        private ListViewModel _vmType = new ListViewModel();
        private List<ListViewModel> _vmNames = new List<ListViewModel>();
        private ListViewModel _vmName = new ListViewModel();

        private EntityCrudConfig<MachineCategory> _categoryConfig;

        #endregion fields

        public async void OnNavigatedTo()
        {
            await LoadDataAsync();
        }

        public void OnNavigatedFrom()
        {
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();

            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        public Setup_MachineCategory(
            Serilog.ILogger logger,
            ILifetimeScope lifetimeScope,
            IEntityCacheManager cacheManager,
            CoreContext coreContext,
            CoreData coreData)
        {
            InitializeComponent();

            _logger = logger;
            _scope = lifetimeScope;
            _cacheManager = cacheManager;
            _context = coreContext;
            _coreData = coreData;

            _categories = _context.MachineCategories;
            _types = _context.MachineTypes;
            _names = _context.MachineNames;

            string itemName = PropertyText.Title.MachineCategory;
            CommonStyles.SetListBox(List_Categories);
            CommonStyles.SetCrudButton(Category_Create, "C", itemName);
            CommonStyles.SetCrudButton(Category_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Category_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Category_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Category_Down, "DOWN", itemName);

            itemName = PropertyText.Title.MachineType;
            CommonStyles.SetListBox(List_Types);
            CommonStyles.SetCrudButton(Type_Create, "C", itemName);
            CommonStyles.SetCrudButton(Type_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Type_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Type_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Type_Down, "DOWN", itemName);

            itemName = PropertyText.Title.MachineName;
            CommonStyles.SetListBox(List_Names);
            CommonStyles.SetCrudButton(Name_Create, "C", itemName);
            CommonStyles.SetCrudButton(Name_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Name_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Name_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Name_Down, "DOWN", itemName);

            _categoryConfig = new EntityCrudConfig<MachineCategory>
            {
                EntityTypeName = PropertyText.Title.MachineCategory,
                NameSelector = e => e.CategoryName,
                OrderNoSelector = e => e.OrderNo,
                NameGetter = e => e.CategoryName,
                NameSetter = (e, name) => e.CategoryName = name,
                OrderNoGetter = e => e.OrderNo,
                OrderNoSetter = (e, orderNo) => e.OrderNo = orderNo,
                MaxNameLength = 30,
                ExistsChecker = name => _categories.Any(m => m.CategoryName == name),
                EntityFinder = id => _categories.FirstOrDefault(m => m.Id == id),
                EntityFactory = () => new MachineCategory()
            };

            WeakReferenceMessenger.Default.Register<NotifyMachineDataUpdated>(this, async (recipient, message) =>
            {
                await LoadDataAsync();
            });
        }

        private async Task LoadDataAsync()
        {
            await UpdateCategoriesViewAsync();
            await UpdateTypesViewAsync();
            await UpdateNamesViewAsync();
        }

        #region Category

        /********************
         * Category
         ********************/
        private async Task UpdateCategoriesViewAsync()
        {
            var query = await _context.MachineCategories
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmCategories = query
                .Select(b => new ListViewModel
                {
                    Id = b.Id,
                    Name = b.CategoryName,
                    OrderNo = b.OrderNo
                })
                .ToList();
            List_Categories.ValueMember = nameof(ListViewModel.Id);
            List_Categories.DisplayMember = nameof(ListViewModel.Name);
            List_Categories.DataSource = _vmCategories;
        }

        private async void List_Categories_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmCategory = List_Categories.SelectedItem as ListViewModel;
            if (_vmCategory != null)
            {
                Category_Edit.Enabled = true;
                Category_Delete.Enabled = true;

                var vmOrderNo = _vmCategory.OrderNo;
                Category_Up.Enabled = vmOrderNo != _vmCategories.Min(w => w.OrderNo);
                Category_Down.Enabled = vmOrderNo != _vmCategories.Max(w => w.OrderNo);
                HeadLabel_Category.Text = $"{PropertyText.Title.MachineCategory} ({_vmCategories.Count()})";

                await UpdateTypesViewAsync();
            }
            else
            {
                List_Types.DataSource = null;

                Category_Edit.Enabled = false;
                Category_Delete.Enabled = false;
                Category_Up.Enabled = false;
                Category_Down.Enabled = false;
                HeadLabel_Category.Text = $"{PropertyText.Title.MachineCategory} (0)";
            }
        }

        private async void Category_Create_Click(object sender, EventArgs e)
        {
            //await EntityCrudHelper.CreateEntityAsync(
            //    _scope,                          // Autofac scope
            //    _logger,                         // Logger
            //    _context,                        // DbContext
            //    _categories,                     // DbSet
            //    _categoryConfig,                 // 配置物件
            //    _cacheManager,                   // Cache manager
            //    () => _cacheManager.RequestMachineUpdateDelay(),  // Cache 更新動作
            //    UpdateCategoriesViewAsync,            // 更新 View 方法
            //    id => List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == id)  // 選擇新項目
            //);

            string title = $"請輸入新{PropertyText.Title.MachineCategory}名稱";
            string caption = $"新{PropertyText.Title.MachineCategory}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.MachineCategory}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.MachineCategory}名稱必須小於等於 30 個字元！"),
                input => _categories.Any(m => m.CategoryName == input) ? (false, $"{PropertyText.Title.MachineCategory}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newMachineCategoryName = crud.Result.StringValue;
                        int maxOrderNo = _categories.Max(w => w.OrderNo);

                        _context.MachineCategories.Add(new MachineCategory()
                        {
                            CategoryName = newMachineCategoryName,
                            OrderNo = maxOrderNo + 1,
                        });
                        await _context.SaveChangesAsync();
                        await UpdateCategoriesViewAsync();
                        _cacheManager.RequestMachineUpdateDelay();
                        List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Name == newMachineCategoryName);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.MachineCategory}: {newMachineCategoryName}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增{PropertyText.Title.MachineCategory}失敗: {nameof(Setup_MachineCategory)} -> {nameof(Category_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Category_Edit_Click(object sender, EventArgs e)
        {
            //if (_vmCategory != null)
            //{
            //    await EntityCrudHelper.EditEntityAsync(
            //        _scope,                     // Autofac scope
            //        _logger,                    // Logger
            //        _context,                   // DbContext
            //        _categories,                // DbSet
            //        _categoryConfig,            // 配置物件
            //        _cacheManager,              // Cache manager
            //        () => _cacheManager.RequestMachineUpdateDelay(), // Cache 更新動作
            //        UpdateCategoriesViewAsync,  // 更新 View 方法
            //        _vmCategory.Id,             // 實體 ID
            //        _vmCategory.Name,           // 當前名稱
            //        id => List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == id)
            //    );
            //}

            if (_vmCategory != null)
            {
                var thisCategory = _vmCategory;
                string title = $"請輸入新{PropertyText.Title.MachineCategory}名稱";
                string oldCaption = $"原{PropertyText.Title.MachineCategory}名稱";
                string newCaption = $"新{PropertyText.Title.MachineCategory}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.MachineCategory}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.MachineCategory}名稱必須小於等於 30 個字元！"),
                    input => _categories.Any(m => m.CategoryName == input) ? (false, $"{PropertyText.Title.MachineCategory}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = thisCategory.Name,
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = "",
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        try
                        {
                            string newCategoryName = crud.Result.StringValue;

                            var newCategory = _categories.FirstOrDefault(m => m.Id == thisCategory.Id);
                            if (newCategory != null)
                            {
                                newCategory.CategoryName = newCategoryName;
                                await _context.SaveChangesAsync();
                                await UpdateCategoriesViewAsync();
                                _cacheManager.RequestMachineUpdateDelay();
                                List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == newCategory.Id);

                                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.MachineCategory}: {thisCategory.Name}，名稱已變更為: {newCategoryName}"));
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"{PropertyText.Title.MachineCategory}重新命名失敗: {nameof(Setup_MachineCategory)} -> {nameof(Category_Edit_Click)}()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private async void Category_Delete_Click(object sender, EventArgs e)
        {
            //if (_vmCategory != null)
            //{
            //    await EntityCrudHelper.DeleteEntityAsync(
            //        _logger,                // Logger
            //        _context,               // DbContext
            //        _categories,            // DbSet
            //        _categoryConfig,        // 配置物件
            //        _cacheManager,          // Cache manager
            //        () => _cacheManager.RequestMachineUpdateDelay(), // Cache 更新動作
            //        UpdateCategoriesViewAsync,   // 更新 View 方法
            //        _vmCategory.Id,         // 實體 ID
            //        _vmCategory.Name        // 當前名稱
            //    );
            //}


            if (_vmCategory != null)
            {
                var thisCategory = _vmCategory;
                if (UIMessageBox.ShowAsk2($"確定要刪除嗎？ {PropertyText.Title.MachineCategory}: {thisCategory.Name}",
                    true,
                    UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetCategory = _categories.FirstOrDefault(m => m.Id == thisCategory.Id);
                        if (targetCategory != null)
                        {
                            _categories.Remove(targetCategory);
                            await _context.SaveChangesAsync();
                            await UpdateCategoriesViewAsync();
                            _cacheManager.RequestMachineUpdateDelay();

                            MessageBox.Show($"{PropertyText.Title.MachineCategory}: {thisCategory.Name} 刪除成功！",
                                "刪除成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.MachineCategory}刪除失敗: {nameof(Setup_MachineCategory)} -> {nameof(Category_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Category_Up_Click(object sender, EventArgs e)
        {
            if (_vmCategory != null)
            {
                var thisVmWs = _vmCategory;
                var smallerVmWs = _vmCategories.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapCategoryOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Category_Down_Click(object sender, EventArgs e)
        {
            if (_vmCategory != null)
            {
                var thisVm = _vmCategory;
                var biggerVm = _vmCategories.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapCategoryOrderNo(thisVm.Id, biggerVm.Id);
                    List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapCategoryOrderNo(int id1, int id2)
        {
            try
            {
                var entity1 = _categories.FirstOrDefault(w => w.Id == id1);
                var entity2 = _categories.FirstOrDefault(w => w.Id == id2);

                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateCategoriesViewAsync();
                _cacheManager.RequestMachineUpdateDelay();
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_MachineBrend)} -> {nameof(SwapCategoryOrderNo)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //private async void Category_Up_Click(object sender, EventArgs e)
        //{
        //    await EntityCrudHelper.HandleUpClickAsync<ListViewModel, MachineCategory>(
        //        _logger,                    // Logger
        //        _context,                   // DbContext
        //        _categoryConfig,            // 配置物件
        //        _cacheManager,              // Cache manager
        //        () => _cacheManager.RequestMachineUpdateDelay(), // Cache 更新動作
        //        UpdateCategoriesViewAsync,  // 更新 View 方法
        //        _vmCategories,              // 所有檢視模型的清單
        //        _vmCategory,                // 目前選取的檢視模型
        //        vm => vm.OrderNo,           // 取得排序編號的函式
        //        vm => vm.Id,                // 取得 ID 的函式
        //        id => List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == id) // 選取項目的動作
        //    );
        //}

        //private async void Category_Down_Click(object sender, EventArgs e)
        //{
        //    await EntityCrudHelper.HandleDownClickAsync<ListViewModel, MachineCategory>(
        //        _logger,                    // Logger
        //        _context,                   // DbContext
        //        _categoryConfig,            // 配置物件
        //        _cacheManager,              // Cache manager
        //        () => _cacheManager.RequestMachineUpdateDelay(), // Cache 更新動作
        //        UpdateCategoriesViewAsync,  // 更新 View 方法
        //        _vmCategories,              // 所有檢視模型的清單
        //        _vmCategory,                // 目前選取的檢視模型
        //        vm => vm.OrderNo,           // 取得排序編號的函式
        //        vm => vm.Id,                // 取得 ID 的函式
        //        id => List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == id) // 選取項目的動作
        //    );
        //}

        //private async Task<bool> SwapCategoryOrderNo(int id1, int id2)
        //{
        //    try
        //    {
        //        var entity1 = _categories.FirstOrDefault(w => w.Id == id1);
        //        var entity2 = _categories.FirstOrDefault(w => w.Id == id2);

        //        (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
        //        await _context.SaveChangesAsync();
        //        await UpdateCategoriesViewAsync();
        //        _cacheManager.RequestMachineUpdateDelay();
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        string errMsg = $"順序調整失敗: {nameof(Setup_MachineCategory)} -> {nameof(SwapCategoryOrderNo)}()";
        //        using (LogContext.PushProperty("Category", "Database"))
        //        {
        //            _logger.Fatal(ex, errMsg);
        //        }
        //        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        return false;
        //    }
        //}

        #endregion Category

        #region Type

        /********************
         * TypeName
         ********************/
        private async Task UpdateTypesViewAsync()
        {
            List_Types.DataSource = null;
            if (_vmCategory != null)
            {
                var query = await _context.MachineTypes
                    .Where(m => m.CategoryId == _vmCategory.Id)
                    .OrderBy(b => b.OrderNo)
                    .ToListAsync();
                _vmTypes = query
                    .Select(b => new ListViewModel { Id = b.Id, Name = b.TypeName, OrderNo = b.OrderNo })
                    .ToList();
                List_Types.ValueMember = nameof(ListViewModel.Id);
                List_Types.DisplayMember = nameof(ListViewModel.Name);
                List_Types.DataSource = _vmTypes;
            }
            else
            {
                _vmTypes = null;
            }
        }

        private async void List_Types_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmType = List_Types.SelectedItem as ListViewModel;
            if (_vmType != null)
            {
                Type_Edit.Enabled = true;
                Type_Delete.Enabled = true;

                var vmOrderNo = _vmType.OrderNo;
                Type_Up.Enabled = vmOrderNo != _vmTypes.Min(w => w.OrderNo);
                Type_Down.Enabled = vmOrderNo != _vmTypes.Max(w => w.OrderNo);
                HeadLabel_Type.Text = $"{PropertyText.Title.MachineType} ({_vmTypes.Count()})";

                await UpdateNamesViewAsync();
            }
            else
            {
                List_Names.DataSource = null;

                Type_Edit.Enabled = false;
                Type_Delete.Enabled = false;
                Type_Up.Enabled = false;
                Type_Down.Enabled = false;
                HeadLabel_Type.Text = $"{PropertyText.Title.MachineType} (0)";
            }
        }

        private async void Type_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.MachineType}名稱";
            string caption = $"新{PropertyText.Title.MachineType}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.MachineType}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.MachineType}名稱必須小於等於 30 個字元！"),
                input => _types.Any(m => m.TypeName == input) ? (false, $"{PropertyText.Title.MachineType}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newTypeName = crud.Result.StringValue;
                        int maxOrderNo = _types.Max(w => w.OrderNo);

                        _context.MachineTypes.Add(new MachineType()
                        {
                            TypeName = newTypeName,
                            CategoryId = _vmCategory.Id,
                            OrderNo = maxOrderNo + 1
                        });
                        await _context.SaveChangesAsync();
                        await UpdateTypesViewAsync();
                        _cacheManager.RequestMachineUpdateDelay();
                        List_Types.SelectedIndex = _vmTypes.FindIndex(m => m.Name == newTypeName);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.MachineType}: {newTypeName}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增{PropertyText.Title.MachineType}失敗: {nameof(Setup_MachineCategory)} -> {nameof(Type_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Type_Edit_Click(object sender, EventArgs e)
        {
            if (_vmType != null)
            {
                var thisType = _vmType;
                string title = $"請輸入新{PropertyText.Title.MachineType}名稱";
                string oldCaption = $"原{PropertyText.Title.MachineType}名稱";
                string newCaption = $"新{PropertyText.Title.MachineType}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.MachineType}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.MachineType}名稱必須小於等於 30 個字元！"),
                    input => _types.Any(m => m.TypeName == input) ? (false, $"{PropertyText.Title.MachineType}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = thisType.Name,
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = "",
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        try
                        {
                            string newTypeName = crud.Result.StringValue;

                            var newType = _types.FirstOrDefault(m => m.Id == thisType.Id);
                            if (newType != null)
                            {
                                newType.TypeName = newTypeName;
                                await _context.SaveChangesAsync();
                                await UpdateTypesViewAsync();
                                _cacheManager.RequestMachineUpdateDelay();
                                List_Types.SelectedIndex = _vmTypes.FindIndex(m => m.Id == newType.Id);

                                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.MachineType}: {thisType.Name}，名稱已變更為: {newTypeName}"));
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"{PropertyText.Title.MachineType}重新命名失敗: {nameof(Setup_MachineCategory)} -> {nameof(Type_Edit_Click)}()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private async void Type_Delete_Click(object sender, EventArgs e)
        {
            if (_vmType != null)
            {
                var thisType = _vmType;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {PropertyText.Title.MachineType} {thisType.Name} 嗎？",
                    true,
                    UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetType = _types.FirstOrDefault(m => m.Id == thisType.Id);
                        if (targetType != null)
                        {
                            _types.Remove(targetType);
                            await _context.SaveChangesAsync();
                            await UpdateTypesViewAsync();
                            _cacheManager.RequestMachineUpdateDelay();

                            MessageBox.Show($"{PropertyText.Title.MachineType}: {thisType.Name} 刪除成功！",
                                "刪除成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.MachineType}刪除失敗: {nameof(Setup_MachineCategory)} -> {nameof(Type_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Type_Up_Click(object sender, EventArgs e)
        {
            if (_vmType != null)
            {
                var thisVmWs = _vmType;
                var smallerVmWs = _vmTypes.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapTypeOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Types.SelectedIndex = _vmTypes.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Type_Down_Click(object sender, EventArgs e)
        {
            if (_vmType != null)
            {
                var thisVm = _vmType;
                var biggerVm = _vmTypes.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapTypeOrderNo(thisVm.Id, biggerVm.Id);
                    List_Types.SelectedIndex = _vmTypes.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapTypeOrderNo(int id1, int id2)
        {
            try
            {
                var entity1 = _types.FirstOrDefault(w => w.Id == id1);
                var entity2 = _types.FirstOrDefault(w => w.Id == id2);

                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateTypesViewAsync();
                _cacheManager.RequestMachineUpdateDelay();
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_MachineCategory)} -> {nameof(SwapTypeOrderNo)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion Type

        #region Name

        /********************
         * Names
         ********************/
        private async Task UpdateNamesViewAsync()
        {
            List_Names.DataSource = null;
            if (_vmType != null)
            {
                var query = await _context.MachineNames
                    .Where(m => m.TypeId == _vmType.Id)
                    .ToListAsync();
                _vmNames = query
                    .Select(b => new ListViewModel { Id = b.Id, Name = b.ModelName, OrderNo = b.OrderNo })
                    .ToList();
                List_Names.ValueMember = nameof(ListViewModel.Id);
                List_Names.DisplayMember = nameof(ListViewModel.Name);
                List_Names.DataSource = _vmNames;
            }
            else
            {
                _vmNames = null;
            }
        }

        private void List_Names_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmName = List_Names.SelectedItem as ListViewModel;
            if (_vmName != null)
            {
                Name_Edit.Enabled = true;
                Name_Delete.Enabled = true;

                var vmOrderNo = _vmName.OrderNo;
                Name_Up.Enabled = vmOrderNo != _vmNames.Min(w => w.OrderNo);
                Name_Down.Enabled = vmOrderNo != _vmNames.Max(w => w.OrderNo);
                HeadLabel_Name.Text = $"{PropertyText.Title.MachineName} ({_vmNames.Count()})";
            }
            else
            {
                Name_Edit.Enabled = false;
                Name_Delete.Enabled = false;
                Name_Up.Enabled = false;
                Name_Down.Enabled = false;
                HeadLabel_Name.Text = $"{PropertyText.Title.MachineName} (0)";
            }
        }

        private async void Name_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.MachineName}名稱";
            string caption = $"新{PropertyText.Title.MachineName}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.MachineName}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.MachineName}名稱必須小於等於 30 個字元！"),
                input => _names.Any(m => m.ModelName == input) ? (false, $"{PropertyText.Title.MachineName}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newNameName = crud.Result.StringValue;
                        int maxOrderNo = _names.Max(w => w.OrderNo);

                        _context.MachineNames.Add(new MachineName()
                        {
                            ModelName = newNameName,
                            TypeId = _vmType.Id,
                            OrderNo = maxOrderNo + 1,
                        });
                        await _context.SaveChangesAsync();
                        await UpdateNamesViewAsync();
                        _cacheManager.RequestMachineUpdateDelay();
                        List_Names.SelectedIndex = _vmNames.FindIndex(m => m.Name == newNameName);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.MachineName}: {newNameName}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增{PropertyText.Title.MachineName}失敗: {nameof(Setup_MachineCategory)} -> {nameof(Name_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Name_Edit_Click(object sender, EventArgs e)
        {
            if (_vmName != null)
            {
                var thisName = _vmName;
                string title = $"請輸入新{PropertyText.Title.MachineName}名稱";
                string oldCaption = $"原{PropertyText.Title.MachineName}名稱";
                string newCaption = $"新{PropertyText.Title.MachineName}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.MachineName}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.MachineName}名稱必須小於等於 30 個字元！"),
                    input => _names.Any(m => m.ModelName == input) ? (false, $"{PropertyText.Title.MachineName}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = thisName.Name,
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = "",
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        try
                        {
                            string newNameName = crud.Result.StringValue;

                            var newName = _names.FirstOrDefault(m => m.Id == thisName.Id);
                            if (newName != null)
                            {
                                newName.ModelName = newNameName;
                                await _context.SaveChangesAsync();
                                await UpdateNamesViewAsync();
                                _cacheManager.RequestMachineUpdateDelay();
                                List_Names.SelectedIndex = _vmNames.FindIndex(m => m.Id == newName.Id);

                                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.MachineName}: {thisName.Name}，名稱已變更為: {newNameName}"));
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"{PropertyText.Title.MachineName}重新命名失敗: {nameof(Setup_MachineCategory)} -> {nameof(Name_Edit_Click)}()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private async void Name_Delete_Click(object sender, EventArgs e)
        {
            if (_vmName != null)
            {
                var thisName = _vmName;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {PropertyText.Title.MachineName} {thisName.Name} 嗎？",
                    true,
                    UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetName = _names.FirstOrDefault(m => m.Id == thisName.Id);
                        if (targetName != null)
                        {
                            _names.Remove(targetName);
                            await _context.SaveChangesAsync();
                            await UpdateNamesViewAsync();
                            _cacheManager.RequestMachineUpdateDelay();

                            MessageBox.Show($"{PropertyText.Title.MachineName}: {thisName.Name} 刪除成功！",
                                "刪除成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.MachineName}刪除失敗: {nameof(Setup_MachineCategory)} -> {nameof(Name_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Name_Up_Click(object sender, EventArgs e)
        {
            if (_vmName != null)
            {
                var thisVmWs = _vmName;
                var smallerVmWs = _vmNames.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapNameOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Names.SelectedIndex = _vmNames.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Name_Down_Click(object sender, EventArgs e)
        {
            if (_vmName != null)
            {
                var thisVm = _vmName;
                var biggerVm = _vmNames.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapNameOrderNo(thisVm.Id, biggerVm.Id);
                    List_Names.SelectedIndex = _vmNames.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapNameOrderNo(int id1, int id2)
        {
            try
            {
                var entity1 = _names.FirstOrDefault(w => w.Id == id1);
                var entity2 = _names.FirstOrDefault(w => w.Id == id2);

                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateNamesViewAsync();
                _cacheManager.RequestMachineUpdateDelay();
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_MachineCategory)} -> {nameof(SwapNameOrderNo)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion Name
    }
}
