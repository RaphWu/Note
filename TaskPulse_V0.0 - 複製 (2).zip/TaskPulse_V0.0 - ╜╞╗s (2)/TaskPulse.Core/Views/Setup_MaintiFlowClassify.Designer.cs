﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_MaintiFlowClassify
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.HeadLabel_IssueCategory = new System.Windows.Forms.Label();
            this.List_IssueCategories = new Sunny.UI.UIListBox();
            this.IssueCategory_Create = new Sunny.UI.UISymbolButton();
            this.IssueCategory_Edit = new Sunny.UI.UISymbolButton();
            this.IssueCategory_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.IssueCategory_Up = new Sunny.UI.UISymbolButton();
            this.IssueCategory_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // HeadLabel_IssueCategory
            // 
            this.HeadLabel_IssueCategory.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.HeadLabel_IssueCategory.AutoSize = true;
            this.HeadLabel_IssueCategory.Font = new System.Drawing.Font("標楷體", 14F);
            this.HeadLabel_IssueCategory.Location = new System.Drawing.Point(179, 6);
            this.HeadLabel_IssueCategory.Name = "HeadLabel_IssueCategory";
            this.HeadLabel_IssueCategory.Size = new System.Drawing.Size(49, 19);
            this.HeadLabel_IssueCategory.TabIndex = 17;
            this.HeadLabel_IssueCategory.Text = "廠牌";
            this.HeadLabel_IssueCategory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // List_IssueCategories
            // 
            this.List_IssueCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_IssueCategories.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_IssueCategories.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_IssueCategories.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_IssueCategories.Location = new System.Drawing.Point(83, 30);
            this.List_IssueCategories.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_IssueCategories.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_IssueCategories.Name = "List_IssueCategories";
            this.List_IssueCategories.Padding = new System.Windows.Forms.Padding(2);
            this.List_IssueCategories.ShowText = false;
            this.List_IssueCategories.Size = new System.Drawing.Size(242, 573);
            this.List_IssueCategories.TabIndex = 20;
            this.List_IssueCategories.Text = "uiListBox1";
            this.List_IssueCategories.SelectedIndexChanged += new System.EventHandler(this.List_IssueCategories_SelectedIndexChanged);
            // 
            // IssueCategory_Create
            // 
            this.IssueCategory_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IssueCategory_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory_Create.Location = new System.Drawing.Point(9, 0);
            this.IssueCategory_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.IssueCategory_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueCategory_Create.Name = "IssueCategory_Create";
            this.IssueCategory_Create.Size = new System.Drawing.Size(30, 30);
            this.IssueCategory_Create.Symbol = 557669;
            this.IssueCategory_Create.SymbolSize = 32;
            this.IssueCategory_Create.TabIndex = 2;
            this.IssueCategory_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.IssueCategory_Create.Click += new System.EventHandler(this.IssueCategory_Create_Click);
            // 
            // IssueCategory_Edit
            // 
            this.IssueCategory_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IssueCategory_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory_Edit.Location = new System.Drawing.Point(57, 0);
            this.IssueCategory_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.IssueCategory_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueCategory_Edit.Name = "IssueCategory_Edit";
            this.IssueCategory_Edit.Size = new System.Drawing.Size(30, 30);
            this.IssueCategory_Edit.Symbol = 559205;
            this.IssueCategory_Edit.SymbolSize = 32;
            this.IssueCategory_Edit.TabIndex = 3;
            this.IssueCategory_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.IssueCategory_Edit.Click += new System.EventHandler(this.IssueCategory_Edit_Click);
            // 
            // IssueCategory_Delete
            // 
            this.IssueCategory_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IssueCategory_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory_Delete.Location = new System.Drawing.Point(105, 0);
            this.IssueCategory_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.IssueCategory_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueCategory_Delete.Name = "IssueCategory_Delete";
            this.IssueCategory_Delete.Size = new System.Drawing.Size(30, 30);
            this.IssueCategory_Delete.Symbol = 559506;
            this.IssueCategory_Delete.SymbolSize = 26;
            this.IssueCategory_Delete.TabIndex = 4;
            this.IssueCategory_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.IssueCategory_Delete.Click += new System.EventHandler(this.IssueCategory_Delete_Click);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.Controls.Add(this.IssueCategory_Create);
            this.flowLayoutPanel4.Controls.Add(this.IssueCategory_Edit);
            this.flowLayoutPanel4.Controls.Add(this.IssueCategory_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(132, 608);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 23;
            // 
            // IssueCategory_Up
            // 
            this.IssueCategory_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IssueCategory_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory_Up.Location = new System.Drawing.Point(0, 9);
            this.IssueCategory_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.IssueCategory_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueCategory_Up.Name = "IssueCategory_Up";
            this.IssueCategory_Up.Size = new System.Drawing.Size(30, 30);
            this.IssueCategory_Up.Symbol = 361702;
            this.IssueCategory_Up.SymbolSize = 32;
            this.IssueCategory_Up.TabIndex = 2;
            this.IssueCategory_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.IssueCategory_Up.Click += new System.EventHandler(this.IssueCategory_Up_Click);
            // 
            // IssueCategory_Down
            // 
            this.IssueCategory_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IssueCategory_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory_Down.Location = new System.Drawing.Point(0, 57);
            this.IssueCategory_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.IssueCategory_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueCategory_Down.Name = "IssueCategory_Down";
            this.IssueCategory_Down.Size = new System.Drawing.Size(30, 30);
            this.IssueCategory_Down.Symbol = 361703;
            this.IssueCategory_Down.SymbolSize = 32;
            this.IssueCategory_Down.TabIndex = 4;
            this.IssueCategory_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.IssueCategory_Down.Click += new System.EventHandler(this.IssueCategory_Down_Click);
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel3.AutoSize = true;
            this.flowLayoutPanel3.Controls.Add(this.IssueCategory_Up);
            this.flowLayoutPanel3.Controls.Add(this.IssueCategory_Down);
            this.flowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(46, 145);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel3.TabIndex = 26;
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 8;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel3, 1, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel4, 2, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.HeadLabel_IssueCategory, 2, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.List_IssueCategories, 2, 1);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 3;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(1197, 658);
            this.tableLayoutPanel_Page.TabIndex = 1;
            // 
            // Setup_MaintiFlowClassify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Setup_MaintiFlowClassify";
            this.Size = new System.Drawing.Size(1197, 658);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.tableLayoutPanel_Page.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label HeadLabel_IssueCategory;
        private Sunny.UI.UIListBox List_IssueCategories;
        private Sunny.UI.UISymbolButton IssueCategory_Create;
        private Sunny.UI.UISymbolButton IssueCategory_Edit;
        private Sunny.UI.UISymbolButton IssueCategory_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton IssueCategory_Up;
        private Sunny.UI.UISymbolButton IssueCategory_Down;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
    }
}
