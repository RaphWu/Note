﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;
using Sunny.UI.Win32;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachineBrend : UserControl, INavigationAware
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly ILifetimeScope _scope;
        private readonly IEntityCacheManager _cacheManager;
        private readonly CoreContext _context;

        private readonly DbSet<MachineBrand> _brands;
        private readonly DbSet<MachineLocation> _locations;
        private readonly DbSet<MachineCondition> _conditions;

        private List<ListViewModel> _vmBrands = null;
        private ListViewModel _vmBrand = null;
        private List<ListViewModel> _vmLocs = null;
        private ListViewModel _vmLoc = null;
        private List<ListViewModel> _vmConds = null;
        private ListViewModel _vmCond = null;

        #endregion fields

        public async void OnNavigatedTo()
        {
            await LoadDataAsync();
        }

        public void OnNavigatedFrom()
        {
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();

            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        public Setup_MachineBrend(
            Serilog.ILogger logger,
            ILifetimeScope lifetimeScope,
            IEntityCacheManager cacheManager,
            CoreContext coreContext)
        {
            InitializeComponent();

            _logger = logger;
            _scope = lifetimeScope;
            _cacheManager = cacheManager;
            _context = coreContext;

            _brands = _context.MachineBrands;
            _locations = _context.MachineLocations;
            _conditions = _context.MachineConditions;

            string itemName = PropertyText.Title.Brand;
            CommonStyles.SetListBox(List_Brands);
            CommonStyles.SetCrudButton(Brand_Create, "C", itemName);
            CommonStyles.SetCrudButton(Brand_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Brand_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Brand_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Brand_Down, "DOWN", itemName);

            itemName = PropertyText.Title.Location;
            CommonStyles.SetListBox(List_Locations);
            CommonStyles.SetCrudButton(Location_Create, "C", itemName);
            CommonStyles.SetCrudButton(Location_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Location_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Location_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Location_Down, "DOWN", itemName);

            itemName = PropertyText.Title.Condition;
            CommonStyles.SetListBox(List_Conditions);
            CommonStyles.SetCrudButton(Condition_Create, "C", itemName);
            CommonStyles.SetCrudButton(Condition_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Condition_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Condition_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Condition_Down, "DOWN", itemName);

            WeakReferenceMessenger.Default.Register<NotifyMachineDataUpdated>(this, async (recipient, message) =>
            {
                await LoadDataAsync();
            });
        }

        private async Task LoadDataAsync()
        {
            await UpdateBrandsViewAsync();
            await UpdateLocationsViewAsync();
            await UpdateConditionsViewAsync();
        }

        #region Brand

        private async Task UpdateBrandsViewAsync()
        {
            var query = await _brands
                .OrderBy(b => b.OrderNo)
                .AsNoTracking()
                .ToListAsync();
            _vmBrands = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.BrandName, OrderNo = b.OrderNo })
                .ToList();
            List_Brands.DataSource = null;
            List_Brands.ValueMember = nameof(ListViewModel.Id);
            List_Brands.DisplayMember = nameof(ListViewModel.Name);
            List_Brands.DataSource = _vmBrands;
            HeadLabel_Brand.Text = $"{PropertyText.Title.Brand} ({_vmBrands.Count})";
        }

        private void List_Brands_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmBrand = List_Brands.SelectedItem as ListViewModel;
            if (_vmBrand != null)
            {
                Brand_Edit.Enabled = true;
                Brand_Delete.Enabled = true;

                if (List_Brands.DataSource is List<ListViewModel> vmBrands)
                {
                    var vmOrderNo = vmBrands.FirstOrDefault(w => w.Id == _vmBrand.Id).OrderNo;
                    Brand_Up.Enabled = vmOrderNo != vmBrands.Min(w => w.OrderNo);
                    Brand_Down.Enabled = vmOrderNo != vmBrands.Max(w => w.OrderNo);
                }
                else
                {
                    Brand_Up.Enabled = false;
                    Brand_Down.Enabled = false;
                }
            }
            else
            {
                Brand_Edit.Enabled = false;
                Brand_Delete.Enabled = false;
                Brand_Up.Enabled = false;
                Brand_Down.Enabled = false;
            }
        }

        private async void Brand_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.Brand}名稱";
            string caption = $"新{PropertyText.Title.Brand}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Brand}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.Brand}名稱必須小於等於 30 個字元！"),
                input => _brands.Any(m => m.BrandName == input) ? (false, $"{PropertyText.Title.Brand}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);

                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newBrandName = crud.Result.StringValue;
                        int maxOrderNo = _brands.Max(w => w.OrderNo);

                        _context.MachineBrands.Add(new MachineBrand() { BrandName = newBrandName, OrderNo = maxOrderNo + 1 });
                        await _context.SaveChangesAsync();
                        await UpdateBrandsViewAsync();
                        _cacheManager.RequestMachineUpdateDelay();
                        List_Brands.SelectedIndex = _vmBrands.FindIndex(m => m.Name == newBrandName);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.Brand}: {newBrandName}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增{PropertyText.Title.Brand}失敗: {nameof(Setup_MachineBrend)} -> {nameof(Brand_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Brand_Edit_Click(object sender, EventArgs e)
        {
            if (_vmBrand != null)
            {
                var thisBrand = _vmBrand;
                string title = $"請輸入新{PropertyText.Title.Brand}名稱";
                string oldCaption = $"原{PropertyText.Title.Brand}名稱";
                string newCaption = $"新{PropertyText.Title.Brand}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Brand}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.Brand}名稱必須小於等於 30 個字元！"),
                    input => _brands.Any(m => m.BrandName == input) ? (false, $"{PropertyText.Title.Brand}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = thisBrand.Name,
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = "",
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        try
                        {
                            string newBrandName = crud.Result.StringValue;

                            var newBrand = _brands.FirstOrDefault(m => m.Id == thisBrand.Id);
                            if (newBrand != null)
                            {
                                newBrand.BrandName = newBrandName;
                                await _context.SaveChangesAsync();
                                await UpdateBrandsViewAsync();
                                _cacheManager.RequestMachineUpdateDelay();
                                List_Brands.SelectedIndex = _vmBrands.FindIndex(m => m.Id == newBrand.Id);

                                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.Brand}: {thisBrand.Name}，名稱已變更為: {newBrandName}"));
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"{PropertyText.Title.Brand}重新命名失敗: {nameof(Setup_MachineBrend)} -> {nameof(Brand_Edit_Click)}()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private async void Brand_Delete_Click(object sender, EventArgs e)
        {
            if (_vmBrand != null)
            {
                var thisBrand = _vmBrand;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {PropertyText.Title.Brand} {thisBrand.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetBrand = _brands.FirstOrDefault(m => m.Id == thisBrand.Id);
                        if (targetBrand != null)
                        {
                            _brands.Remove(targetBrand);
                            await _context.SaveChangesAsync();
                            await UpdateBrandsViewAsync();
                            _cacheManager.RequestMachineUpdateDelay();

                            MessageBox.Show($"{PropertyText.Title.Brand}: {thisBrand.Name} 刪除成功",
                                "刪除成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.Brand}刪除失敗: {nameof(Setup_MachineBrend)} -> {nameof(Brand_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Brand_Up_Click(object sender, EventArgs e)
        {
            if (_vmBrand != null)
            {
                var thisVmWs = _vmBrand;
                var smallerVmWs = _vmBrands.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapBrandOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Brands.SelectedIndex = _vmBrands.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Brand_Down_Click(object sender, EventArgs e)
        {
            if (_vmBrand != null)
            {
                var thisVm = _vmBrand;
                var biggerVm = _vmBrands.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapBrandOrderNo(thisVm.Id, biggerVm.Id);
                    List_Brands.SelectedIndex = _vmBrands.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapBrandOrderNo(int id1, int id2)
        {
            try
            {
                var entity1 = _brands.FirstOrDefault(w => w.Id == id1);
                var entity2 = _brands.FirstOrDefault(w => w.Id == id2);

                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateBrandsViewAsync();
                _cacheManager.RequestMachineUpdateDelay();
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_MachineBrend)} -> {nameof(SwapBrandOrderNo)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion Brand

        #region Location

        private async Task UpdateLocationsViewAsync()
        {
            var query = await _locations
            .OrderBy(b => b.OrderNo)
            .AsNoTracking()
            .ToListAsync();
            _vmLocs = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.LocationName, OrderNo = b.OrderNo })
                .ToList();
            List_Locations.DataSource = null;
            List_Locations.ValueMember = nameof(ListViewModel.Id);
            List_Locations.DisplayMember = nameof(ListViewModel.Name);
            List_Locations.DataSource = _vmLocs;
            HeadLabel_Location.Text = $"{PropertyText.Title.Location} ({_vmLocs.Count})";
        }

        private void List_Locations_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmLoc = List_Locations.SelectedItem as ListViewModel;
            if (_vmLoc != null)
            {
                Location_Edit.Enabled = true;
                Location_Delete.Enabled = true;

                if (List_Locations.DataSource is List<ListViewModel> vmLocation)
                {
                    var vmOrderNo = vmLocation.FirstOrDefault(w => w.Id == _vmLoc.Id).OrderNo;
                    Location_Up.Enabled = vmOrderNo != vmLocation.Min(w => w.OrderNo);
                    Location_Down.Enabled = vmOrderNo != vmLocation.Max(w => w.OrderNo);
                }
                else
                {
                    Location_Up.Enabled = false;
                    Location_Down.Enabled = false;
                }
            }
            else
            {
                Location_Edit.Enabled = false;
                Location_Delete.Enabled = false;
                Location_Up.Enabled = false;
                Location_Down.Enabled = false;
            }
        }

        private async void Location_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.Location}名稱";
            string caption = $"新{PropertyText.Title.Location}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Location}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.Location}名稱必須小於等於 30 個字元！"),
                input => _locations.Any(m => m.LocationName == input) ? (false, $"{PropertyText.Title.Location}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);

                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newLocationName = crud.Result.StringValue;
                        int maxOrderNo = _locations.Max(w => w.OrderNo);

                        _context.MachineLocations.Add(new MachineLocation() { LocationName = newLocationName, OrderNo = maxOrderNo + 1 });
                        await _context.SaveChangesAsync();
                        await UpdateLocationsViewAsync();
                        _cacheManager.RequestMachineUpdateDelay();
                        List_Locations.SelectedIndex = _vmLocs.FindIndex(m => m.Name == newLocationName);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.Location}: {newLocationName}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增{PropertyText.Title.Location}失敗: {nameof(Setup_MachineBrend)} -> {nameof(Location_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Location_Edit_Click(object sender, EventArgs e)
        {
            if (_vmLoc != null)
            {
                var thisLocation = _vmLoc;
                string title = $"請輸入新{PropertyText.Title.Location}名稱";
                string oldCaption = $"原{PropertyText.Title.Location}名稱";
                string newCaption = $"新{PropertyText.Title.Location}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Location}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.Location}名稱必須小於等於 30 個字元！"),
                    input => _locations.Any(m => m.LocationName == input) ? (false, $"{PropertyText.Title.Location}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = thisLocation.Name,
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = "",
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        try
                        {
                            string newLocationName = crud.Result.StringValue;

                            var newLocation = _locations.FirstOrDefault(m => m.Id == thisLocation.Id);
                            if (newLocation != null)
                            {
                                newLocation.LocationName = newLocationName;
                                await _context.SaveChangesAsync();
                                await UpdateLocationsViewAsync();
                                _cacheManager.RequestMachineUpdateDelay();
                                List_Locations.SelectedIndex = _vmLocs.FindIndex(m => m.Id == newLocation.Id);

                                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.Location}: {thisLocation.Name}，名稱已變更為: {newLocationName}"));
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"{PropertyText.Title.Location}重新命名失敗: {nameof(Setup_MachineBrend)} -> {nameof(Location_Edit_Click)}()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private async void Location_Delete_Click(object sender, EventArgs e)
        {
            if (_vmLoc != null)
            {
                var thisLocation = _vmLoc;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {PropertyText.Title.Location} {thisLocation.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetLocation = _locations.FirstOrDefault(m => m.Id == thisLocation.Id);
                        if (targetLocation != null)
                        {
                            _locations.Remove(targetLocation);
                            await _context.SaveChangesAsync();
                            await UpdateLocationsViewAsync();
                            _cacheManager.RequestMachineUpdateDelay();

                            MessageBox.Show($"{PropertyText.Title.Location}: {thisLocation.Name} 刪除成功",
                                "刪除成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.Location}刪除失敗: {nameof(Setup_MachineBrend)} -> {nameof(Location_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Location_Up_Click(object sender, EventArgs e)
        {
            if (_vmLoc != null)
            {
                var thisVmWs = _vmLoc;
                var smallerVmWs = _vmLocs.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapLocationOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Locations.SelectedIndex = _vmLocs.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Location_Down_Click(object sender, EventArgs e)
        {
            if (_vmLoc != null)
            {
                var thisVm = _vmLoc;
                var biggerVm = _vmLocs.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapLocationOrderNo(thisVm.Id, biggerVm.Id);
                    List_Locations.SelectedIndex = _vmLocs.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapLocationOrderNo(int id1, int id2)
        {
            try
            {
                var entity1 = _locations.FirstOrDefault(w => w.Id == id1);
                var entity2 = _locations.FirstOrDefault(w => w.Id == id2);

                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateLocationsViewAsync();
                _cacheManager.RequestMachineUpdateDelay();
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_MachineBrend)} -> {nameof(SwapLocationOrderNo)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion Location

        #region Condition

        private async Task UpdateConditionsViewAsync()
        {
            var query = await _conditions
            .OrderBy(b => b.OrderNo)
            .AsNoTracking()
            .ToListAsync();
            _vmConds = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.ConditionName, OrderNo = b.OrderNo })
                .ToList();
            List_Conditions.DataSource = null;
            List_Conditions.ValueMember = nameof(ListViewModel.Id);
            List_Conditions.DisplayMember = nameof(ListViewModel.Name);
            List_Conditions.DataSource = _vmConds;
            HeadLabel_Condition.Text = $"{PropertyText.Title.Condition} ({_vmConds.Count})";
        }

        private void List_Conditions_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmCond = List_Conditions.SelectedItem as ListViewModel;
            if (_vmCond != null)
            {
                Condition_Edit.Enabled = true;
                Condition_Delete.Enabled = true;

                if (List_Conditions.DataSource is List<ListViewModel> vmCondition)
                {
                    var vmOrderNo = vmCondition.FirstOrDefault(w => w.Id == _vmCond.Id).OrderNo;
                    Condition_Up.Enabled = vmOrderNo != vmCondition.Min(w => w.OrderNo);
                    Condition_Down.Enabled = vmOrderNo != vmCondition.Max(w => w.OrderNo);
                }
                else
                {
                    Condition_Up.Enabled = false;
                    Condition_Down.Enabled = false;
                }
            }
            else
            {
                Condition_Edit.Enabled = false;
                Condition_Delete.Enabled = false;
                Condition_Up.Enabled = false;
                Condition_Down.Enabled = false;
            }
        }

        private async void Condition_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.Condition}名稱";
            string caption = $"新{PropertyText.Title.Condition}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Condition}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.Condition}名稱必須小於等於 30 個字元！"),
                input => _conditions.Any(m => m.ConditionName == input) ? (false, $"{PropertyText.Title.Condition}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);

                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newConditionName = crud.Result.StringValue;
                        int maxOrderNo = _conditions.Max(w => w.OrderNo);

                        _context.MachineConditions.Add(new MachineCondition() { ConditionName = newConditionName, OrderNo = maxOrderNo + 1 });
                        await _context.SaveChangesAsync();
                        await UpdateConditionsViewAsync();
                        _cacheManager.RequestMachineUpdateDelay();
                        List_Conditions.SelectedIndex = _vmConds.FindIndex(m => m.Name == newConditionName);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.Condition}: {newConditionName}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增{PropertyText.Title.Condition}失敗: {nameof(Setup_MachineBrend)} -> {nameof(Condition_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Condition_Edit_Click(object sender, EventArgs e)
        {
            if (_vmCond != null)
            {
                var thisCondition = _vmCond;
                string title = $"請輸入新{PropertyText.Title.Condition}名稱";
                string oldCaption = $"原{PropertyText.Title.Condition}名稱";
                string newCaption = $"新{PropertyText.Title.Condition}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Condition}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.Condition}名稱必須小於等於 30 個字元！"),
                    input => _conditions.Any(m => m.ConditionName == input) ? (false, $"{PropertyText.Title.Condition}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = thisCondition.Name,
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = "",
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        try
                        {
                            string newConditionName = crud.Result.StringValue;

                            var newCondition = _conditions.FirstOrDefault(m => m.Id == thisCondition.Id);
                            if (newCondition != null)
                            {
                                newCondition.ConditionName = newConditionName;
                                await _context.SaveChangesAsync();
                                await UpdateConditionsViewAsync();
                                _cacheManager.RequestMachineUpdateDelay();
                                List_Conditions.SelectedIndex = _vmConds.FindIndex(m => m.Id == newCondition.Id);

                                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.Condition}: {thisCondition.Name}，名稱已變更為: {newConditionName}"));
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"{PropertyText.Title.Condition}重新命名失敗: {nameof(Setup_MachineBrend)} -> {nameof(Condition_Edit_Click)}()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private async void Condition_Delete_Click(object sender, EventArgs e)
        {
            if (_vmCond != null)
            {
                var thisCondition = _vmCond;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {PropertyText.Title.Condition} {thisCondition.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetCondition = _conditions.FirstOrDefault(m => m.Id == thisCondition.Id);
                        if (targetCondition != null)
                        {
                            _conditions.Remove(targetCondition);
                            await _context.SaveChangesAsync();
                            await UpdateConditionsViewAsync();
                            _cacheManager.RequestMachineUpdateDelay();

                            MessageBox.Show($"{PropertyText.Title.Condition}: {thisCondition.Name} 刪除成功",
                                "刪除成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.Condition}刪除失敗: {nameof(Setup_MachineBrend)} -> {nameof(Condition_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Condition_Up_Click(object sender, EventArgs e)
        {
            if (_vmCond != null)
            {
                var thisVmWs = _vmCond;
                var smallerVmWs = _vmConds.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapConditionOrderNoAsync(thisVmWs.Id, smallerVmWs.Id);
                    List_Conditions.SelectedIndex = _vmConds.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Condition_Down_Click(object sender, EventArgs e)
        {
            if (_vmCond != null)
            {
                var thisVm = _vmCond;
                var biggerVm = _vmConds.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapConditionOrderNoAsync(thisVm.Id, biggerVm.Id);
                    List_Conditions.SelectedIndex = _vmConds.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapConditionOrderNoAsync(int id1, int id2)
        {
            try
            {
                var entity1 = _conditions.FirstOrDefault(w => w.Id == id1);
                var entity2 = _conditions.FirstOrDefault(w => w.Id == id2);

                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateConditionsViewAsync();
                _cacheManager.RequestMachineUpdateDelay();
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_MachineBrend)} -> {nameof(SwapConditionOrderNoAsync)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion Condition
    }
}
