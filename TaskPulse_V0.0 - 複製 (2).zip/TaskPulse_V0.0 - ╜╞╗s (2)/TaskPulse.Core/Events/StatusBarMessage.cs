﻿using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 狀態列 Message 區顯示訊息。
    /// </summary>
    public class StatusBarMessage : ValueChangedMessage<string>
    {
        public StatusBarMessage(string info) : base(info) { }
    }
}
