﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 機種快取已更新通知。
    /// </summary>
    public class NotifyModelNoDataUpdated
    {
        public static readonly NotifyModelNoDataUpdated Instance = new NotifyModelNoDataUpdated();
        private NotifyModelNoDataUpdated() { }
    }
}
