﻿namespace Calin.TaskPulse.Core.SharedUI
{
    partial class MultiSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiPanel_Message = new Sunny.UI.UIPanel();
            this.label_ResultList = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClear = new Sunny.UI.UISymbolButton();
            this.btnOK = new Sunny.UI.UISymbolButton();
            this.btnCancel = new Sunny.UI.UISymbolButton();
            this.TLP_Content = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlTypes = new Calin.TaskPulse.Core.SharedUI.FixIndexTabControl();
            this.treeViewCategories = new System.Windows.Forms.TreeView();
            this.label_TreeCaption = new System.Windows.Forms.Label();
            this.uiPanel_Message.SuspendLayout();
            this.panel1.SuspendLayout();
            this.TLP_Content.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiPanel_Message
            // 
            this.TLP_Content.SetColumnSpan(this.uiPanel_Message, 2);
            this.uiPanel_Message.Controls.Add(this.label_ResultList);
            this.uiPanel_Message.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel_Message.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiPanel_Message.Location = new System.Drawing.Point(0, 443);
            this.uiPanel_Message.Margin = new System.Windows.Forms.Padding(0);
            this.uiPanel_Message.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel_Message.Name = "uiPanel_Message";
            this.uiPanel_Message.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPanel_Message.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiPanel_Message.Size = new System.Drawing.Size(586, 120);
            this.uiPanel_Message.TabIndex = 3;
            this.uiPanel_Message.Text = null;
            this.uiPanel_Message.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_ResultList
            // 
            this.label_ResultList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_ResultList.Location = new System.Drawing.Point(0, 0);
            this.label_ResultList.Margin = new System.Windows.Forms.Padding(3);
            this.label_ResultList.Name = "label_ResultList";
            this.label_ResultList.Padding = new System.Windows.Forms.Padding(15, 9, 0, 0);
            this.label_ResultList.Size = new System.Drawing.Size(586, 120);
            this.label_ResultList.TabIndex = 5;
            this.label_ResultList.Text = "ResultList";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnOK);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(589, 446);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(264, 114);
            this.panel1.TabIndex = 4;
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnClear.Location = new System.Drawing.Point(140, 66);
            this.btnClear.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnClear.Name = "btnClear";
            this.btnClear.Radius = 10;
            this.btnClear.Size = new System.Drawing.Size(100, 35);
            this.btnClear.Symbol = 362746;
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "全部清除";
            this.btnClear.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnOK
            // 
            this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnOK.Location = new System.Drawing.Point(23, 21);
            this.btnOK.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnOK.Name = "btnOK";
            this.btnOK.Radius = 10;
            this.btnOK.Size = new System.Drawing.Size(100, 80);
            this.btnOK.TabIndex = 5;
            this.btnOK.Text = "確定";
            this.btnOK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnCancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnCancel.Location = new System.Drawing.Point(140, 21);
            this.btnCancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Radius = 10;
            this.btnCancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.Size = new System.Drawing.Size(100, 35);
            this.btnCancel.Style = Sunny.UI.UIStyle.Custom;
            this.btnCancel.Symbol = 361453;
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "取消";
            this.btnCancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // TLP_Content
            // 
            this.TLP_Content.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.TLP_Content.ColumnCount = 3;
            this.TLP_Content.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.TLP_Content.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Content.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 270F));
            this.TLP_Content.Controls.Add(this.tabControlTypes, 1, 0);
            this.TLP_Content.Controls.Add(this.panel1, 2, 2);
            this.TLP_Content.Controls.Add(this.treeViewCategories, 0, 1);
            this.TLP_Content.Controls.Add(this.uiPanel_Message, 0, 2);
            this.TLP_Content.Controls.Add(this.label_TreeCaption, 0, 0);
            this.TLP_Content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP_Content.Location = new System.Drawing.Point(2, 35);
            this.TLP_Content.Margin = new System.Windows.Forms.Padding(30);
            this.TLP_Content.Name = "TLP_Content";
            this.TLP_Content.RowCount = 3;
            this.TLP_Content.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.TLP_Content.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Content.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.TLP_Content.Size = new System.Drawing.Size(856, 563);
            this.TLP_Content.TabIndex = 6;
            // 
            // tabControlTypes
            // 
            this.tabControlTypes.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.TLP_Content.SetColumnSpan(this.tabControlTypes, 2);
            this.tabControlTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlTypes.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tabControlTypes.HideTabHeaders = true;
            this.tabControlTypes.ItemSize = new System.Drawing.Size(100, 24);
            this.tabControlTypes.Location = new System.Drawing.Point(143, 5);
            this.tabControlTypes.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.tabControlTypes.Multiline = true;
            this.tabControlTypes.Name = "tabControlTypes";
            this.TLP_Content.SetRowSpan(this.tabControlTypes, 2);
            this.tabControlTypes.SelectedIndex = 0;
            this.tabControlTypes.Size = new System.Drawing.Size(710, 435);
            this.tabControlTypes.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControlTypes.TabIndex = 4;
            this.tabControlTypes.TabStop = false;
            // 
            // treeViewCategories
            // 
            this.treeViewCategories.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.treeViewCategories.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeViewCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeViewCategories.FullRowSelect = true;
            this.treeViewCategories.HideSelection = false;
            this.treeViewCategories.HotTracking = true;
            this.treeViewCategories.ItemHeight = 28;
            this.treeViewCategories.Location = new System.Drawing.Point(5, 33);
            this.treeViewCategories.Margin = new System.Windows.Forms.Padding(5, 3, 3, 9);
            this.treeViewCategories.Name = "treeViewCategories";
            this.treeViewCategories.ShowRootLines = false;
            this.treeViewCategories.Size = new System.Drawing.Size(132, 401);
            this.treeViewCategories.TabIndex = 5;
            this.treeViewCategories.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewCategories_AfterSelect);
            // 
            // label_TreeCaption
            // 
            this.label_TreeCaption.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label_TreeCaption.AutoSize = true;
            this.label_TreeCaption.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_TreeCaption.Location = new System.Drawing.Point(19, 7);
            this.label_TreeCaption.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.label_TreeCaption.Name = "label_TreeCaption";
            this.label_TreeCaption.Size = new System.Drawing.Size(102, 20);
            this.label_TreeCaption.TabIndex = 6;
            this.label_TreeCaption.Text = "TreeCaption";
            this.label_TreeCaption.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // MultiSelector
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(860, 600);
            this.Controls.Add(this.TLP_Content);
            this.EscClose = true;
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MultiSelector";
            this.Padding = new System.Windows.Forms.Padding(2, 35, 2, 2);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Title";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 800, 450);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FlowLayoutSelector_FormClosing);
            this.Shown += new System.EventHandler(this.FlowLayoutSelector_Shown);
            this.uiPanel_Message.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.TLP_Content.ResumeLayout(false);
            this.TLP_Content.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UIPanel uiPanel_Message;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolButton btnOK;
        private Sunny.UI.UISymbolButton btnCancel;
        private System.Windows.Forms.TableLayoutPanel TLP_Content;
        private System.Windows.Forms.Label label_ResultList;
        private Sunny.UI.UISymbolButton btnClear;
        private FixIndexTabControl tabControlTypes;
        private System.Windows.Forms.TreeView treeViewCategories;
        private System.Windows.Forms.Label label_TreeCaption;
    }
}