/*
 * ���J����ܮءA�Ω�b�Ӯɧ@�~����ܸ��J�ʵe�C
 */

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.SharedUI
{
    /// <summary>
    /// ���J����ܮءA������骺�ʵe�C
    /// </summary>
    public partial class LoadingDialog : Form
    {
        private System.Windows.Forms.Timer _animationTimer;
        private int _angle = 0;
        private const int SPINNER_SIZE = 60;
        private const int ARC_COUNT = 12;
        private const int ARC_WIDTH = 4;
        private SynchronizationContext _syncContext;

        /// <summary>
        /// ���J�T���C
        /// </summary>
        public string LoadingMessage
        {
            get => lblMessage.Text;
            set => lblMessage.Text = value;
        }

        public LoadingDialog()
        {
            InitializeComponent();
            InitializeDialog();
            _syncContext = SynchronizationContext.Current ?? new WindowsFormsSynchronizationContext();
        }

        private void InitializeDialog()
        {
            // �]�w Form �ݩ�
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            this.BackColor = Color.FromArgb(48, 48, 48);
            this.Size = new Size(300, 200);

            // �]�w�b�z���ĪG
            this.Opacity = 0.95;

            // �������D�C
            this.Padding = new Padding(0);

            // ��l�ưʵe�p�ɾ�
            _animationTimer = new System.Windows.Forms.Timer();
            _animationTimer.Interval = 50; // 50ms ��s�@��
            _animationTimer.Tick += AnimationTimer_Tick;

            // �]�w������i����
            this.ControlBox = false;

            // ���U Paint �ƥ�
            if (panelSpinner != null)
            {
                panelSpinner.Paint += PanelSpinner_Paint;
            }
        }

        private void AnimationTimer_Tick(object sender, EventArgs e)
        {
            _angle = (_angle + 30) % 360;
            panelSpinner?.Invalidate(); // Ĳ�o��ø
        }

        private void PanelSpinner_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int centerX = panelSpinner.Width / 2;
            int centerY = panelSpinner.Height / 2;
            int radius = SPINNER_SIZE / 2;

            for (int i = 0; i < ARC_COUNT; i++)
            {
                int angle = _angle + (i * 30);
                float alpha = 255f * (i + 1) / ARC_COUNT;

                using (Pen pen = new Pen(Color.FromArgb((int)alpha, CommonStyles.BackColor), ARC_WIDTH))
                {
                    pen.StartCap = LineCap.Round;
                    pen.EndCap = LineCap.Round;

                    double radian = angle * Math.PI / 180;
                    int x1 = (int)(centerX + Math.Cos(radian) * (radius - 10));
                    int y1 = (int)(centerY + Math.Sin(radian) * (radius - 10));
                    int x2 = (int)(centerX + Math.Cos(radian) * radius);
                    int y2 = (int)(centerY + Math.Sin(radian) * radius);

                    g.DrawLine(pen, x1, y1, x2, y2);
                }
            }
        }

        /// <summary>
        /// ��ܸ��J��ܮءC
        /// </summary>
        public new void Show()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(Show));
                return;
            }

            _animationTimer.Start();
            base.Show();
            this.Refresh();
        }

        /// <summary>
        /// �������J��ܮءC
        /// </summary>
        public new void Close()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(Close));
                return;
            }

            _animationTimer.Stop();
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (InvokeRequired)
                {
                    try
                    {
                        Invoke(new Action(() =>
                        {
                            _animationTimer?.Stop();
                            _animationTimer?.Dispose();
                        }));
                    }
                    catch (InvalidOperationException)
                    {
                        // �p�G�����w�g����,�����B�z
                        _animationTimer?.Stop();
                        _animationTimer?.Dispose();
                    }
                }
                else
                {
                    _animationTimer?.Stop();
                    _animationTimer?.Dispose();
                }
            }
            base.Dispose(disposing);
        }
    }
}
