﻿#region License
// Advanced DataGridView
//
// Copyright (c), 2014 Davide Gironi <davide.gironi@gmail.com>
// Original work Copyright (c), 2013 Zuby <zuby@me.com>
//
// Please refer to LICENSE file for licensing information.
#endregion

using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
#if NETFRAMEWORK
using System.Web.Script.Serialization;
#else
#endif
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.ADGV
{

    [System.ComponentModel.DesignerCategory("")]
    public class AdvancedDataGridView : DataGridView
    {

        #region public enum

        /// <summary>
        /// 篩選建立器模式（用於組合多個欄位的篩選條件）
        /// </summary>
        public enum FilterBuilerMode : byte
        {
            /// <summary>
            /// 使用 AND 邏輯連接篩選條件
            /// </summary>
            And = 0,
            /// <summary>
            /// 使用 OR 邏輯連接篩選條件
            /// </summary>
            Or = 1
        }

        #endregion


        #region public events

        /// <summary>
        /// SortStringChanged 事件參數，封裝排序字串與取消標記
        /// </summary>
        public class SortEventArgs : EventArgs
        {
            /// <summary>
            /// 要套用至資料來源的排序字串（例如 DataView.Sort）
            /// </summary>
            public string SortString { get; set; }
            /// <summary>
            /// 若設定為 true，則表明應取消排序應用
            /// </summary>
            public bool Cancel { get; set; }

            /// <summary>
            /// 建構子，初始化欄位預設值
            /// </summary>
            public SortEventArgs()
            {
                SortString = null;
                Cancel = false;
            }
        }

        /// <summary>
        /// FilterStringChanged 事件參數，封裝篩選字串與取消標記
        /// </summary>
        public class FilterEventArgs : EventArgs
        {
            /// <summary>
            /// 要套用至資料來源的篩選字串（例如 DataView.RowFilter）
            /// </summary>
            public string FilterString { get; set; }
            /// <summary>
            /// 若設定為 true，則表明應取消篩選應用
            /// </summary>
            public bool Cancel { get; set; }

            /// <summary>
            /// 建構子，初始化欄位預設值
            /// </summary>
            public FilterEventArgs()
            {
                FilterString = null;
                Cancel = false;
            }
        }

        /// <summary>
        /// 排序字串改變事件（訂閱以處理排序邏輯）
        /// </summary>
        public event EventHandler<SortEventArgs> SortStringChanged;

        /// <summary>
        /// 篩選字串改變事件（訂閱以處理篩選邏輯）
        /// </summary>
        public event EventHandler<FilterEventArgs> FilterStringChanged;

        #endregion


        #region translations

        /// <summary>
        /// 可用的翻譯鍵
        /// </summary>
        public enum TranslationKey
        {
            ADGVSortDateTimeASC,
            ADGVSortDateTimeDESC,
            ADGVSortBoolASC,
            ADGVSortBoolDESC,
            ADGVSortNumASC,
            ADGVSortNumDESC,
            ADGVSortTextASC,
            ADGVSortTextDESC,
            ADGVAddCustomFilter,
            ADGVCustomFilter,
            ADGVClearFilter,
            ADGVClearSort,
            ADGVButtonFilter,
            ADGVButtonUndofilter,
            ADGVNodeSelectAll,
            ADGVNodeSelectEmpty,
            ADGVNodeSelectTrue,
            ADGVNodeSelectFalse,
            ADGVFilterChecklistDisable,
            ADGVEquals,
            ADGVDoesNotEqual,
            ADGVEarlierThan,
            ADGVEarlierThanOrEqualTo,
            ADGVLaterThan,
            ADGVLaterThanOrEqualTo,
            ADGVBetween,
            ADGVGreaterThan,
            ADGVGreaterThanOrEqualTo,
            ADGVLessThan,
            ADGVLessThanOrEqualTo,
            ADGVBeginsWith,
            ADGVDoesNotBeginWith,
            ADGVEndsWith,
            ADGVDoesNotEndWith,
            ADGVContains,
            ADGVDoesNotContain,
            ADGVIncludeNullValues,
            ADGVInvalidValue,
            ADGVFilterStringDescription,
            ADGVFormTitle,
            ADGVLabelColumnNameText,
            ADGVLabelAnd,
            ADGVButtonOk,
            ADGVButtonCancel
        }

        /// <summary>
        /// 國際化字串字典（預設英語值，可透過 SetTranslations 覆寫）
        /// </summary>
        public static Dictionary<string, string> Translations = new Dictionary<string, string>()
        {
            { TranslationKey.ADGVSortDateTimeASC.ToString(), "Sort Oldest to Newest" },
            { TranslationKey.ADGVSortDateTimeDESC.ToString(), "Sort Newest to Oldest" },
            { TranslationKey.ADGVSortBoolASC.ToString(), "Sort by False/True" },
            { TranslationKey.ADGVSortBoolDESC.ToString(), "Sort by True/False" },
            { TranslationKey.ADGVSortNumASC.ToString(), "Sort Smallest to Largest" },
            { TranslationKey.ADGVSortNumDESC.ToString(), "Sort Largest to Smallest" },
            { TranslationKey.ADGVSortTextASC.ToString(), "Sort А to Z" },
            { TranslationKey.ADGVSortTextDESC.ToString(), "Sort Z to A" },
            { TranslationKey.ADGVAddCustomFilter.ToString(), "Add a Custom Filter" },
            { TranslationKey.ADGVCustomFilter.ToString(), "Custom Filter" },
            { TranslationKey.ADGVClearFilter.ToString(), "Clear Filter" },
            { TranslationKey.ADGVClearSort.ToString(), "Clear Sort" },
            { TranslationKey.ADGVButtonFilter.ToString(), "Filter" },
            { TranslationKey.ADGVButtonUndofilter.ToString(), "Cancel" },
            { TranslationKey.ADGVNodeSelectAll.ToString(), "(Select All)" },
            { TranslationKey.ADGVNodeSelectEmpty.ToString(), "(Blanks)" },
            { TranslationKey.ADGVNodeSelectTrue.ToString(), "True" },
            { TranslationKey.ADGVNodeSelectFalse.ToString(), "False" },
            { TranslationKey.ADGVFilterChecklistDisable.ToString(), "Filter list is disabled" },
            { TranslationKey.ADGVEquals.ToString(), "equals" },
            { TranslationKey.ADGVDoesNotEqual.ToString(), "does not equal" },
            { TranslationKey.ADGVEarlierThan.ToString(), "earlier than" },
            { TranslationKey.ADGVEarlierThanOrEqualTo.ToString(), "earlier than or equal to" },
            { TranslationKey.ADGVLaterThan.ToString(), "later than"},
            { TranslationKey.ADGVLaterThanOrEqualTo.ToString(), "later than or equal to" },
            { TranslationKey.ADGVBetween.ToString(), "between" },
            { TranslationKey.ADGVGreaterThan.ToString(), "greater than" },
            { TranslationKey.ADGVGreaterThanOrEqualTo.ToString(), "greater than or equal to" },
            { TranslationKey.ADGVLessThan.ToString(), "less than" },
            { TranslationKey.ADGVLessThanOrEqualTo.ToString(), "less than or equal to" },
            { TranslationKey.ADGVBeginsWith.ToString(), "begins with" },
            { TranslationKey.ADGVDoesNotBeginWith.ToString(), "does not begin with" },
            { TranslationKey.ADGVEndsWith.ToString(), "ends with" },
            { TranslationKey.ADGVDoesNotEndWith.ToString(), "does not end with" },
            { TranslationKey.ADGVContains.ToString(), "contains" },
            { TranslationKey.ADGVDoesNotContain.ToString(), "does not contain" },
            { TranslationKey.ADGVIncludeNullValues.ToString(), "include empty strings" },
            { TranslationKey.ADGVInvalidValue.ToString(), "Invalid Value" },
            { TranslationKey.ADGVFilterStringDescription.ToString(), "Show rows where value {0} \"{1}\"" },
            { TranslationKey.ADGVFormTitle.ToString(), "Custom Filter" },
            { TranslationKey.ADGVLabelColumnNameText.ToString(), "Show rows where value" },
            { TranslationKey.ADGVLabelAnd.ToString(), "And" },
            { TranslationKey.ADGVButtonOk.ToString(), "OK" },
            { TranslationKey.ADGVButtonCancel.ToString(), "Cancel" }
        };

        #endregion


        #region class properties and fields

        private List<string> _sortOrderList = new List<string>();
        private List<string> _filterOrderList = new List<string>();
        private List<string> _filteredColumns = new List<string>();
        private List<MenuStrip> _menuStripToDispose = new List<MenuStrip>();

        private bool _loadedFilter = false;
        private string _sortString = null;
        private string _filterString = null;

        private bool _sortStringChangedInvokeBeforeDatasourceUpdate = true;
        private bool _filterStringChangedInvokeBeforeDatasourceUpdate = true;

        private FilterBuilerMode _filterBuilerMode = FilterBuilerMode.And;

        internal int _maxFilterButtonImageHeight = ColumnHeaderCell.FilterButtonImageDefaultSize;

        internal int _maxAllCellHeight = ColumnHeaderCell.FilterButtonImageDefaultSize;

        #endregion


        #region constructors

        /// <summary>
        /// 建構子：建立 AdvancedDataGridView 並設定預設方向為 Left-to-Right
        /// </summary>
        public AdvancedDataGridView()
        {
            RightToLeft = RightToLeft.No;
        }

        /// <summary>
        /// 處理控制項被銷毀時的清理工作，取消事件並處理未處置的 MenuStrip
        /// </summary>
        /// <param name="e">事件參數</param>
        protected override void OnHandleDestroyed(EventArgs e)
        {
            foreach (DataGridViewColumn column in Columns)
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SortChanged -= Cell_SortChanged;
                    cell.FilterChanged -= Cell_FilterChanged;
                    cell.FilterPopup -= Cell_FilterPopup;
                }
            }
            foreach (MenuStrip menustrip in _menuStripToDispose)
            {
                menustrip.Dispose();
            }
            _menuStripToDispose.Clear();

            base.OnHandleDestroyed(e);
        }

        /// <summary>
        /// 當 DataSource 變更時處理未使用的 MenuStrip 並更新現有 MenuStrip 的資料型別
        /// </summary>
        /// <param name="e">事件參數</param>
        protected override void OnDataSourceChanged(EventArgs e)
        {
            //dispose unactive menustrips
            foreach (DataGridViewColumn column in Columns)
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                _menuStripToDispose = _menuStripToDispose.Where(f => f != cell.MenuStrip).ToList();
            }
            foreach (MenuStrip menustrip in _menuStripToDispose)
            {
                menustrip.Dispose();
            }
            _menuStripToDispose.Clear();

            //update datatype for active menustrips
            foreach (DataGridViewColumn column in Columns)
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                cell.MenuStrip.SetDataType(column.ValueType);
            }

            base.OnDataSourceChanged(e);
        }
        #endregion


        #region translations methods

        /// <summary>
        /// 使用指定的字典覆寫內部翻譯字串
        /// </summary>
        /// <param name="translations">欲設定的翻譯鍵值對集合</param>
        public static void SetTranslations(IDictionary<string, string> translations)
        {
            //set localization strings
            if (translations != null)
            {
                foreach (KeyValuePair<string, string> translation in translations)
                {
                    if (Translations.ContainsKey(translation.Key))
                        Translations[translation.Key] = translation.Value;
                }
            }
        }

        /// <summary>
        /// 取得目前的翻譯字典參考
        /// </summary>
        /// <returns>包含所有翻譯字串的字典</returns>
        public static IDictionary<string, string> GetTranslations()
        {
            return Translations;
        }

        /// <summary>
        /// 從檔案載入翻譯字串並回傳合併後的字典（僅接受已定義的鍵）
        /// </summary>
        /// <param name="filename">包含 JSON 翻譯內容的檔案路徑</param>
        /// <returns>載入並合併後的翻譯字典</returns>
        public static IDictionary<string, string> LoadTranslationsFromFile(string filename)
        {
            IDictionary<string, string> ret = new Dictionary<string, string>();

            if (!string.IsNullOrEmpty(filename))
            {
                //deserialize the file
                try
                {
                    string jsontext = File.ReadAllText(filename);
#if NETFRAMEWORK
                    Dictionary<string, string> translations = new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(jsontext);
#else
                    Dictionary<string, string> translations = JsonSerializer.Deserialize<Dictionary<string, string>>(jsontext);
#endif
                    foreach (KeyValuePair<string, string> translation in translations)
                    {
                        if (!ret.ContainsKey(translation.Key) && Translations.ContainsKey(translation.Key))
                            ret.Add(translation.Key, translation.Value);
                    }
                }
                catch { }
            }

            //add default translations if not in files
            foreach (KeyValuePair<string, string> translation in GetTranslations())
            {
                if (!ret.ContainsKey(translation.Key))
                    ret.Add(translation.Key, translation.Value);
            }

            return ret;
        }

        #endregion


        #region public Helper methods

        /// <summary>
        /// 啟用雙緩衝，減少重繪閃爍
        /// </summary>
        public void SetDoubleBuffered()
        {
            DoubleBuffered = true;
        }

        #endregion


        #region public Filter and Sort methods

        /// <summary>
        /// 指示在更新資料來源之前是否先觸發 SortStringChanged 事件
        /// </summary>
        public bool SortStringChangedInvokeBeforeDatasourceUpdate
        {
            get
            {
                return _sortStringChangedInvokeBeforeDatasourceUpdate;
            }
            set
            {
                _sortStringChangedInvokeBeforeDatasourceUpdate = value;
            }
        }

        /// <summary>
        /// 指示在更新資料來源之前是否先觸發 FilterStringChanged 事件
        /// </summary>
        public bool FilterStringChangedInvokeBeforeDatasourceUpdate
        {
            get
            {
                return _filterStringChangedInvokeBeforeDatasourceUpdate;
            }
            set
            {
                _filterStringChangedInvokeBeforeDatasourceUpdate = value;
            }
        }

        /// <summary>
        /// 停用指定欄位的篩選與排序功能
        /// </summary>
        /// <param name="column">要停用的欄位</param>
        public void DisableFilterAndSort(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    if (cell.FilterAndSortEnabled == true && (cell.SortString.Length > 0 || cell.FilterString.Length > 0))
                    {
                        CleanFilter(true);
                        cell.FilterAndSortEnabled = false;
                    }
                    else
                        cell.FilterAndSortEnabled = false;
                    _filterOrderList.Remove(column.Name);
                    _sortOrderList.Remove(column.Name);
                    _filteredColumns.Remove(column.Name);
                }
            }
        }

        /// <summary>
        /// 啟用指定欄位的篩選與排序功能（若欄位尚未使用 ColumnHeaderCell 會建立之）
        /// </summary>
        /// <param name="column">要啟用的欄位</param>
        public void EnableFilterAndSort(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    if (!cell.FilterAndSortEnabled && (cell.FilterString.Length > 0 || cell.SortString.Length > 0))
                        CleanFilter(true);

                    cell.FilterAndSortEnabled = true;
                    _filteredColumns.Remove(column.Name);

                    SetFilterDateAndTimeEnabled(column, cell.IsFilterDateAndTimeEnabled);
                    SetSortEnabled(column, cell.IsSortEnabled);
                    SetFilterEnabled(column, cell.IsFilterEnabled);
                }
                else
                {
                    column.SortMode = DataGridViewColumnSortMode.Programmatic;
                    cell = new ColumnHeaderCell(this, column.HeaderCell, true);
                    cell.SortChanged += new ColumnHeaderCellEventHandler(Cell_SortChanged);
                    cell.FilterChanged += new ColumnHeaderCellEventHandler(Cell_FilterChanged);
                    cell.FilterPopup += new ColumnHeaderCellEventHandler(Cell_FilterPopup);
                    column.MinimumWidth = cell.MinimumSize.Width;
                    if (ColumnHeadersHeight < cell.MinimumSize.Height)
                        ColumnHeadersHeight = cell.MinimumSize.Height;
                    column.HeaderCell = cell;
                }
            }
        }

        /// <summary>
        /// 啟用或停用指定欄位的篩選與排序功能（便利方法）
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="enabled">是否啟用</param>
        public void SetFilterAndSortEnabled(DataGridViewColumn column, bool enabled)
        {
            if (enabled)
                EnableFilterAndSort(column);
            else
                DisableFilterAndSort(column);
        }

        /// <summary>
        /// 停用指定欄位的 checklist 篩選（值清單）功能
        /// </summary>
        /// <param name="column">目標欄位</param>
        public void DisableFilterChecklist(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetFilterChecklistEnabled(false);
                }
            }
        }

        /// <summary>
        /// 啟用指定欄位的 checklist 篩選（值清單）功能
        /// </summary>
        /// <param name="column">目標欄位</param>
        public void EnableFilterChecklist(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetFilterChecklistEnabled(true);
                }
            }
        }

        /// <summary>
        /// 設定指定欄位是否啟用 checklist 篩選
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="enabled">true 表示啟用</param>
        public void SetFilterChecklistEnabled(DataGridViewColumn column, bool enabled)
        {
            if (enabled)
                EnableFilterChecklist(column);
            else
                DisableFilterChecklist(column);
        }

        /// <summary>
        /// 設定指定欄位在 checklist 篩選中允許顯示的節點最大數量
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="maxnodes">最大節點數</param>
        public void SetFilterChecklistNodesMax(DataGridViewColumn column, int maxnodes)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetFilterChecklistNodesMax(maxnodes);
                }
            }
        }

        /// <summary>
        /// 設定全欄位 checklist 篩選的節點上限
        /// </summary>
        /// <param name="maxnodes">最大節點數</param>
        public void SetFilterChecklistNodesMax(int maxnodes)
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.SetFilterChecklistNodesMax(maxnodes);
        }

        /// <summary>
        /// 啟用或停用指定欄位是否啟用 checklist 節點上限
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="enabled">是否啟用</param>
        public void EnabledFilterChecklistNodesMax(DataGridViewColumn column, bool enabled)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.EnabledFilterChecklistNodesMax(enabled);
                }
            }
        }

        /// <summary>
        /// 啟用或停用所有可篩選欄位的 checklist 節點上限
        /// </summary>
        /// <param name="enabled">是否啟用</param>
        public void EnabledFilterChecklistNodesMax(bool enabled)
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.EnabledFilterChecklistNodesMax(enabled);
        }

        /// <summary>
        /// 停用指定欄位的自訂篩選（Custom Filter）功能
        /// </summary>
        /// <param name="column">目標欄位</param>
        public void DisableFilterCustom(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetFilterCustomEnabled(false);
                }
            }
        }

        /// <summary>
        /// 啟用指定欄位的自訂篩選（Custom Filter）功能
        /// </summary>
        /// <param name="column">目標欄位</param>
        public void EnableFilterCustom(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetFilterCustomEnabled(true);
                }
            }
        }

        /// <summary>
        /// 設定指定欄位是否啟用自訂篩選功能
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="enabled">是否啟用</param>
        public void SetFilterCustomEnabled(DataGridViewColumn column, bool enabled)
        {
            if (enabled)
                EnableFilterCustom(column);
            else
                DisableFilterCustom(column);
        }

        /// <summary>
        /// 設定在 checklist 的文字篩選中觸發 TextChanged 延遲機制所需的節點數（單欄）
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="numnodes">節點數門檻</param>
        public void SetFilterChecklistTextFilterTextChangedDelayNodes(DataGridViewColumn column, int numnodes)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.TextFilterTextChangedDelayNodes = numnodes;
                }
            }
        }

        /// <summary>
        /// 設定在 checklist 的文字篩選中觸發 TextChanged 延遲機制所需的節點數（全欄）
        /// </summary>
        /// <param name="numnodes">節點數門檻</param>
        public void SetFilterChecklistTextFilterTextChangedDelayNodes(int numnodes)
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.TextFilterTextChangedDelayNodes = numnodes;
        }

        /// <summary>
        /// 停用指定欄位 checklist 的 TextChanged 延遲處理機制
        /// </summary>
        /// <param name="column">目標欄位</param>
        public void SetFilterChecklistTextFilterTextChangedDelayDisabled(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetTextFilterTextChangedDelayNodesDisabled();
                }
            }
        }

        /// <summary>
        /// 停用所有可篩選欄位的 TextChanged 延遲處理機制
        /// </summary>
        public void SetFilterChecklistTextFilterTextChangedDelayDisabled()
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.SetTextFilterTextChangedDelayNodesDisabled();
        }

        /// <summary>
        /// 設定 checklist 的 TextChanged 延遲毫秒數（單欄）
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="milliseconds">延遲毫秒數</param>
        public void SetFilterChecklistTextFilterTextChangedDelayMs(DataGridViewColumn column, int milliseconds)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetTextFilterTextChangedDelayMs(milliseconds);
                }
            }
        }

        /// <summary>
        /// 設定 checklist 的 TextChanged 延遲毫秒數（全欄）
        /// </summary>
        /// <param name="milliseconds">延遲毫秒數</param>
        public void SetFilterChecklistTextFilterTextChangedDelayMs(int milliseconds)
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.SetTextFilterTextChangedDelayMs(milliseconds);
        }

        /// <summary>
        /// 載入先前儲存的篩選與排序字串，並將欄位進入 Loaded 模式（避免立即應用）
        /// </summary>
        /// <param name="filter">篩選字串</param>
        /// <param name="sorting">排序字串</param>
        public void LoadFilterAndSort(string filter, string sorting)
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.SetLoadedMode(true);

            _filteredColumns.Clear();

            _filterOrderList.Clear();
            _sortOrderList.Clear();

            if (filter != null)
                FilterString = filter;
            if (sorting != null)
                SortString = sorting;

            _loadedFilter = true;
        }

        /// <summary>
        /// 清除所有欄位的篩選與排序設定，並退出 Loaded 模式
        /// </summary>
        public void CleanFilterAndSort()
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.SetLoadedMode(false);

            _filteredColumns.Clear();
            _filterOrderList.Clear();
            _sortOrderList.Clear();

            _loadedFilter = false;

            CleanFilter();
            CleanSort();
        }

        /// <summary>
        /// 設定 checkbox 篩選所使用的 NOT IN 邏輯（若支援）
        /// </summary>
        /// <param name="enabled">是否啟用 NOT IN 邏輯</param>
        public void SetMenuStripFilterNOTINLogic(bool enabled)
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.IsMenuStripFilterNOTINLogicEnabled = enabled;
        }

        /// <summary>
        /// 取得或設定整體是否啟用篩選與排序功能
        /// </summary>
        public bool FilterAndSortEnabled
        {
            get
            {
                return _filterAndSortEnabled;
            }
            set
            {
                _filterAndSortEnabled = value;
            }
        }
        private bool _filterAndSortEnabled = true;

        /// <summary>
        /// 設定在顯示篩選視窗時 TextBox 是否自動取得焦點
        /// </summary>
        /// <param name="enabled">是否自動取焦點</param>
        public void SetFilterTextFocusOnShow(bool enabled)
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.FilterTextFocusOnShow = enabled;
        }

        #endregion


        #region public Sort methods

        /// <summary>
        /// 取得目前的排序字串（若為 null 或空則回傳空字串）
        /// </summary>
        public string SortString
        {
            get
            {
                return !string.IsNullOrEmpty(_sortString) ? _sortString : "";
            }
            private set
            {
                string old = value;
                if (old != _sortString)
                {
                    _sortString = value;

                    TriggerSortStringChanged();
                }
            }
        }

        /// <summary>
        /// 觸發排序字串變更：可先觸發事件讓外部取消或修改排序，然後套用至資料來源
        /// </summary>
        public void TriggerSortStringChanged()
        {
            //call event handler if one is attached
            SortEventArgs sortEventArgs = new SortEventArgs
            {
                SortString = _sortString,
                Cancel = false
            };
            //invoke SortStringChanged
            if (_sortStringChangedInvokeBeforeDatasourceUpdate)
            {
                if (SortStringChanged != null)
                    SortStringChanged.Invoke(this, sortEventArgs);
            }
            //sort datasource
            if (sortEventArgs.Cancel == false)
            {
                if (DataSource is BindingSource bindingsource)
                {
                    bindingsource.Sort = sortEventArgs.SortString;
                }
                else if (DataSource is DataView dataview)
                {
                    dataview.Sort = sortEventArgs.SortString;
                }
                else if (DataSource is DataTable datatable)
                {
                    if (datatable.DefaultView != null)
                        datatable.DefaultView.Sort = sortEventArgs.SortString;
                }
            }
            //invoke SortStringChanged
            if (!_sortStringChangedInvokeBeforeDatasourceUpdate)
            {
                if (SortStringChanged != null)
                    SortStringChanged.Invoke(this, sortEventArgs);
            }
        }

        /// <summary>
        /// 設定指定欄位是否可排序
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="enabled">是否啟用排序</param>
        public void SetSortEnabled(DataGridViewColumn column, bool enabled)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetSortEnabled(enabled);
                }
            }
        }

        /// <summary>
        /// 對指定欄位套用遞增排序（ASC）
        /// </summary>
        /// <param name="column">目標欄位</param>
        public void SortASC(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SortASC();
                }
            }
        }

        /// <summary>
        /// 對指定欄位套用遞減排序（DESC）
        /// </summary>
        /// <param name="column">目標欄位</param>
        public void SortDESC(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SortDESC();
                }
            }
        }

        /// <summary>
        /// 清除特定欄位的排序設定
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="fireEvent">若為 true 則會觸發排序變更事件</param>
        public void CleanSort(DataGridViewColumn column, bool fireEvent)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null && FilterableCells.Contains(cell))
                {
                    cell.CleanSort();
                    //remove column from sorted list
                    _sortOrderList.Remove(column.Name);
                }
            }

            if (fireEvent)
                SortString = BuildSortString();
            else
                _sortString = BuildSortString();
        }

        /// <summary>
        /// 清除特定欄位的排序設定（會觸發事件）
        /// </summary>
        /// <param name="column">目標欄位</param>
        public void CleanSort(DataGridViewColumn column)
        {
            CleanSort(column, true);
        }

        /// <summary>
        /// 清除所有欄位的排序設定
        /// </summary>
        /// <param name="fireEvent">若為 true 則會觸發排序變更事件</param>
        public void CleanSort(bool fireEvent)
        {
            foreach (ColumnHeaderCell c in FilterableCells)
                c.CleanSort();
            _sortOrderList.Clear();

            if (fireEvent)
                SortString = null;
            else
                _sortString = null;
        }

        /// <summary>
        /// 清除所有欄位的排序設定（會觸發事件）
        /// </summary>
        public void CleanSort()
        {
            CleanSort(true);
        }

        #endregion


        #region public Filter methods

        /// <summary>
        /// 取得目前的完整篩選字串（若為 null 或空則回傳空字串）
        /// </summary>
        public string FilterString
        {
            get
            {
                return !string.IsNullOrEmpty(_filterString) ? _filterString : "";
            }
            private set
            {
                string old = value;
                if (old != _filterString)
                {
                    _filterString = value;

                    TriggerFilterStringChanged();
                }
            }
        }

        /// <summary>
        /// 觸發篩選字串變更：可先觸發事件讓外部取消或修改篩選，然後套用至資料來源
        /// </summary>
        public void TriggerFilterStringChanged()
        {
            //call event handler if one is attached
            FilterEventArgs filterEventArgs = new FilterEventArgs
            {
                FilterString = _filterString,
                Cancel = false
            };
            //invoke FilterStringChanged
            if (_filterStringChangedInvokeBeforeDatasourceUpdate)
            {
                if (FilterStringChanged != null)
                    FilterStringChanged.Invoke(this, filterEventArgs);
            }
            //filter datasource
            if (filterEventArgs.Cancel == false)
            {
                if (DataSource is BindingSource bindingsource)
                {
                    bindingsource.Filter = filterEventArgs.FilterString;
                }
                else if (DataSource is DataView dataview)
                {
                    dataview.RowFilter = filterEventArgs.FilterString;
                }
                else if (DataSource is DataTable datatable)
                {
                    if (datatable.DefaultView != null)
                        datatable.DefaultView.RowFilter = filterEventArgs.FilterString;
                }
            }
            //invoke FilterStringChanged
            if (!_filterStringChangedInvokeBeforeDatasourceUpdate)
            {
                if (FilterStringChanged != null)
                    FilterStringChanged.Invoke(this, filterEventArgs);
            }
        }

        /// <summary>
        /// 設定指定欄位的日期與時間篩選功能是否啟用
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="enabled">是否啟用日期與時間篩選</param>
        public void SetFilterDateAndTimeEnabled(DataGridViewColumn column, bool enabled)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.IsFilterDateAndTimeEnabled = enabled;
                }
            }
        }

        /// <summary>
        /// 設定指定欄位是否啟用篩選功能
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="enabled">是否啟用篩選</param>
        public void SetFilterEnabled(DataGridViewColumn column, bool enabled)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetFilterEnabled(enabled);
                }
            }
        }

        /// <summary>
        /// 設定在 checklist 中使用文字篩選且會在搜尋模式下移除節點的行為（單欄）
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="enabled">是否啟用搜尋移除節點模式</param>
        public void SetChecklistTextFilterRemoveNodesOnSearchMode(DataGridViewColumn column, bool enabled)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.SetChecklistTextFilterRemoveNodesOnSearchMode(enabled);
                }
            }
        }

        /// <summary>
        /// 清除特定欄位的篩選設定
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="fireEvent">若為 true 則會觸發篩選變更事件</param>
        public void CleanFilter(DataGridViewColumn column, bool fireEvent)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    cell.CleanFilter();
                    //remove column from filtered list
                    _filterOrderList.Remove(column.Name);
                }
            }

            if (fireEvent)
                FilterString = BuildFilterString();
            else
                _filterString = BuildFilterString();
        }

        /// <summary>
        /// 清除特定欄位的篩選設定（會觸發事件）
        /// </summary>
        /// <param name="column">目標欄位</param>
        public void CleanFilter(DataGridViewColumn column)
        {
            CleanFilter(column, true);
        }

        /// <summary>
        /// 清除所有欄位的篩選設定
        /// </summary>
        /// <param name="fireEvent">若為 true 則會觸發篩選變更事件</param>
        public void CleanFilter(bool fireEvent)
        {
            foreach (ColumnHeaderCell c in FilterableCells)
            {
                c.CleanFilter();
            }
            _filterOrderList.Clear();

            if (fireEvent)
                FilterString = null;
            else
                _filterString = null;
        }

        /// <summary>
        /// 清除所有欄位的篩選設定（會觸發事件）
        /// </summary>
        public void CleanFilter()
        {
            CleanFilter(true);
        }

        /// <summary>
        /// 設定文字篩選在搜尋模式下是否移除節點（單欄）
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <param name="enabled">是否移除節點</param>
        public void SetTextFilterRemoveNodesOnSearch(DataGridViewColumn column, bool enabled)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                    cell.DoesTextFilterRemoveNodesOnSearch = enabled;
            }
        }

        /// <summary>
        /// 取得文字篩選在搜尋模式下是否會移除節點（單欄）
        /// </summary>
        /// <param name="column">目標欄位</param>
        /// <returns>若設定過則回傳布林值，否則回傳 null</returns>
        public bool? GetTextFilterRemoveNodesOnSearch(DataGridViewColumn column)
        {
            bool? ret = null;
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                    ret = cell.DoesTextFilterRemoveNodesOnSearch;
            }
            return ret;
        }


        /// <summary>
        /// 回傳目前每個已套用篩選的資料欄位與其對應的篩選字串（使用欄位的 DataPropertyName 作為鍵）
        /// </summary>
        /// <returns>字典：{ DataPropertyName => 篩選字串 }</returns>
        public Dictionary<string, string> GetColumnsFilteredStrings()
        {
            Dictionary<string, string> ret = new Dictionary<string, string>();

            foreach (string filterOrder in _filterOrderList)
            {
                DataGridViewColumn Column = Columns[filterOrder];

                if (Column != null)
                {
                    ColumnHeaderCell cell = Column.HeaderCell as ColumnHeaderCell;
                    if (cell != null)
                    {
                        if (cell.FilterAndSortEnabled && cell.ActiveFilterType != MenuStrip.FilterType.None)
                        {
                            if (!ret.ContainsKey(Column.DataPropertyName))
                            {
                                ret.Add(Column.DataPropertyName, cell.FilterString);
                            }
                        }
                    }
                }
            }
            return ret;
        }

        /// <summary>
        /// 設定篩選建立器模式（AND 或 OR）
        /// </summary>
        /// <param name="filterBuilerMode">要使用的模式</param>
        public void SetFilterBuilderMode(FilterBuilerMode filterBuilerMode)
        {
            _filterBuilerMode = filterBuilerMode;
        }

        /// <summary>
        /// 取得目前的篩選建立器模式
        /// </summary>
        /// <returns>目前使用的 FilterBuilerMode</returns>
        public FilterBuilerMode GetFilterBuilderMode()
        {
            return _filterBuilerMode;
        }

        #endregion


        #region public Find methods

        /// <summary>
        /// 在表格中尋找第一個符合指定條件的儲存格
        /// </summary>
        /// <param name="valueToFind">要尋找的值（字串）</param>
        /// <param name="columnName">若非 null，僅在該欄位搜尋；否則從所有欄位搜尋</param>
        /// <param name="rowIndex">起始列索引（包含）</param>
        /// <param name="columnIndex">起始欄索引（包含），僅在 columnName 為 null 時生效</param>
        /// <param name="isWholeWordSearch">是否要求整字比對（true 則必須完全相等）</param>
        /// <param name="isCaseSensitive">是否區分大小寫</param>
        /// <returns>找到的 DataGridViewCell；若沒有找到則回傳 null</returns>
        public DataGridViewCell FindCell(string valueToFind, string columnName, int rowIndex, int columnIndex, bool isWholeWordSearch, bool isCaseSensitive)
        {
            if (valueToFind != null && RowCount > 0 && ColumnCount > 0 && (columnName == null || Columns.Contains(columnName) && Columns[columnName].Visible))
            {
                rowIndex = Math.Max(0, rowIndex);

                if (!isCaseSensitive)
                    valueToFind = valueToFind.ToLower();

                if (columnName != null)
                {
                    int c = Columns[columnName].Index;
                    if (columnIndex > c)
                        rowIndex++;
                    for (int r = rowIndex; r < RowCount; r++)
                    {
                        string value = Rows[r].Cells[c].FormattedValue.ToString();
                        if (!isCaseSensitive)
                            value = value.ToLower();

                        if (!isWholeWordSearch && value.Contains(valueToFind) || value.Equals(valueToFind))
                            return Rows[r].Cells[c];
                    }
                }
                else
                {
                    columnIndex = Math.Max(0, columnIndex);

                    for (int r = rowIndex; r < RowCount; r++)
                    {
                        for (int c = columnIndex; c < ColumnCount; c++)
                        {
                            if (!Rows[r].Cells[c].Visible)
                                continue;

                            string value = Rows[r].Cells[c].FormattedValue.ToString();
                            if (!isCaseSensitive)
                                value = value.ToLower();

                            if (!isWholeWordSearch && value.Contains(valueToFind) || value.Equals(valueToFind))
                                return Rows[r].Cells[c];
                        }

                        columnIndex = 0;
                    }
                }
            }

            return null;
        }

        #endregion


        #region public Cell methods

        /// <summary>
        /// 顯示指定欄位的篩選選單（MenuStrip）
        /// </summary>
        /// <param name="column">要顯示選單的欄位</param>
        public void ShowMenuStrip(DataGridViewColumn column)
        {
            if (Columns.Contains(column))
            {
                ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                if (cell != null)
                {
                    Cell_FilterPopup(cell, new ColumnHeaderCellEventArgs(cell.MenuStrip, column));
                }
            }
        }

        /// <summary>
        /// 取得或設定欄位上篩選按鈕影像的最大高度
        /// </summary>
        public int MaxFilterButtonImageHeight
        {
            get
            {
                return _maxFilterButtonImageHeight;
            }
            set
            {
                _maxFilterButtonImageHeight = value > ColumnHeaderCell.FilterButtonImageDefaultSize ? value : ColumnHeaderCell.FilterButtonImageDefaultSize;
            }
        }

        #endregion


        #region internal Cell methods

        /// <summary>
        /// 取得或設定所有欄位上篩選按鈕影像的最大高度（內部使用）
        /// </summary>
        internal int MaxAllCellHeight
        {
            get
            {
                return _maxAllCellHeight;
            }
            set
            {
                _maxAllCellHeight = value > ColumnHeaderCell.FilterButtonImageDefaultSize ? value : ColumnHeaderCell.FilterButtonImageDefaultSize;
            }
        }

        #endregion


        #region cells methods

        /// <summary>
        /// 取得目前所有已包裝為 ColumnHeaderCell 的欄位集合
        /// </summary>
        private IEnumerable<ColumnHeaderCell> FilterableCells
        {
            get
            {
                return from DataGridViewColumn c in Columns
                       where c.HeaderCell != null && c.HeaderCell is ColumnHeaderCell
                       select (c.HeaderCell as ColumnHeaderCell);
            }
        }

        #endregion


        #region column events

        /// <summary>
        /// 當欄位新增時，替換 HeaderCell 為 ColumnHeaderCell 並註冊事件處理器
        /// </summary>
        /// <param name="e">欄位事件參數</param>
        protected override void OnColumnAdded(DataGridViewColumnEventArgs e)
        {
            e.Column.SortMode = DataGridViewColumnSortMode.Programmatic;
            ColumnHeaderCell cell = new ColumnHeaderCell(this, e.Column.HeaderCell, FilterAndSortEnabled);
            cell.SortChanged += new ColumnHeaderCellEventHandler(Cell_SortChanged);
            cell.FilterChanged += new ColumnHeaderCellEventHandler(Cell_FilterChanged);
            cell.FilterPopup += new ColumnHeaderCellEventHandler(Cell_FilterPopup);
            e.Column.MinimumWidth = cell.MinimumSize.Width;
            if (ColumnHeadersHeight < cell.MinimumSize.Height)
                ColumnHeadersHeight = cell.MinimumSize.Height;
            e.Column.HeaderCell = cell;

            base.OnColumnAdded(e);
        }

        /// <summary>
        /// 當欄位移除時，解除事件並處理相關資源（包含 MenuStrip 的釋放或延遲釋放）
        /// </summary>
        /// <param name="e">欄位事件參數</param>
        protected override void OnColumnRemoved(DataGridViewColumnEventArgs e)
        {
            _filteredColumns.Remove(e.Column.Name);
            _filterOrderList.Remove(e.Column.Name);
            _sortOrderList.Remove(e.Column.Name);

            ColumnHeaderCell cell = e.Column.HeaderCell as ColumnHeaderCell;
            if (cell != null)
            {
                cell.SortChanged -= Cell_SortChanged;
                cell.FilterChanged -= Cell_FilterChanged;
                cell.FilterPopup -= Cell_FilterPopup;

                cell.CleanEvents();
                if (!e.Column.IsDataBound)
                    cell.MenuStrip.Dispose();
                else
                    _menuStripToDispose.Add(cell.MenuStrip);
            }
            base.OnColumnRemoved(e);
        }

        #endregion


        #region rows events

        /// <summary>
        /// 當列新增時清除已緩存的已篩選欄位清單，因為資料可能改變
        /// </summary>
        /// <param name="e">列事件參數</param>
        protected override void OnRowsAdded(DataGridViewRowsAddedEventArgs e)
        {
            if (e.RowIndex >= 0)
                _filteredColumns.Clear();
            base.OnRowsAdded(e);
        }

        /// <summary>
        /// 當列移除時清除已緩存的已篩選欄位清單，因為資料可能改變
        /// </summary>
        /// <param name="e">列事件參數</param>
        protected override void OnRowsRemoved(DataGridViewRowsRemovedEventArgs e)
        {
            if (e.RowIndex >= 0)
                _filteredColumns.Clear();
            base.OnRowsRemoved(e);
        }

        #endregion


        #region cell events

        /// <summary>
        /// 當儲存格值改變時，移除該欄位的已篩選狀態快取（若存在）
        /// </summary>
        /// <param name="e">儲存格事件參數</param>
        protected override void OnCellValueChanged(DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                _filteredColumns.Remove(Columns[e.ColumnIndex].Name);
            base.OnCellValueChanged(e);
        }

        #endregion


        #region filter events

        /// <summary>
        /// 建構完整的 RowFilter 字串，會依 _filterOrderList 的順序組合每個欄位的子篩選字串
        /// </summary>
        /// <returns>回傳組合後的篩選字串</returns>
        private string BuildFilterString()
        {
            StringBuilder sb = new StringBuilder("");
            string appx = "";

            foreach (string filterOrder in _filterOrderList)
            {
                DataGridViewColumn Column = Columns[filterOrder];

                if (Column != null)
                {
                    ColumnHeaderCell cell = Column.HeaderCell as ColumnHeaderCell;
                    if (cell != null)
                    {
                        if (cell.FilterAndSortEnabled && cell.ActiveFilterType != MenuStrip.FilterType.None)
                        {
                            sb.AppendFormat(appx + "(" + cell.FilterString + ")", Column.DataPropertyName);
                            if (_filterBuilerMode == FilterBuilerMode.And)
                                appx = " AND ";
                            else if (_filterBuilerMode == FilterBuilerMode.Or)
                                appx = " OR ";
                        }
                    }
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// 當欄位的篩選選單（MenuStrip）要求顯示時觸發，負責定位並顯示選單
        /// </summary>
        /// <param name="sender">事件來源（通常為 ColumnHeaderCell）</param>
        /// <param name="e">事件參數，包含 MenuStrip 與欄位</param>
        private void Cell_FilterPopup(object sender, ColumnHeaderCellEventArgs e)
        {
            if (Columns.Contains(e.Column))
            {
                MenuStrip filterMenu = e.FilterMenu;
                DataGridViewColumn column = e.Column;

                Rectangle rect = GetCellDisplayRectangle(column.Index, -1, true);

                if (_filteredColumns.Contains(column.Name))
                    filterMenu.Show(this, rect.Left, rect.Bottom, false);
                else
                {
                    _filteredColumns.Add(column.Name);
                    if (_filterOrderList.Count() > 0 && _filterOrderList.Last() == column.Name)
                        filterMenu.Show(this, rect.Left, rect.Bottom, true);
                    else
                        filterMenu.Show(this, rect.Left, rect.Bottom, column.Name);
                }
            }
        }

        /// <summary>
        /// 當欄位的篩選條件改變時觸發，更新內部的篩選順序並重新建構 FilterString
        /// </summary>
        /// <param name="sender">事件來源（通常為 ColumnHeaderCell）</param>
        /// <param name="e">事件參數，包含 MenuStrip 與欄位</param>
        private void Cell_FilterChanged(object sender, ColumnHeaderCellEventArgs e)
        {
            if (Columns.Contains(e.Column))
            {
                MenuStrip filterMenu = e.FilterMenu;
                DataGridViewColumn column = e.Column;

                _filterOrderList.Remove(column.Name);
                if (filterMenu.ActiveFilterType != MenuStrip.FilterType.None)
                    _filterOrderList.Add(column.Name);

                FilterString = BuildFilterString();

                if (_loadedFilter)
                {
                    _loadedFilter = false;
                    foreach (ColumnHeaderCell c in FilterableCells.Where(f => f.MenuStrip != filterMenu))
                        c.SetLoadedMode(false);
                }
            }
        }

        #endregion


        #region sort events

        /// <summary>
        /// 建構完整的 Sort 字串，依據 _sortOrderList 的順序組合每個欄位的排序子字串
        /// </summary>
        /// <returns>回傳組合後的排序字串</returns>
        private string BuildSortString()
        {
            StringBuilder sb = new StringBuilder("");
            string appx = "";

            foreach (string sortOrder in _sortOrderList)
            {
                DataGridViewColumn column = Columns[sortOrder];

                if (column != null)
                {
                    ColumnHeaderCell cell = column.HeaderCell as ColumnHeaderCell;
                    if (cell != null)
                    {
                        if (cell.FilterAndSortEnabled && cell.ActiveSortType != MenuStrip.SortType.None)
                        {
                            sb.AppendFormat(appx + cell.SortString, column.DataPropertyName);
                            appx = ", ";
                        }
                    }
                }
            }

            return sb.ToString();
        }

        /// <summary>
        /// 當欄位的排序設定改變時觸發，更新內部的排序順序並重新建構 SortString（會進而呼叫資料排序流程）
        /// </summary>
        /// <param name="sender">事件來源（通常為 ColumnHeaderCell）</param>
        /// <param name="e">事件參數，包含 MenuStrip 與欄位</param>
        private void Cell_SortChanged(object sender, ColumnHeaderCellEventArgs e)
        {
            if (Columns.Contains(e.Column))
            {
                MenuStrip filterMenu = e.FilterMenu;
                DataGridViewColumn column = e.Column;

                _sortOrderList.Remove(column.Name);
                if (filterMenu.ActiveSortType != MenuStrip.SortType.None)
                    _sortOrderList.Add(column.Name);
                SortString = BuildSortString();
            }
        }

        #endregion

    }
}
