﻿//using System.Windows.Forms;
//using Calin.TaskPulse.Core.Contract;

//namespace Calin.TaskPulse.Core.Logger
//{
//    /*
//        全自動 UI 日誌：只記錄 使用者有權限的按鈕或控制項操作
//        遞迴掛載：支援 GroupBox、Panel 等容器內所有控制項
//        JSON 格式：與登入、CRUD 日誌一致，方便分析
//        權限分析：可結合 CurrentUserService 分析不同權限使用者的操作行為
//    */

//    /// <summary>
//    /// UI 事件監聽器
//    /// </summary>
//    public class UIEventLoggerWithPermission
//    {
//        private readonly ICurrentUserService _currentUser;
//        private readonly IPermissionService _permissionService;
//        private readonly IActivityLogService _activityLogService;

//        public UIEventLoggerWithPermission(ICurrentUserService currentUser,
//                                           IPermissionService permissionService,
//                                           IActivityLogService activityLogService)
//        {
//            _currentUser = currentUser;
//            _permissionService = permissionService;
//            _activityLogService = activityLogService;
//        }

//        // 掛載到整個 Form
//        public void Attach(Form form)
//        {
//            foreach (Control control in form.Controls)
//            {
//                AttachControl(control, form.Name);
//            }
//        }

//        private void AttachControl(Control control, string formName)
//        {
//            // 如果是 Button 並且使用者有權限
//            // 只要呼叫 PermissionService.HasControlAccess 與 GetPermissionSource，就會自動使用快取。
//            if (control is Button btn)
//            {
//                if (_permissionService.HasAccess(_currentUser.UserId, btn.Name))
//                {
//                    btn.Click += async (s, e) =>
//                    {
//                        var source = _permissionService.GetPermissionSource(_currentUser.UserId, btn.Name);
//                        await _activityLogService.UIActionAsync(
//                            _currentUser.UserId,
//                            formName,
//                            btn.Name,
//                            "Click",
//                            new { PermissionSource = source }
//                        );
//                    };
//                }
//                else
//                {
//                    btn.Enabled = false; // 無權限自動停用
//                }
//            }

//            // 可加 TextBox 或其他控制項判斷，依需求
//            if (control is TextBox txt)
//            {
//                if (_permissionService.HasAccess(_currentUser.UserId, txt.Name))
//                {
//                    txt.TextChanged += async (s, e) =>
//                    {
//                        await _activityLogService.UIActionAsync(
//                            _currentUser.UserId,
//                            formName,
//                            txt.Name,
//                            "TextChanged",
//                            new { Value = txt.Text }
//                        );
//                    };
//                }
//                else
//                {
//                    txt.Enabled = false;
//                }
//            }

//            // 遞迴監聽子控制項
//            foreach (Control child in control.Controls)
//            {
//                AttachControl(child, formName);
//            }
//        }
//    }
//}
