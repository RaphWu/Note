//using System;
//using System.Collections.ObjectModel;
//using System.Linq;
//using Calin.TaskPulse.Entity.Contants;

//namespace Calin.TaskPulse.Core.ViewModels
//{
//    /// <summary>
//    /// ���@�u��@�� ViewModel - �h�� View �i�P�ɦ@�ΨçY�ɦP�B�C
//    /// </summary>
//    public class SharedTaskOrderViewModel : BindableBase
//    {
//        private int _id;
//        private string _workOrderNo;
//        private FlowStatus _status;
//        private int? _machineId;
//        private string _machineCode;
//        private int? _workstationId;
//        private string _workstationName;
//        private int _creatorId;
//        private string _creatorName;
//        private DateTime _creationDateTime;
//        private int? _maintenanceUnitId;
//        private string _maintenanceUnitName;
//        private ObservableCollection<int> _engineerIds;
//        private ObservableCollection<string> _engineerNames;
//        private DateTime _acceptedTime;
//        private int? _issueCategoryId;
//        private string _issueCategoryName;
//        private string _issueDescription;
//        private string _details;
//        private DateTime? _repairStarted;
//        private DateTime? _repairCompleted;
//        private long _repairDurationTick;
//        private DateTime? _fillingTime;
//        private int? _requestingUnitId;
//        private string _requestingUnitName;
//        private int? _feedbackEmployeeId;
//        private string _feedbackEmployeeName;
//        private string _feedback;
//        private DateTime? _outageStarted;
//        private DateTime? _outageEnded;
//        private long _outageDurationTick;
//        private string _responsible;

//        #region ���ݩ�

//        /// <summary>
//        /// ���o�γ]�w�u���ѧO�X�C
//        /// </summary>
//        public int Id
//        {
//            get => _id;
//            set => SetProperty(ref _id, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�u��s���C
//        /// </summary>
//        public string WorkOrderNo
//        {
//            get => _workOrderNo;
//            set => SetProperty(ref _workOrderNo, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�u��y�{���A�C
//        /// </summary>
//        public FlowStatus Status
//        {
//            get => _status;
//            set => SetProperty(ref _status, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���x�ѧO�X�C
//        /// </summary>
//        public int? MachineId
//        {
//            get => _machineId;
//            set => SetProperty(ref _machineId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���x�N�X�C
//        /// </summary>
//        public string MachineCode
//        {
//            get => _machineCode;
//            set => SetProperty(ref _machineCode, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�u�@���ѧO�X�C
//        /// </summary>
//        public int? WorkstationId
//        {
//            get => _workstationId;
//            set => SetProperty(ref _workstationId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�u�@���W�١C
//        /// </summary>
//        public string WorkstationName
//        {
//            get => _workstationName;
//            set => SetProperty(ref _workstationName, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�إߪ��ѧO�X�C
//        /// </summary>
//        public int CreatorId
//        {
//            get => _creatorId;
//            set => SetProperty(ref _creatorId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�إߪ̦W�١C
//        /// </summary>
//        public string CreatorName
//        {
//            get => _creatorName;
//            set => SetProperty(ref _creatorName, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�إߤ���ɶ��C
//        /// </summary>
//        public DateTime CreationDateTime
//        {
//            get => _creationDateTime;
//            set => SetProperty(ref _creationDateTime, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���׳���ѧO�X�C
//        /// </summary>
//        public int? MaintenanceUnitId
//        {
//            get => _maintenanceUnitId;
//            set => SetProperty(ref _maintenanceUnitId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���׳��W�١C
//        /// </summary>
//        public string MaintenanceUnitName
//        {
//            get => _maintenanceUnitName;
//            set => SetProperty(ref _maintenanceUnitName, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�u�汵���ɶ��C
//        /// </summary>
//        public DateTime AcceptedTime
//        {
//            get => _acceptedTime;
//            set => SetProperty(ref _acceptedTime, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���D���O�ѧO�X�C
//        /// </summary>
//        public int? IssueCategoryId
//        {
//            get => _issueCategoryId;
//            set => SetProperty(ref _issueCategoryId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���D���O�W�١C
//        /// </summary>
//        public string IssueCategoryName
//        {
//            get => _issueCategoryName;
//            set => SetProperty(ref _issueCategoryName, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���D�y�z�C
//        /// </summary>
//        public string IssueDescription
//        {
//            get => _issueDescription;
//            set => SetProperty(ref _issueDescription, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�ԲӤ��e�C
//        /// </summary>
//        public string Details
//        {
//            get => _details;
//            set => SetProperty(ref _details, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���׶}�l�ɶ��C
//        /// </summary>
//        public DateTime? RepairStarted
//        {
//            get => _repairStarted;
//            set => SetProperty(ref _repairStarted, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���ק����ɶ��C
//        /// </summary>
//        public DateTime? RepairCompleted
//        {
//            get => _repairCompleted;
//            set => SetProperty(ref _repairCompleted, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���׫���ɶ� (Tick)�C
//        /// </summary>
//        public long RepairDurationTick
//        {
//            get => _repairDurationTick;
//            set => SetProperty(ref _repairDurationTick, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w��g�ɶ��C
//        /// </summary>
//        public DateTime? FillingTime
//        {
//            get => _fillingTime;
//            set => SetProperty(ref _fillingTime, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�ШD����ѧO�X�C
//        /// </summary>
//        public int? RequestingUnitId
//        {
//            get => _requestingUnitId;
//            set => SetProperty(ref _requestingUnitId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�ШD���W�١C
//        /// </summary>
//        public string RequestingUnitName
//        {
//            get => _requestingUnitName;
//            set => SetProperty(ref _requestingUnitName, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�^�X���u�ѧO�X�C
//        /// </summary>
//        public int? FeedbackEmployeeId
//        {
//            get => _feedbackEmployeeId;
//            set => SetProperty(ref _feedbackEmployeeId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�^�X���u�W�١C
//        /// </summary>
//        public string FeedbackEmployeeName
//        {
//            get => _feedbackEmployeeName;
//            set => SetProperty(ref _feedbackEmployeeName, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�^�X���e�C
//        /// </summary>
//        public string Feedback
//        {
//            get => _feedback;
//            set => SetProperty(ref _feedback, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�����}�l�ɶ��C
//        /// </summary>
//        public DateTime? OutageStarted
//        {
//            get => _outageStarted;
//            set => SetProperty(ref _outageStarted, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���������ɶ��C
//        /// </summary>
//        public DateTime? OutageEnded
//        {
//            get => _outageEnded;
//            set => SetProperty(ref _outageEnded, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w��������ɶ� (Tick)�C
//        /// </summary>
//        public long OutageDurationTick
//        {
//            get => _outageDurationTick;
//            set => SetProperty(ref _outageDurationTick, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�t�d�H�C
//        /// </summary>
//        public string Responsible
//        {
//            get => _responsible;
//            set => SetProperty(ref _responsible, value);
//        }

//        #endregion

//        #region �h��h���Y

//        /// <summary>
//        /// ���o�γ]�w�u�{�v�ѧO�X���X�C
//        /// </summary>
//        public ObservableCollection<int> EngineerIds
//        {
//            get => _engineerIds;
//            set
//            {
//                if (_engineerIds != null)
//                {
//                    _engineerIds.CollectionChanged -= OnCollectionChanged;
//                }
//                SetProperty(ref _engineerIds, value);
//                if (_engineerIds != null)
//                {
//                    _engineerIds.CollectionChanged += OnCollectionChanged;
//                }
//            }
//        }

//        /// <summary>
//        /// ���o�γ]�w�u�{�v�W�ٶ��X�C
//        /// </summary>
//        public ObservableCollection<string> EngineerNames
//        {
//            get => _engineerNames;
//            set
//            {
//                if (_engineerNames != null)
//                {
//                    _engineerNames.CollectionChanged -= OnCollectionChanged;
//                }
//                SetProperty(ref _engineerNames, value);
//                if (_engineerNames != null)
//                {
//                    _engineerNames.CollectionChanged += OnCollectionChanged;
//                }
//            }
//        }

//        #endregion

//        #region �غc�禡

//        /// <summary>
//        /// ��l�� <see cref="SharedTaskOrderViewModel"/> ���O���s�������C
//        /// </summary>
//        public SharedTaskOrderViewModel()
//        {
//            _engineerIds = new ObservableCollection<int>();
//            _engineerNames = new ObservableCollection<string>();

//            _engineerIds.CollectionChanged += OnCollectionChanged;
//            _engineerNames.CollectionChanged += OnCollectionChanged;
//        }

//        /// <summary>
//        /// �ϥΫ��w�� DTO ��l�� <see cref="SharedTaskOrderViewModel"/> ���O���s�������C
//        /// </summary>
//        /// <param name="dto">�u���ƶǿ骫��C</param>
//        public SharedTaskOrderViewModel(WorkOrderDto dto) : this()
//        {
//            if (dto == null) return;
//            LoadFromDto(dto);
//        }

//        #endregion

//        #region DTO �ഫ

//        /// <summary>
//        /// �q���w�� DTO ���J��Ʀܦ� ViewModel�C
//        /// </summary>
//        /// <param name="dto">�u���ƶǿ骫��C</param>
//        public void LoadFromDto(WorkOrderDto dto)
//        {
//            if (dto == null) return;

//            Id = dto.Id;
//            WorkOrderNo = dto.WorkOrderNo;
//            Status = dto.Status;
//            MachineId = dto.MachineId;
//            MachineCode = dto.MachineCode;
//            WorkstationId = dto.WorkstationId;
//            WorkstationName = dto.WorkstationName;
//            CreatorId = dto.CreatorId;
//            CreatorName = dto.CreatorName;
//            CreationDateTime = dto.CreationDateTime;
//            MaintenanceUnitId = dto.MaintenanceUnitId;
//            MaintenanceUnitName = dto.MaintenanceUnitName;
//            AcceptedTime = dto.AcceptedTime;
//            IssueCategoryId = dto.IssueCategoryId;
//            IssueCategoryName = dto.IssueCategoryName;
//            IssueDescription = dto.IssueDescription;
//            Details = dto.Details;
//            RepairStarted = dto.RepairStarted;
//            RepairCompleted = dto.RepairCompleted;
//            RepairDurationTick = dto.RepairDurationTick;
//            FillingTime = dto.FillingTime;
//            RequestingUnitId = dto.RequestingUnitId;
//            RequestingUnitName = dto.RequestingUnitName;
//            FeedbackEmployeeId = dto.FeedbackEmployeeId;
//            FeedbackEmployeeName = dto.FeedbackEmployeeName;
//            Feedback = dto.Feedback;
//            OutageStarted = dto.OutageStarted;
//            OutageEnded = dto.OutageEnded;
//            OutageDurationTick = dto.OutageDurationTick;
//            Responsible = dto.Responsible;

//            if (dto.EngineerIds != null)
//            {
//                EngineerIds = new ObservableCollection<int>(dto.EngineerIds);
//            }
//            if (dto.EngineerNames != null)
//            {
//                EngineerNames = new ObservableCollection<string>(dto.EngineerNames);
//            }
//        }

//        /// <summary>
//        /// �N�� ViewModel ������ഫ�� DTO�C
//        /// </summary>
//        /// <returns>�u���ƶǿ骫��C</returns>
//        public WorkOrderDto ToDto()
//        {
//            return new WorkOrderDto
//            {
//                Id = Id,
//                WorkOrderNo = WorkOrderNo,
//                Status = Status,
//                MachineId = MachineId,
//                MachineCode = MachineCode,
//                WorkstationId = WorkstationId,
//                WorkstationName = WorkstationName,
//                CreatorId = CreatorId,
//                CreatorName = CreatorName,
//                CreationDateTime = CreationDateTime,
//                MaintenanceUnitId = MaintenanceUnitId,
//                MaintenanceUnitName = MaintenanceUnitName,
//                AcceptedTime = AcceptedTime,
//                IssueCategoryId = IssueCategoryId,
//                IssueCategoryName = IssueCategoryName,
//                IssueDescription = IssueDescription,
//                Details = Details,
//                RepairStarted = RepairStarted,
//                RepairCompleted = RepairCompleted,
//                RepairDurationTick = RepairDurationTick,
//                FillingTime = FillingTime,
//                RequestingUnitId = RequestingUnitId,
//                RequestingUnitName = RequestingUnitName,
//                FeedbackEmployeeId = FeedbackEmployeeId,
//                FeedbackEmployeeName = FeedbackEmployeeName,
//                Feedback = Feedback,
//                OutageStarted = OutageStarted,
//                OutageEnded = OutageEnded,
//                OutageDurationTick = OutageDurationTick,
//                Responsible = Responsible,
//                EngineerIds = EngineerIds?.ToList(),
//                EngineerNames = EngineerNames?.ToList()
//            };
//        }

//        #endregion

//        #region INotifyPropertyChanged

//        /// <summary>
//        /// �B�z���X�ܧ�ƥ�C
//        /// </summary>
//        /// <param name="sender">�ƥ�ӷ��C</param>
//        /// <param name="e">���X�ܧ�ƥ�޼ơC</param>
//        private void OnCollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
//        {
//            if (sender == _engineerIds)
//                OnPropertyChanged(nameof(EngineerIds));
//            else if (sender == _engineerNames)
//                OnPropertyChanged(nameof(EngineerNames));
//        }

//        #endregion
//    }
//}
