using System.ComponentModel;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.ViewModels
{
    /// <summary>
    /// �D�x�������� BaseViewModelUserControl - �M���]�p���ۮe�ʳ]�p
    /// ��ڨϥήɽШϥΪx������ BaseViewModelUserControl&lt;TViewModel&gt;
    /// </summary>
    [DesignerCategory("")]
    public abstract class BaseViewModelUserControlDesigner : UserControl
    {
        /// <summary>
        /// �ˬd ViewModel �O�_�w�j�w
        /// </summary>
        protected bool IsViewModelBound { get; set; }

        /// <summary>
        /// ���U��k�G�j�w����ݩʨ� ViewModel
        /// </summary>
        protected void BindControl(
            Control control,
            string controlProperty,
            object dataSource,
            string dataMember,
            bool formattingEnabled = true,
            DataSourceUpdateMode updateMode = DataSourceUpdateMode.OnPropertyChanged)
        {
            if (control == null) return;

            control.DataBindings.Clear();
            control.DataBindings.Add(
                controlProperty,
                dataSource,
                dataMember,
                formattingEnabled,
                updateMode);
        }

        /// <summary>
        /// ���U��k�G�j�w TextBox
        /// </summary>
        protected void BindTextBox(TextBox textBox, object dataSource, string dataMember)
        {
            BindControl(textBox, "Text", dataSource, dataMember);
        }

        /// <summary>
        /// ���U��k�G�j�w CheckBox
        /// </summary>
        protected void BindCheckBox(CheckBox checkBox, object dataSource, string dataMember)
        {
            BindControl(checkBox, "Checked", dataSource, dataMember);
        }

        /// <summary>
        /// ���U��k�G�j�w ComboBox
        /// </summary>
        protected void BindComboBox(ComboBox comboBox, object dataSource, string dataMember)
        {
            BindControl(comboBox, "SelectedValue", dataSource, dataMember);
        }

        /// <summary>
        /// ���U��k�G�j�w Label
        /// </summary>
        protected void BindLabel(Label label, object dataSource, string dataMember)
        {
            BindControl(label, "Text", dataSource, dataMember);
        }

        /// <summary>
        /// �M���Ҧ��������Ƹj�w
        /// </summary>
        protected void ClearAllBindings()
        {
            ClearBindingsRecursive(this);
        }

        private void ClearBindingsRecursive(Control control)
        {
            if (control == null) return;

            if (control.DataBindings.Count > 0)
            {
                control.DataBindings.Clear();
            }

            foreach (Control child in control.Controls)
            {
                ClearBindingsRecursive(child);
            }
        }
    }
}
