﻿namespace Calin.TaskPulse.Core.Contracts.DB
{
    public interface IMachineViewMode
    {
    }
}
