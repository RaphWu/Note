﻿using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Contracts
{
    /// <summary>
    /// 使用者切換操作服務。
    /// </summary>
    public interface ICurrentUserService
    {
        /********************
         * Switch User
         ********************/
        /// <summary>
        /// 刷新目前使用者的資料。
        /// </summary>
        /// <param name="employee">新的使用者資料。</param>
        void SwitchCurrentUser(Employee employee);

        /// <summary>
        /// 將目前使用者切換為指定使用者 Id。
        /// </summary>
        /// <param name="userId">使用者 Id。</param>
        void SwitchCurrentUser(int userId);

        /// <summary>
        /// 將目前使用者切換為指定員工工號。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        void SwitchCurrentUser(string employeeId);

        /********************
         * 特定使用者
         ********************/
        /// <summary>
        /// 將目前使用者切換為訪客。
        /// </summary>
        void SwitchCurrentUserToGuest();

        /// <summary>
        /// 管理員登入。
        /// </summary>
        void AdminLogin();
    }
}
