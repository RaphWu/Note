﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Sunny.UI;

namespace Calin.TaskPulse.Core.WinForms
{
    /// <summary>
    /// WinForm 擴充功能。
    /// </summary>
    public static class WinFormExtension
    {
        ///// <summary>
        ///// WinForm 跨執行緒修改 Control。
        ///// </summary>
        ///// <param name="control">Control 物件。</param>
        ///// <param name="action">要執行的動作。</param>
        //public static void InvokeIfRequired(this Control control, MethodInvoker action)
        //{
        //    if (control.InvokeRequired)
        //        control.Invoke(action);
        //    else
        //        action();
        //}

        /// <summary>
        /// 在UI執行緒執行方法。
        /// </summary>
        public static void RunOnUIThread(Action action)
        {
            if (Application.OpenForms.Count == 0)
            {
                action(); // 若沒有開啟的窗體（例如測試模式），直接執行
                return;
            }

            var form = Application.OpenForms[0];
            if (form.InvokeRequired)
                form.BeginInvoke(action);
            else
                action();
        }

        public static bool IsNodeVisible(this TreeNode node, TreeView treeView)
        {
            if (node == null || treeView == null)
                return false;

            // 獲取節點的邊界
            Rectangle nodeBounds = node.Bounds;

            // 獲取 TreeView 的顯示區域
            Rectangle visibleBounds = treeView.ClientRectangle;

            // 檢查節點的邊界是否與顯示區域重疊
            return visibleBounds.IntersectsWith(nodeBounds);
        }

        public static bool IsNodeVisible(this TreeNode node, UITreeView treeView)
        {
            if (node == null || treeView == null)
                return false;

            // 獲取節點的邊界
            Rectangle nodeBounds = node.Bounds;

            // 獲取 TreeView 的顯示區域
            Rectangle visibleBounds = treeView.ClientRectangle;

            // 檢查節點的邊界是否與顯示區域重疊
            return visibleBounds.IntersectsWith(nodeBounds);
        }
    }
}
