﻿using System.Drawing;
using System.Windows.Forms;
using Sunny.UI;

namespace Calin.TaskPulse.Core.WinForms
{
    public class SunnyUiHelper
    {
        /// <summary>
        /// 根據 Sunny.UI 標題列與動態內容自動調整整體大小。
        /// </summary>
        /// <param name="form">要調整的 UIForm</param>
        /// <param name="contentPanel">主要內容的 TableLayoutPanel 或主容器</param>
        public static void AdjustFormLayout(UIForm form, Control contentPanel)
        {
            if (form == null || contentPanel == null)
                return;

            // 1️⃣ 取得標題文字實際高度
            //int titleTextHeight = 0;
            //if (form.ShowTitle && !string.IsNullOrEmpty(form.Text))
            //{
            //    var titleSize = TextRenderer.MeasureText(form.Text, form.TitleFont);
            //    //titleTextHeight = titleSize.Height + 0;
            //}

            // 2️⃣ 計算內容的預期高度
            int contentHeight = contentPanel.PreferredSize.Height;

            // 3️⃣ 加上 Padding 與按鈕列預留
            int totalHeight = contentHeight + form.Padding.Top + form.Padding.Bottom;

            // 4️⃣ Sunny.UI 的 TitleHeight 也要更新，否則仍會吃掉
            //if (form.TitleHeight < titleTextHeight)
            //    form.TitleHeight = titleTextHeight;

            // 5️⃣ 設定 ClientSize，保留標題列
            form.ClientSize = new Size(
                contentPanel.PreferredSize.Width + form.Padding.Left + form.Padding.Right,
                totalHeight
            );

            form.Padding = new Padding(form.Padding.Left,
                                       form.Padding.Top + 10,
                                       form.Padding.Right,
                                       form.Padding.Bottom);

            // 6️⃣ 重新排版
            form.PerformLayout();
            form.Update();
        }
    }
}
