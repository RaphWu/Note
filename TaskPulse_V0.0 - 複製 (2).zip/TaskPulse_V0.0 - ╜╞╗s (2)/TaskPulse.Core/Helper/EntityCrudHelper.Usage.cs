﻿/*
 * 這個檔案展示如何使用 EntityCrudHelper v2.0 來簡化 CRUD 操作
 * 
 * v2.0 主要變更：
 * - HandleUpClickAsync 和 HandleDownClickAsync 已整合交換邏輯
 * - 不再需要額外的 SwapOrderNo 方法
 * - 進一步減少代碼量（每個實體再減少 20-30 行）
 * 
 * 使用範例：將現有的 Setup_MachineCategory.cs 重構為使用 EntityCrudHelper v2.0
 * 
 * 主要改進：
 * 1. 減少重複代碼（80%）
 * 2. 統一錯誤處理
 * 3. 統一驗證邏輯
 * 4. 簡化排序操作（整合交換邏輯）
 * 5. 不再需要 SwapOrderNo 方法
 * 
 * 使用步驟：
 * 
 * 1. 在類別中建立配置物件：
 * 
 * private EntityCrudConfig<MachineCategory> _categoryConfig;
 * 
 * 2. 在建構函數中初始化配置：
 * 
 * _categoryConfig = new EntityCrudConfig<MachineCategory>
 * {
 *     EntityTypeName = PropertyText.Title.MachineCategory,
 *     NameSelector = e => e.CategoryName,
 *     OrderNoSelector = e => e.OrderNo,
 *     NameGetter = e => e.CategoryName,
 *     NameSetter = (e, name) => e.CategoryName = name,
 *     OrderNoGetter = e => e.OrderNo,
 *     OrderNoSetter = (e, orderNo) => e.OrderNo = orderNo,
 *     MaxNameLength = 30,
 *     ExistsChecker = name => _categories.Any(m => m.CategoryName == name),
 *     EntityFinder = id => _categories.FirstOrDefault(m => m.Id == id),
 *     EntityFactory = () => new MachineCategory()
 * };
 * 
 * 3. 使用輔助方法替換原有的 CRUD 方法：
 * 
 * // 原本的 Category_Create_Click 方法可以簡化為：
 * private async void Category_Create_Click(object sender, EventArgs e)
 * {
 *     await EntityCrudHelper.CreateEntityAsync(
 *         _scope,
 *         _logger,
 *         _context,
 *         _categories,
 *         _categoryConfig,
 *         _cacheManager,
 *         () => _cacheManager.RequestMachineUpdateDelay(),
 *         UpdateCategoriesViewAsync,
 *         id => List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == id)
 *     );
 * }
 * 
 * // 原本的 Category_Edit_Click 方法可以簡化為：
 * private async void Category_Edit_Click(object sender, EventArgs e)
 * {
 *     if (_vmCategory != null)
 *     {
 *         await EntityCrudHelper.EditEntityAsync(
 *             _scope,
 *             _logger,
 *             _context,
 *             _categories,
 *             _categoryConfig,
 *             _cacheManager,
 *             () => _cacheManager.RequestMachineUpdateDelay(),
 *             UpdateCategoriesViewAsync,
 *             _vmCategory.Id,
 *             _vmCategory.Name,
 *             id => List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == id)
 *         );
 *     }
 * }
 * 
 * // 原本的 Category_Delete_Click 方法可以簡化為：
 * private async void Category_Delete_Click(object sender, EventArgs e)
 * {
 *     if (_vmCategory != null)
 *     {
 *         await EntityCrudHelper.DeleteEntityAsync(
 *             _logger,
 *             _context,
 *             _categories,
 *             _categoryConfig,
 *             _cacheManager,
 *             () => _cacheManager.RequestMachineUpdateDelay(),
 *             UpdateCategoriesViewAsync,
 *             _vmCategory.Id,
 *             _vmCategory.Name
 *         );
 *     }
 * }
 * 
 * // ============================================
 * // v2.0 新版排序方法（整合版本）
 * // ============================================
 * 
 * // 原本的 Category_Up_Click 方法可以簡化為（v2.0）：
 * private async void Category_Up_Click(object sender, EventArgs e)
 * {
 *     await EntityCrudHelper.HandleUpClickAsync<ListViewModel, MachineCategory>(
 *         _logger,
 *         _context,
 *         _categoryConfig,
 *         _cacheManager,
 *         () => _cacheManager.RequestMachineUpdateDelay(),
 *         UpdateCategoriesViewAsync,
 *         _vmCategories,
 *         _vmCategory,
 *         vm => vm.OrderNo,
 *         vm => vm.Id,
 *         id => List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == id)
 *     );
 * }
 * 
 * // 原本的 Category_Down_Click 方法可以簡化為（v2.0）：
 * private async void Category_Down_Click(object sender, EventArgs e)
 * {
 *     await EntityCrudHelper.HandleDownClickAsync<ListViewModel, MachineCategory>(
 *         _logger,
 *         _context,
 *         _categoryConfig,
 *         _cacheManager,
 *         () => _cacheManager.RequestMachineUpdateDelay(),
 *         UpdateCategoriesViewAsync,
 *         _vmCategories,
 *         _vmCategory,
 *         vm => vm.OrderNo,
 *         vm => vm.Id,
 *         id => List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == id)
 *     );
 * }
 * 
 * // ✨ SwapCategoryOrderNo 方法不再需要！（v2.0 改進）
 * // 交換邏輯已經整合在 HandleUpClickAsync 和 HandleDownClickAsync 中
 * 
 * // SelectedIndexChanged 事件可以簡化為：
 * private async void List_Categories_SelectedIndexChanged(object sender, EventArgs e)
 * {
 *     _vmCategory = List_Categories.SelectedItem as ListViewModel;
 *     
 *     EntityCrudHelper.UpdateButtonStates(
 *         _vmCategory,
 *         _vmCategories,
 *         Category_Edit,
 *         Category_Delete,
 *         Category_Up,
 *         Category_Down
 *     );
 * 
 *     if (_vmCategory != null)
 *     {
 *         HeadLabel_Category.Text = $"{PropertyText.Title.MachineCategory} ({_vmCategories.Count()})";
 *         await UpdateTypesViewAsync();
 *     }
 *     else
 *     {
 *         List_Types.DataSource = null;
 *         HeadLabel_Category.Text = $"{PropertyText.Title.MachineCategory} (0)";
 *     }
 * }
 * 
 * v2.0 優點：
 * - 所有 CRUD 操作使用統一的錯誤處理
 * - 驗證邏輯集中管理
 * - 減少約 80% 的重複代碼（v1.0 是 70%）
 * - 更容易維護和測試
 * - 統一的用戶體驗
 * - ✨ 不再需要為每個實體寫 SwapOrderNo 方法
 * 
 * v2.0 vs v1.0 代碼對比：
 * 
 * v1.0 排序操作（約 50 行）：
 * --------------------------------
 * private async void Category_Up_Click() {
 *     EntityCrudHelper.HandleUpClick(..., SwapCategoryOrderNo, ...);
 * }
 * 
 * private async void Category_Down_Click() {
 *     EntityCrudHelper.HandleDownClick(..., SwapCategoryOrderNo, ...);
 * }
 * 
 * private async Task<bool> SwapCategoryOrderNo(int id1, int id2) {
 *     return await EntityCrudHelper.SwapOrderNoAsync(...);  // 需要手寫
 * }
 * 
 * v2.0 排序操作（約 26 行）：
 * --------------------------------
 * private async void Category_Up_Click() {
 *     await EntityCrudHelper.HandleUpClickAsync<ListViewModel, MachineCategory>(...);
 * }
 * 
 * private async void Category_Down_Click() {
 *     await EntityCrudHelper.HandleDownClickAsync<ListViewModel, MachineCategory>(...);
 * }
 * 
 * // SwapCategoryOrderNo 不再需要！交換邏輯已整合
 * 
 * 代碼減少：約 50 行 → 26 行（48% 減少）
 * 加上 CRUD 操作的減少，總體減少約 80%！
 */

namespace Calin.TaskPulse.Core.Helper
{
    // 此檔案僅作為使用範例和文檔
    // 實際使用時請參考上述註解中的說明
}
