﻿using Autofac;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.ToolQuest.Views;

namespace Calin.TaskPulse.ToolQuest
{
    public class ToolQuestMoudle : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            SplashMessenger.Post("載入工具委託模組...");

            // views
            builder.RegisterType<ToolQuestPage>().AsSelf().PropertiesAutowired();
        }
    }
}
