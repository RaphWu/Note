﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class MF_CreateFlow
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_IssueDescription = new Sunny.UI.UILabel();
            this.Label_OutageStarted = new Sunny.UI.UILabel();
            this.lblMachineList = new Sunny.UI.UILabel();
            this.lblCreator = new Sunny.UI.UILabel();
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Button_Clear = new Sunny.UI.UISymbolButton();
            this.Button_OK = new Sunny.UI.UISymbolButton();
            this.Button_Cancel = new Sunny.UI.UISymbolButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ModelWs = new Sunny.UI.UITextBox();
            this.lblModel = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UITextBox();
            this.IssueDescription = new Sunny.UI.UIRichTextBox();
            this.RequestingUnit = new Sunny.UI.UIComboBox();
            this.lblRequestingUnit = new Sunny.UI.UILabel();
            this.MachineList = new Sunny.UI.UITextBox();
            this.OutageStartedAvailable = new Sunny.UI.UICheckBox();
            this.OutageStarted = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.TLP.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label_IssueDescription
            // 
            this.Label_IssueDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueDescription.Location = new System.Drawing.Point(19, 209);
            this.Label_IssueDescription.Name = "Label_IssueDescription";
            this.Label_IssueDescription.Size = new System.Drawing.Size(80, 29);
            this.Label_IssueDescription.TabIndex = 37;
            this.Label_IssueDescription.Text = "Issue";
            this.Label_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_OutageStarted
            // 
            this.Label_OutageStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageStarted.Location = new System.Drawing.Point(19, 170);
            this.Label_OutageStarted.Name = "Label_OutageStarted";
            this.Label_OutageStarted.Size = new System.Drawing.Size(80, 29);
            this.Label_OutageStarted.TabIndex = 34;
            this.Label_OutageStarted.Text = "Outage";
            this.Label_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblMachineList
            // 
            this.lblMachineList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblMachineList.BackColor = System.Drawing.Color.Transparent;
            this.lblMachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.lblMachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblMachineList.Location = new System.Drawing.Point(19, 92);
            this.lblMachineList.Name = "lblMachineList";
            this.lblMachineList.Size = new System.Drawing.Size(80, 29);
            this.lblMachineList.TabIndex = 28;
            this.lblMachineList.Text = "機台";
            this.lblMachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCreator
            // 
            this.lblCreator.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCreator.BackColor = System.Drawing.Color.Transparent;
            this.lblCreator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.lblCreator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblCreator.Location = new System.Drawing.Point(19, 53);
            this.lblCreator.Name = "lblCreator";
            this.lblCreator.Size = new System.Drawing.Size(80, 29);
            this.lblCreator.TabIndex = 26;
            this.lblCreator.Text = "Creator";
            this.lblCreator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 1;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Controls.Add(this.panel1, 0, 1);
            this.TLP.Controls.Add(this.panel2, 0, 0);
            this.TLP.Location = new System.Drawing.Point(3, 40);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 2;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.TLP.Size = new System.Drawing.Size(385, 467);
            this.TLP.TabIndex = 38;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Button_Clear);
            this.panel1.Controls.Add(this.Button_OK);
            this.panel1.Controls.Add(this.Button_Cancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 360);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(379, 104);
            this.panel1.TabIndex = 0;
            // 
            // Button_Clear
            // 
            this.Button_Clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Clear.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Clear.Location = new System.Drawing.Point(245, 51);
            this.Button_Clear.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Clear.Name = "Button_Clear";
            this.Button_Clear.Radius = 10;
            this.Button_Clear.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_Clear.Size = new System.Drawing.Size(110, 35);
            this.Button_Clear.Symbol = 362746;
            this.Button_Clear.TabIndex = 4;
            this.Button_Clear.Text = "全部清除";
            this.Button_Clear.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Clear.Click += new System.EventHandler(this.Button_Clear_Click);
            // 
            // Button_OK
            // 
            this.Button_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_OK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_OK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_OK.Location = new System.Drawing.Point(115, 10);
            this.Button_OK.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_OK.Name = "Button_OK";
            this.Button_OK.Radius = 10;
            this.Button_OK.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_OK.Size = new System.Drawing.Size(110, 76);
            this.Button_OK.TabIndex = 3;
            this.Button_OK.Text = "建立工單";
            this.Button_OK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_OK.Click += new System.EventHandler(this.uiButton_OK_Click);
            // 
            // Button_Cancel
            // 
            this.Button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Button_Cancel.Location = new System.Drawing.Point(245, 10);
            this.Button_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Cancel.Name = "Button_Cancel";
            this.Button_Cancel.Radius = 10;
            this.Button_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_Cancel.Size = new System.Drawing.Size(110, 35);
            this.Button_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.Button_Cancel.Symbol = 361453;
            this.Button_Cancel.TabIndex = 2;
            this.Button_Cancel.Text = "取消";
            this.Button_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Cancel.Click += new System.EventHandler(this.uiButton_Cancel_Click);
            // 
            // panel2
            // 
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.Controls.Add(this.OutageStarted);
            this.panel2.Controls.Add(this.ModelWs);
            this.panel2.Controls.Add(this.lblModel);
            this.panel2.Controls.Add(this.Creator);
            this.panel2.Controls.Add(this.IssueDescription);
            this.panel2.Controls.Add(this.RequestingUnit);
            this.panel2.Controls.Add(this.lblRequestingUnit);
            this.panel2.Controls.Add(this.lblCreator);
            this.panel2.Controls.Add(this.Label_IssueDescription);
            this.panel2.Controls.Add(this.lblMachineList);
            this.panel2.Controls.Add(this.MachineList);
            this.panel2.Controls.Add(this.Label_OutageStarted);
            this.panel2.Controls.Add(this.OutageStartedAvailable);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(379, 351);
            this.panel2.TabIndex = 1;
            // 
            // ModelWs
            // 
            this.ModelWs.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ModelWs.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelWs.Location = new System.Drawing.Point(105, 131);
            this.ModelWs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ModelWs.MinimumSize = new System.Drawing.Size(1, 16);
            this.ModelWs.Name = "ModelWs";
            this.ModelWs.Padding = new System.Windows.Forms.Padding(5);
            this.ModelWs.ShowButton = true;
            this.ModelWs.ShowText = false;
            this.ModelWs.Size = new System.Drawing.Size(255, 29);
            this.ModelWs.TabIndex = 30;
            this.ModelWs.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ModelWs.Watermark = "";
            this.ModelWs.ButtonClick += new System.EventHandler(this.ModelList_ButtonClick);
            // 
            // lblModel
            // 
            this.lblModel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblModel.BackColor = System.Drawing.Color.Transparent;
            this.lblModel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.lblModel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblModel.Location = new System.Drawing.Point(19, 131);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(80, 29);
            this.lblModel.TabIndex = 30;
            this.lblModel.Text = "機種";
            this.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Creator
            // 
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.Location = new System.Drawing.Point(105, 53);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(5);
            this.Creator.ShowButton = true;
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(255, 29);
            this.Creator.TabIndex = 30;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            this.Creator.ButtonClick += new System.EventHandler(this.Creator_ButtonClick);
            // 
            // IssueDescription
            // 
            this.IssueDescription.FillColor = System.Drawing.Color.White;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(105, 209);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(2);
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(255, 125);
            this.IssueDescription.TabIndex = 38;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // RequestingUnit
            // 
            this.RequestingUnit.DataSource = null;
            this.RequestingUnit.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.RequestingUnit.FillColor = System.Drawing.Color.White;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.RequestingUnit.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.RequestingUnit.Location = new System.Drawing.Point(105, 14);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MaxDropDownItems = 12;
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(63, 0);
            this.RequestingUnit.Name = "RequestingUnit";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.RequestingUnit.Size = new System.Drawing.Size(255, 29);
            this.RequestingUnit.SymbolSize = 24;
            this.RequestingUnit.TabIndex = 29;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // lblRequestingUnit
            // 
            this.lblRequestingUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRequestingUnit.BackColor = System.Drawing.Color.Transparent;
            this.lblRequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.lblRequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.lblRequestingUnit.Location = new System.Drawing.Point(19, 14);
            this.lblRequestingUnit.Name = "lblRequestingUnit";
            this.lblRequestingUnit.Size = new System.Drawing.Size(80, 29);
            this.lblRequestingUnit.TabIndex = 28;
            this.lblRequestingUnit.Text = "需求單位";
            this.lblRequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineList
            // 
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.Location = new System.Drawing.Point(105, 92);
            this.MachineList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(5);
            this.MachineList.ShowButton = true;
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(255, 29);
            this.MachineList.TabIndex = 29;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            this.MachineList.ButtonClick += new System.EventHandler(this.MachineId_ButtonClick);
            // 
            // OutageStartedAvailable
            // 
            this.OutageStartedAvailable.CheckBoxSize = 18;
            this.OutageStartedAvailable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.OutageStartedAvailable.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OutageStartedAvailable.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageStartedAvailable.Location = new System.Drawing.Point(327, 169);
            this.OutageStartedAvailable.MinimumSize = new System.Drawing.Size(1, 1);
            this.OutageStartedAvailable.Name = "OutageStartedAvailable";
            this.OutageStartedAvailable.Size = new System.Drawing.Size(32, 29);
            this.OutageStartedAvailable.TabIndex = 39;
            this.OutageStartedAvailable.CheckedChanged += new System.EventHandler(this.OutageStartedAvailable_CheckedChanged);
            // 
            // OutageStarted
            // 
            this.OutageStarted.DateFormat = "yyyy/MM/dd HH:mm";
            this.OutageStarted.DurationControl = null;
            this.OutageStarted.EndTimeControl = null;
            this.OutageStarted.FillColor = System.Drawing.Color.White;
            this.OutageStarted.Location = new System.Drawing.Point(105, 170);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Size = new System.Drawing.Size(217, 29);
            this.OutageStarted.StartTimeControl = null;
            this.OutageStarted.TabIndex = 40;
            this.OutageStarted.Value = null;
            // 
            // MF_CreateFlow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(398, 507);
            this.Controls.Add(this.TLP);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MF_CreateFlow";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 12F);
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 1141, 732);
            this.Load += new System.EventHandler(this.CreateFlow_Load);
            this.Shown += new System.EventHandler(this.CreateFlow_Shown);
            this.TLP.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UILabel Label_IssueDescription;
        private Sunny.UI.UILabel Label_OutageStarted;
        private Sunny.UI.UILabel lblMachineList;
        private Sunny.UI.UILabel lblCreator;
        private System.Windows.Forms.TableLayoutPanel TLP;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolButton Button_OK;
        private Sunny.UI.UISymbolButton Button_Cancel;
        private Sunny.UI.UISymbolButton Button_Clear;
        private Sunny.UI.UIComboBox RequestingUnit;
        private Sunny.UI.UILabel lblRequestingUnit;
        private Sunny.UI.UIRichTextBox IssueDescription;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UICheckBox OutageStartedAvailable;
        private Sunny.UI.UILabel lblModel;
        private Sunny.UI.UITextBox ModelWs;
        private Core.WinForms.UIDurationDateTimePicker OutageStarted;
    }
}
