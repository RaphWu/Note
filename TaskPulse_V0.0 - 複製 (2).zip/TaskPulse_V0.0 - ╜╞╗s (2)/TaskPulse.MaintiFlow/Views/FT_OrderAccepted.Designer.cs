﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class FT_OrderAccepted
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.IssueDescription = new Sunny.UI.UITextBox();
            this.uiLabel_IssueDescription = new Sunny.UI.UILabel();
            this.AcceptedTime = new Sunny.UI.UITextBox();
            this.uiLabel_AcceptedTime = new Sunny.UI.UILabel();
            this.IssueCategory = new Sunny.UI.UITextBox();
            this.uiLabel_IssueCategory = new Sunny.UI.UILabel();
            this.Status = new Sunny.UI.UITextBox();
            this.uiLabel_Status = new Sunny.UI.UILabel();
            this.Workstation = new Sunny.UI.UITextBox();
            this.uiLabel_WorkStation = new Sunny.UI.UILabel();
            this.Model = new Sunny.UI.UITextBox();
            this.uiLabel_Model = new Sunny.UI.UILabel();
            this.MachineList = new Sunny.UI.UITextBox();
            this.uiLabel_MachineList = new Sunny.UI.UILabel();
            this.CreationDate = new Sunny.UI.UITextBox();
            this.uiLabel_CreationDate = new Sunny.UI.UILabel();
            this.uiLabel_Creator = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UITextBox();
            this.uiLabel_WorkOrderNo = new Sunny.UI.UILabel();
            this.WorkOrderNo = new Sunny.UI.UITextBox();
            this.uiLabel_OrderNo = new Sunny.UI.UILabel();
            this.OrderNo = new Sunny.UI.UITextBox();
            this.Details = new Sunny.UI.UITextBox();
            this.uiLabel_Details = new Sunny.UI.UILabel();
            this.SuspendLayout();
            // 
            // IssueDescription
            // 
            this.IssueDescription.CanEmpty = true;
            this.IssueDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(536, 69);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 16);
            this.IssueDescription.Multiline = true;
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(5);
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(250, 85);
            this.IssueDescription.TabIndex = 71;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.IssueDescription.Watermark = "";
            // 
            // uiLabel_IssueDescription
            // 
            this.uiLabel_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_IssueDescription.Location = new System.Drawing.Point(411, 69);
            this.uiLabel_IssueDescription.Name = "uiLabel_IssueDescription";
            this.uiLabel_IssueDescription.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_IssueDescription.TabIndex = 73;
            this.uiLabel_IssueDescription.Text = "問題描述";
            this.uiLabel_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AcceptedTime
            // 
            this.AcceptedTime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AcceptedTime.FillDisableColor = System.Drawing.Color.White;
            this.AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.AcceptedTime.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.AcceptedTime.Location = new System.Drawing.Point(160, 342);
            this.AcceptedTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AcceptedTime.MinimumSize = new System.Drawing.Size(1, 16);
            this.AcceptedTime.Name = "AcceptedTime";
            this.AcceptedTime.Padding = new System.Windows.Forms.Padding(5);
            this.AcceptedTime.ShowText = false;
            this.AcceptedTime.Size = new System.Drawing.Size(200, 29);
            this.AcceptedTime.TabIndex = 46;
            this.AcceptedTime.TabStop = false;
            this.AcceptedTime.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.AcceptedTime.Watermark = "";
            // 
            // uiLabel_AcceptedTime
            // 
            this.uiLabel_AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_AcceptedTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_AcceptedTime.Location = new System.Drawing.Point(33, 342);
            this.uiLabel_AcceptedTime.Name = "uiLabel_AcceptedTime";
            this.uiLabel_AcceptedTime.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_AcceptedTime.TabIndex = 49;
            this.uiLabel_AcceptedTime.Text = "接單時間";
            this.uiLabel_AcceptedTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // IssueCategory
            // 
            this.IssueCategory.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueCategory.FillDisableColor = System.Drawing.Color.White;
            this.IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.IssueCategory.Location = new System.Drawing.Point(536, 30);
            this.IssueCategory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueCategory.MinimumSize = new System.Drawing.Size(1, 16);
            this.IssueCategory.Name = "IssueCategory";
            this.IssueCategory.Padding = new System.Windows.Forms.Padding(5);
            this.IssueCategory.ShowText = false;
            this.IssueCategory.Size = new System.Drawing.Size(200, 29);
            this.IssueCategory.TabIndex = 59;
            this.IssueCategory.TabStop = false;
            this.IssueCategory.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.IssueCategory.Watermark = "";
            // 
            // uiLabel_IssueCategory
            // 
            this.uiLabel_IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_IssueCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_IssueCategory.Location = new System.Drawing.Point(409, 30);
            this.uiLabel_IssueCategory.Name = "uiLabel_IssueCategory";
            this.uiLabel_IssueCategory.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_IssueCategory.TabIndex = 61;
            this.uiLabel_IssueCategory.Text = "維護類型";
            this.uiLabel_IssueCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Condition
            // 
            this.Status.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Status.FillDisableColor = System.Drawing.Color.White;
            this.Status.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Status.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Status.Location = new System.Drawing.Point(160, 186);
            this.Status.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Status.MinimumSize = new System.Drawing.Size(1, 16);
            this.Status.Name = "Condition";
            this.Status.Padding = new System.Windows.Forms.Padding(5);
            this.Status.ShowText = false;
            this.Status.Size = new System.Drawing.Size(200, 29);
            this.Status.TabIndex = 45;
            this.Status.TabStop = false;
            this.Status.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Status.Watermark = "";
            // 
            // uiLabel_Status
            // 
            this.uiLabel_Status.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Status.Location = new System.Drawing.Point(33, 186);
            this.uiLabel_Status.Name = "uiLabel_Status";
            this.uiLabel_Status.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Status.TabIndex = 48;
            this.uiLabel_Status.Text = "狀態";
            this.uiLabel_Status.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkstationBuff
            // 
            this.Workstation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Workstation.FillDisableColor = System.Drawing.Color.White;
            this.Workstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Workstation.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Workstation.Location = new System.Drawing.Point(160, 303);
            this.Workstation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Workstation.MinimumSize = new System.Drawing.Size(1, 16);
            this.Workstation.Name = "WorkstationBuff";
            this.Workstation.Padding = new System.Windows.Forms.Padding(5);
            this.Workstation.ShowText = false;
            this.Workstation.Size = new System.Drawing.Size(200, 29);
            this.Workstation.TabIndex = 55;
            this.Workstation.TabStop = false;
            this.Workstation.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Workstation.Watermark = "";
            // 
            // uiLabel_WorkStation
            // 
            this.uiLabel_WorkStation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_WorkStation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_WorkStation.Location = new System.Drawing.Point(33, 303);
            this.uiLabel_WorkStation.Name = "uiLabel_WorkStation";
            this.uiLabel_WorkStation.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_WorkStation.TabIndex = 56;
            this.uiLabel_WorkStation.Text = "工站";
            this.uiLabel_WorkStation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ModelBuff
            // 
            this.Model.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Model.FillDisableColor = System.Drawing.Color.White;
            this.Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Model.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Model.Location = new System.Drawing.Point(160, 264);
            this.Model.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Model.MinimumSize = new System.Drawing.Size(1, 16);
            this.Model.Name = "ModelBuff";
            this.Model.Padding = new System.Windows.Forms.Padding(5);
            this.Model.ShowText = false;
            this.Model.Size = new System.Drawing.Size(200, 29);
            this.Model.TabIndex = 50;
            this.Model.TabStop = false;
            this.Model.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Model.Watermark = "";
            // 
            // uiLabel_Model
            // 
            this.uiLabel_Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Model.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Model.Location = new System.Drawing.Point(33, 264);
            this.uiLabel_Model.Name = "uiLabel_Model";
            this.uiLabel_Model.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Model.TabIndex = 52;
            this.uiLabel_Model.Text = "機種";
            this.uiLabel_Model.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineList
            // 
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.FillDisableColor = System.Drawing.Color.White;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MachineList.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.MachineList.Location = new System.Drawing.Point(160, 225);
            this.MachineList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(5);
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(200, 29);
            this.MachineList.TabIndex = 44;
            this.MachineList.TabStop = false;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            // 
            // uiLabel_MachineList
            // 
            this.uiLabel_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MachineList.Location = new System.Drawing.Point(33, 225);
            this.uiLabel_MachineList.Name = "uiLabel_MachineList";
            this.uiLabel_MachineList.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_MachineList.TabIndex = 47;
            this.uiLabel_MachineList.Text = "機台編號";
            this.uiLabel_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreationDate
            // 
            this.CreationDate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CreationDate.FillDisableColor = System.Drawing.Color.White;
            this.CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CreationDate.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CreationDate.Location = new System.Drawing.Point(160, 147);
            this.CreationDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CreationDate.MinimumSize = new System.Drawing.Size(1, 16);
            this.CreationDate.Name = "CreationDate";
            this.CreationDate.Padding = new System.Windows.Forms.Padding(5);
            this.CreationDate.ShowText = false;
            this.CreationDate.Size = new System.Drawing.Size(200, 29);
            this.CreationDate.TabIndex = 41;
            this.CreationDate.TabStop = false;
            this.CreationDate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreationDate.Watermark = "";
            // 
            // uiLabel_CreationDate
            // 
            this.uiLabel_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_CreationDate.Location = new System.Drawing.Point(33, 147);
            this.uiLabel_CreationDate.Name = "uiLabel_CreationDate";
            this.uiLabel_CreationDate.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_CreationDate.TabIndex = 43;
            this.uiLabel_CreationDate.Text = "建檔日期";
            this.uiLabel_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_Creator
            // 
            this.uiLabel_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Creator.Location = new System.Drawing.Point(33, 108);
            this.uiLabel_Creator.Name = "uiLabel_Creator";
            this.uiLabel_Creator.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Creator.TabIndex = 42;
            this.uiLabel_Creator.Text = "建檔人員";
            this.uiLabel_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Creator
            // 
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.FillDisableColor = System.Drawing.Color.White;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Creator.Location = new System.Drawing.Point(160, 108);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(5);
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(200, 29);
            this.Creator.TabIndex = 39;
            this.Creator.TabStop = false;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // uiLabel_WorkOrderNo
            // 
            this.uiLabel_WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_WorkOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_WorkOrderNo.Location = new System.Drawing.Point(33, 69);
            this.uiLabel_WorkOrderNo.Name = "uiLabel_WorkOrderNo";
            this.uiLabel_WorkOrderNo.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_WorkOrderNo.TabIndex = 37;
            this.uiLabel_WorkOrderNo.Text = "維護工單編號";
            this.uiLabel_WorkOrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkOrderNo
            // 
            this.WorkOrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.WorkOrderNo.FillDisableColor = System.Drawing.Color.White;
            this.WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkOrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.WorkOrderNo.Location = new System.Drawing.Point(160, 69);
            this.WorkOrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.WorkOrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.WorkOrderNo.Name = "WorkOrderNo";
            this.WorkOrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.WorkOrderNo.ShowText = false;
            this.WorkOrderNo.Size = new System.Drawing.Size(200, 29);
            this.WorkOrderNo.TabIndex = 36;
            this.WorkOrderNo.TabStop = false;
            this.WorkOrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.WorkOrderNo.Watermark = "";
            // 
            // uiLabel_OrderNo
            // 
            this.uiLabel_OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OrderNo.Location = new System.Drawing.Point(33, 30);
            this.uiLabel_OrderNo.Margin = new System.Windows.Forms.Padding(0);
            this.uiLabel_OrderNo.Name = "uiLabel_OrderNo";
            this.uiLabel_OrderNo.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OrderNo.TabIndex = 35;
            this.uiLabel_OrderNo.Text = "序號";
            this.uiLabel_OrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OrderNo
            // 
            this.OrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OrderNo.FillDisableColor = System.Drawing.Color.White;
            this.OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OrderNo.Location = new System.Drawing.Point(160, 30);
            this.OrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.OrderNo.Name = "OrderNo";
            this.OrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.OrderNo.ShowText = false;
            this.OrderNo.Size = new System.Drawing.Size(200, 29);
            this.OrderNo.TabIndex = 34;
            this.OrderNo.TabStop = false;
            this.OrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OrderNo.Watermark = "";
            // 
            // Details
            // 
            this.Details.CanEmpty = true;
            this.Details.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Details.Location = new System.Drawing.Point(536, 164);
            this.Details.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Details.MinimumSize = new System.Drawing.Size(1, 16);
            this.Details.Multiline = true;
            this.Details.Name = "Details";
            this.Details.Padding = new System.Windows.Forms.Padding(5);
            this.Details.ShowText = false;
            this.Details.Size = new System.Drawing.Size(250, 85);
            this.Details.TabIndex = 75;
            this.Details.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.Details.Watermark = "";
            // 
            // uiLabel_Details
            // 
            this.uiLabel_Details.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Details.Location = new System.Drawing.Point(411, 164);
            this.uiLabel_Details.Name = "uiLabel_Details";
            this.uiLabel_Details.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_Details.TabIndex = 77;
            this.uiLabel_Details.Text = "維護內容";
            this.uiLabel_Details.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FT_OrderAccepted
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1255, 570);
            this.Controls.Add(this.IssueDescription);
            this.Controls.Add(this.uiLabel_IssueDescription);
            this.Controls.Add(this.AcceptedTime);
            this.Controls.Add(this.uiLabel_AcceptedTime);
            this.Controls.Add(this.IssueCategory);
            this.Controls.Add(this.uiLabel_IssueCategory);
            this.Controls.Add(this.Status);
            this.Controls.Add(this.uiLabel_Status);
            this.Controls.Add(this.Workstation);
            this.Controls.Add(this.uiLabel_WorkStation);
            this.Controls.Add(this.Model);
            this.Controls.Add(this.uiLabel_Model);
            this.Controls.Add(this.MachineList);
            this.Controls.Add(this.uiLabel_MachineList);
            this.Controls.Add(this.CreationDate);
            this.Controls.Add(this.uiLabel_CreationDate);
            this.Controls.Add(this.uiLabel_Creator);
            this.Controls.Add(this.Creator);
            this.Controls.Add(this.uiLabel_WorkOrderNo);
            this.Controls.Add(this.WorkOrderNo);
            this.Controls.Add(this.uiLabel_OrderNo);
            this.Controls.Add(this.OrderNo);
            this.Controls.Add(this.Details);
            this.Controls.Add(this.uiLabel_Details);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "FT_OrderAccepted";
            this.Text = "FT_OrderAccepted";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UITextBox IssueDescription;
        private Sunny.UI.UILabel uiLabel_IssueDescription;
        private Sunny.UI.UITextBox AcceptedTime;
        private Sunny.UI.UILabel uiLabel_AcceptedTime;
        private Sunny.UI.UITextBox IssueCategory;
        private Sunny.UI.UILabel uiLabel_IssueCategory;
        private Sunny.UI.UITextBox Status;
        private Sunny.UI.UILabel uiLabel_Status;
        private Sunny.UI.UITextBox Workstation;
        private Sunny.UI.UILabel uiLabel_WorkStation;
        private Sunny.UI.UITextBox Model;
        private Sunny.UI.UILabel uiLabel_Model;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UILabel uiLabel_MachineList;
        private Sunny.UI.UITextBox CreationDate;
        private Sunny.UI.UILabel uiLabel_CreationDate;
        private Sunny.UI.UILabel uiLabel_Creator;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UILabel uiLabel_WorkOrderNo;
        private Sunny.UI.UITextBox WorkOrderNo;
        private Sunny.UI.UILabel uiLabel_OrderNo;
        private Sunny.UI.UITextBox OrderNo;
        private Sunny.UI.UITextBox Details;
        private Sunny.UI.UILabel uiLabel_Details;
    }
}
