﻿using System.Windows.Forms;

namespace Calin.TaskPulse.MechaTrack.Views
{
    public partial class MechaTrackPage : UserControl
    {
        public MechaTrackPage()
        {
            InitializeComponent();
        }
    }
}
