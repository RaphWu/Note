﻿namespace Calin.TaskPulse.MechaTrack.Views
{
    partial class MechaTrackPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiPanel_Header = new Sunny.UI.UIPanel();
            this.SuspendLayout();
            // 
            // uiPanel_Header
            // 
            this.uiPanel_Header.Dock = System.Windows.Forms.DockStyle.Left;
            this.uiPanel_Header.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiPanel_Header.Location = new System.Drawing.Point(0, 0);
            this.uiPanel_Header.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel_Header.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel_Header.Name = "uiPanel_Header";
            this.uiPanel_Header.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.uiPanel_Header.Size = new System.Drawing.Size(133, 450);
            this.uiPanel_Header.TabIndex = 0;
            this.uiPanel_Header.Text = "專案管理";
            this.uiPanel_Header.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // MechaTrackPage
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.uiPanel_Header);
            this.Name = "MechaTrackPage";
            this.Text = "MechaTrackPage";
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UIPanel uiPanel_Header;
    }
}