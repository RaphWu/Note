﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台分類。  
    /// </summary>
    public class MachineCategory
    {
        /// <summary>
        /// 機台分類代號。
        /// </summary>
        [Description("分類代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 機台分類名稱。
        /// </summary>
        [Description("分類")]
        [Required]
        [MaxLength(30)]
        public string CategoryName { get; set; }

        public virtual ICollection<MachineType> MachineTypes { get; set; }
    }
}
