﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 職稱。
    /// </summary>
    public class JobTitle
    {
        /// <summary>
        /// 職稱代號。
        /// </summary>
        [Description("職稱代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 職稱。
        /// </summary>
        [Description("職稱")]
        [MaxLength(12)]
        public string JobTitleName { get; set; }

        public virtual ICollection<Employee> Employees { get; set; }
    }
}
