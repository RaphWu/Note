﻿//namespace Calin.TaskPulse.Entity.Contants
//{
//    public enum CoreDataType
//    {
//        AllCoreData,
//        Employee,
//        Machine,
//        Model,
//        Workstation,
//    }
//}
